# Kingbase 数据库连接数配置指南

## 1. 查找配置文件位置

Kingbase 数据库的配置文件通常是 `kingbase.conf`，位于数据库实例的数据目录中。

### 查找方法：

```bash
# 方法1: 使用数据库查询
psql -h localhost -p 54321 -U system -d test -c "SHOW config_file;"

# 方法2: 查找进程配置文件
ps aux | grep kingbase | grep -o '\-D [^ ]*' | cut -d' ' -f2
# 然后在该目录下查找 kingbase.conf

# 方法3: 默认位置（根据安装路径可能不同）
# Linux: /opt/Kingbase/ES/V8/data/kingbase.conf
# 或: $KINGBASE_DATA/kingbase.conf
```

## 2. 修改 max_connections 参数

### 编辑配置文件：

```bash
# 使用编辑器打开配置文件
sudo vim /path/to/kingbase.conf
# 或
sudo nano /path/to/kingbase.conf
```

### 找到并修改以下参数：

```conf
# 最大连接数（默认通常是 100 或 200）
max_connections = 200          # 增加到所需的值，如 500 或 1000

# 其他相关参数（可选）
superuser_reserved_connections = 3    # 为超级用户保留的连接数
```

### 重要提示：
- **修改后需要重启数据库才能生效**
- 增加连接数会增加内存消耗（每个连接约占用几MB内存）
- 建议根据实际需求设置，不要设置过大

## 3. 重启数据库服务

```bash
# 方法1: 使用 systemctl (如果配置了服务)
sudo systemctl restart kingbaseserver
# 或
sudo systemctl restart kingbase

# 方法2: 使用服务脚本
sudo service kingbase restart

# 方法3: 手动重启
# 先停止数据库
kill -TERM `pgrep -f "kingbase"`
# 等待进程结束，然后启动
/opt/Kingbase/ES/V8/bin/kingbase -D /path/to/data &
```

## 4. 验证配置是否生效

```sql
-- 连接数据库后执行
SHOW max_connections;

-- 查看当前连接数
SELECT count(*) FROM pg_stat_activity;

-- 查看连接数统计
SELECT 
    count(*) as total,
    count(*) FILTER (WHERE state = 'active') as active,
    count(*) FILTER (WHERE state = 'idle') as idle
FROM pg_stat_activity;
```

## 5. 临时修改（无需重启）

如果不想重启数据库，可以临时增加连接数：

```sql
-- 注意：这个值不能超过 max_connections 的配置值
ALTER SYSTEM SET max_connections = 300;
SELECT pg_reload_conf();  -- 重新加载配置（但 max_connections 需要重启）
```

⚠️ **注意**: `max_connections` 参数实际上**无法**通过 `ALTER SYSTEM` 或 `pg_reload_conf()` 动态修改，必须重启数据库。

## 6. 检查当前连接数和状态

使用提供的 `check-db-connections.sh` 脚本：

```bash
chmod +x check-db-connections.sh
./check-db-connections.sh
```

## 7. 清理僵尸连接

如果遇到 "too many clients already" 错误，可以先清理空闲连接：

```sql
-- 查看空闲连接
SELECT pid, usename, state, state_change, query
FROM pg_stat_activity
WHERE datname = 'test' AND state = 'idle'
ORDER BY state_change;

-- 终止空闲连接（谨慎使用）
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = 'test'
  AND pid <> pg_backend_pid()
  AND state = 'idle'
  AND state_change < now() - interval '5 minutes';
```

## 8. 推荐配置值

根据应用场景建议：

- **小型应用**: 50-100
- **中型应用**: 100-200  
- **大型应用**: 200-500
- **超大型应用**: 500-1000（需要足够的内存）

每个连接的内存开销约为 2-5MB，计算总内存需求：
```
总内存需求 = max_connections × 3MB
```

## 9. 连接池配置建议

在 Druid 连接池中，建议配置：

```properties
# 连接池最大连接数应远小于数据库 max_connections
maxActive=50          # 单个应用的最大连接数

# 如果多个应用使用同一数据库，需要：
# 数据库 max_connections >= sum(所有应用的 maxActive) + 系统保留连接
```

例如：
- 数据库 max_connections = 200
- 应用1 maxActive = 50
- 应用2 maxActive = 50
- 系统保留 = 10
- 剩余 = 200 - 50 - 50 - 10 = 90（足够）

