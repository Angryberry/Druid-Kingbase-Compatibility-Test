package MaxEvictableIdleTimeMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxEvictableIdleTimeMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置极短的测试阈值
	private static final long TEST_MAX_IDLE_MS = 2000;
	private static final long SCAN_INTERVAL_MS = 500;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxEvictableIdleTimeMillis_Test.MaxEvictableIdleTimeMillis_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 1. 设置最大空闲时间为 2s
		dataSource.setMaxEvictableIdleTimeMillis(TEST_MAX_IDLE_MS);
		// 2. 最小空闲时间设为 1s（必须小于 Max）
		dataSource.setMinEvictableIdleTimeMillis(1000);
		// 3. 扫描频率设为 0.5s
		dataSource.setTimeBetweenEvictionRunsMillis(SCAN_INTERVAL_MS);

		// 关键点：保持 minIdle 为 1，我们要看这个“保底连接”是否会被强制踢掉
		dataSource.setMinIdle(1);
		dataSource.setInitialSize(1);
		dataSource.setValidationQuery("SELECT 1");
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证连接即使在 minIdle 范围内，超过 MaxEvictable 时间也会被销毁
	 */
	@Test
	public void shouldDestroyConnectionWhenExceedingMaxIdleTimeEvenUnderMinIdle() throws Exception {
		System.out.println(">>> 开始验证 MaxEvictableIdleTimeMillis 行为...");
		dataSource.init();

		// 1. 激活连接并归还
		try (Connection conn = dataSource.getConnection()) {
			System.out.println(">>> 连接已激活并放回池中，当前池内连接数: " + dataSource.getPoolingCount());
		}

		// 获取初始销毁计数
		long initialDestroyCount = dataSource.getDestroyCount();
		System.out.println(">>> 初始销毁计数: " + initialDestroyCount);

		// 2. 等待超过 TEST_MAX_IDLE_MS
		// 2s 超时 + 1s 冗余，确保清理线程至少扫描 2 遍
		System.out.println(">>> 等待连接超过最大空闲时间 (3s)...");
		Thread.sleep(3500);

		// 3. 获取当前的销毁计数
		long currentDestroyCount = dataSource.getDestroyCount();
		System.out.println(">>> 最终销毁计数: " + currentDestroyCount);

		// --- 核心断言 ---

		// 如果 MaxEvictable 生效，即便 minIdle=1，这个连接也必须被 Destroy
		assertTrue("错误：连接超过最大空闲时间后未被销毁！",
				currentDestroyCount > initialDestroyCount);

		// 检查 Druid 是否为了维持 minIdle 又自动创建了新连接
		System.out.println(">>> 验证成功：老旧连接已被强制物理销毁。当前池内连接数: " + dataSource.getPoolingCount());
	}
}