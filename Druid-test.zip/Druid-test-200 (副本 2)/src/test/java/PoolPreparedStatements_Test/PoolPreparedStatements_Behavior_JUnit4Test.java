package PoolPreparedStatements_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.util.Properties;

import static org.junit.Assert.*;

public class PoolPreparedStatements_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置缓存上限
	private static final int TEST_MAX_STATEMENTS = 10;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 使用工厂方法创建数据源
		dataSource = ParameterTest.PoolPreparedStatements_Test.PoolPreparedStatements_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 强制开启 PSCache 及其配套参数
		dataSource.setPoolPreparedStatements(true);
		dataSource.setMaxOpenPreparedStatements(TEST_MAX_STATEMENTS);

		dataSource.setInitialSize(1);
		dataSource.setMinIdle(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证执行 SQL 后，PreparedStatement 是否被存入物理缓存
	 */
	@Test
	public void shouldCachePreparedStatementInPhysicalConnection() throws Exception {
		System.out.println(">>> 开始验证 PoolPreparedStatements (PSCache) 行为...");

		// 获取一个连接
		try (DruidPooledConnection conn = (DruidPooledConnection) dataSource.getConnection()) {

			String testSql = "SELECT 1"; // 必须是相同的字符串

			// 1. 第一次执行：触发创建并放入缓存
			System.out.println(">>> 第一次执行 SQL，预期放入缓存...");
			try (PreparedStatement pstmt = conn.prepareStatement(testSql)) {
				pstmt.executeQuery();
			}

			// 获取缓存中的语句总数
			long countAfterFirst = dataSource.getCachedPreparedStatementCount();
			System.out.println(">>> 当前缓存语句总数: " + countAfterFirst);

			// 2. 第二次执行：应该从缓存直接命中
			System.out.println(">>> 第二次执行相同 SQL，预期命中缓存...");
			try (PreparedStatement pstmt = conn.prepareStatement(testSql)) {
				pstmt.executeQuery();
			}

			long countAfterSecond = dataSource.getCachedPreparedStatementCount();
			System.out.println(">>> 第二次执行后缓存总数: " + countAfterSecond);

			// --- 核心断言 ---

			// 断言 1: 缓存开关确实开启
			assertTrue("PSCache 逻辑未开启", dataSource.isPoolPreparedStatements());

			// 断言 2: 第一次执行后缓存里必须有东西
			assertTrue("执行后缓存总数应大于 0", countAfterFirst > 0);

			// 断言 3: 相同 SQL 不应产生新的缓存对象（证明重用了）
			assertEquals("相同 SQL 执行多次，缓存总数不应增加", countAfterFirst, countAfterSecond);

			System.out.println(">>> [验证通过]：PSCache 成功拦截并缓存了 PreparedStatement 对象。");
		}
	}
}