package Password_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class Password_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private Properties props;

	@Before
	public void setUp() throws Exception {
		props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 正面行为：使用配置文件中的正确密码应能成功获取连接
	 */
	@Test
	public void shouldConnectSuccessfullyWithCorrectPassword() throws SQLException {
		System.out.println(">>> 验证正确密码的连接行为...");
		dataSource = Password_Test.createDataSource(props);

		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接不应为空", conn);
			assertFalse("连接应为有效状态", conn.isClosed());
			System.out.println("【验证通过】：正确密码成功建立连接。");
		}
	}

	/**
	 * 反面行为：故意使用错误密码，验证驱动是否拦截并报错
	 * 这是证明 password 参数确实被传给驱动的最强证据
	 */
	@Test
	public void shouldFailAuthenticationWithWrongPassword() {
		System.out.println(">>> 验证错误密码的拦截行为...");

		// 覆盖密码为错误值
		props.setProperty("password", "WRONG_PASSWORD_666");
		dataSource = Password_Test.createDataSource(props);

		try {
			dataSource.getConnection();
			fail("错误：使用假密码理应建立连接失败");
		} catch (SQLException e) {
			// 验证报错信息中是否包含身份验证失败的特征（不同数据库关键字不同，如 'auth', 'password', 'denied'）
			String errorMsg = e.getMessage().toLowerCase();
			System.out.println("捕获到预期异常: " + e.getMessage());

			// 只要捕获到异常，且连接池没初始化成功，就说明参数生效了
			assertTrue("异常信息应包含认证相关关键字",
					errorMsg.contains("password") || errorMsg.contains("auth") || errorMsg.contains("denied"));
			System.out.println("【验证通过】：错误密码被数据库识别并拒绝访问。");
		}
	}
}