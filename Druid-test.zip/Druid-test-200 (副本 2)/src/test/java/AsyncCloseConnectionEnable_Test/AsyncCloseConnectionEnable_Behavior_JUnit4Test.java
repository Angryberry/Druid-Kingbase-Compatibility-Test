package AsyncCloseConnectionEnable_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;
import java.util.concurrent.Executor;

import static org.junit.Assert.*;

public class AsyncCloseConnectionEnable_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = AsyncCloseConnectionEnable_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 自动探测字段：不依赖硬编码的字段名
	 */
	private Object getAsyncFieldByInference(String hint) {
		Class<?> current = DruidDataSource.class;
		while (current != null) {
			for (Field field : current.getDeclaredFields()) {
				// 寻找包含 async 关键字且类型匹配的字段
				if (field.getName().toLowerCase().contains("async") &&
						field.getName().toLowerCase().contains(hint.toLowerCase())) {
					try {
						field.setAccessible(true);
						return field.get(dataSource);
					} catch (Exception ignored) {}
				}
			}
			current = current.getSuperclass();
		}
		return null;
	}

	@Test
	public void shouldVerifyAsyncBehaviorByAction() throws Exception {
		System.out.println(">>> 开始动作触发式验证...");

		// 1. 先触发一次物理丢弃，强迫 Druid 创建异步线程和执行器
		Connection conn = dataSource.getConnection();
		System.out.println("执行 discardConnection 触发异步机制...");
		dataSource.discardConnection(conn);

		// 给异步线程创建和执行留出时间
		Thread.sleep(1000);

		// 2. 验证：检查是否有异步执行器被创建
		boolean hasExecutor = false;
		Class<?> current = DruidDataSource.class;
		while (current != null) {
			for (Field field : current.getDeclaredFields()) {
				if (Executor.class.isAssignableFrom(field.getType())) {
					field.setAccessible(true);
					if (field.get(dataSource) != null) {
						hasExecutor = true;
						System.out.println("发现已初始化的执行器字段: " + field.getName());
					}
				}
			}
			current = current.getSuperclass();
		}

		// 3. 验证：检查 JVM 线程
		boolean threadFound = false;
		Thread[] threads = new Thread[Thread.activeCount() * 2];
		Thread.enumerate(threads);
		for (Thread t : threads) {
			if (t != null && t.getName().toLowerCase().contains("async") &&
					t.getName().toLowerCase().contains("close")) {
				threadFound = true;
				System.out.println("发现活跃的异步关闭线程: " + t.getName());
			}
		}

		assertTrue("AsyncCloseConnectionEnable 开启后，应能检测到异步执行器或异步线程",
				hasExecutor || threadFound);
	}
}