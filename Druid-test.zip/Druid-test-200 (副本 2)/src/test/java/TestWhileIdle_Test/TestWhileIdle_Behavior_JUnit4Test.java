package TestWhileIdle_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class TestWhileIdle_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    // 设置空闲检测的阈值：3秒
    private static final long IDLE_THRESHOLD_MS = 3000;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }

        // 沿用你之前的风格，通过你封装的工厂方法创建
        dataSource = TestWhileIdle_Test.createDataSource(props);

        // 关键配置：开启 testWhileIdle
        dataSource.setTestWhileIdle(true);
        // 关键配置：关闭 testOnBorrow，否则每次获取都会检测，testWhileIdle 就失去意义了
        dataSource.setTestOnBorrow(false);
        
        // 设置空闲判断的阈值 (testWhileIdle 依赖此参数作为空闲时间的判断标准)
        dataSource.setTimeBetweenEvictionRunsMillis(IDLE_THRESHOLD_MS);

        dataSource.setValidationQuery("SELECT 1");
        // 初始化 1 个连接，方便我们精准控制这 1 个连接的状态
        dataSource.setInitialSize(1);
        dataSource.setMinIdle(1);
        dataSource.setMaxActive(1);
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    @Test
    public void verifyTestWhileIdleEffectiveness() throws Exception {
        System.out.println(">>> 开始精准验证 testWhileIdle 机制，空闲阈值: " + IDLE_THRESHOLD_MS + "ms");
        dataSource.init();

        // 1. 预热阶段：获取一次连接并归还，使其进入空闲池，刷新它的 LastActiveTime
        try (Connection conn = dataSource.getConnection()) {
            System.out.println(">>> 预热：连接已激活并即将归还，开始计算空闲时间...");
        }

        // 2. 第一阶段验证：等待 1.5 秒 (小于 3 秒门槛)
        System.out.println(">>> 第一阶段：等待 1.5s (预期不触发 validationQuery)...");
        Thread.sleep(1500);
        
        // 由于没有触发校验，这次获取连接的速度应该极快
        long start1 = System.currentTimeMillis();
        try (Connection conn = dataSource.getConnection()) {
            long cost1 = System.currentTimeMillis() - start1;
            System.out.println(">>> 1.5s 后获取连接耗时: " + cost1 + "ms");
            assertNotNull("错误：未能成功获取连接", conn);
            // 这里可以观察日志，Druid 底层不会执行 SELECT 1
        }

        // 3. 第二阶段验证：等待 3.5 秒 (超过 3 秒门槛)
        // 此时由于连接归还后空闲了 3.5 秒，超过了 IDLE_THRESHOLD_MS，获取时一定会触发检测
        System.out.println(">>> 第二阶段：等待 3.5s (超过空闲阈值，预期触发 validationQuery)...");
        Thread.sleep(3500);
        
        long start2 = System.currentTimeMillis();
        try (Connection conn = dataSource.getConnection()) {
            long cost2 = System.currentTimeMillis() - start2;
            System.out.println(">>> 3.5s 后获取连接耗时: " + cost2 + "ms (由于执行了探活 SQL，耗时通常会略大于第一阶段)");
            assertNotNull("错误：未能成功获取连接", conn);
            // 这里可以观察日志，Druid 底层一定会执行一次 SELECT 1
        }

        System.out.println(">>> [验证通过]：testWhileIdle 严格遵守了 " + IDLE_THRESHOLD_MS + "ms 的空闲阈值工作。");
    }
}