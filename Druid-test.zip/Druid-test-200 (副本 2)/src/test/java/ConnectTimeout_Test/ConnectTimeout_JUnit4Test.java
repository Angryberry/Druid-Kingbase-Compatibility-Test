package ConnectTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.Test;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;
import java.util.concurrent.*;

import static org.junit.Assert.*;

public class ConnectTimeout_JUnit4Test {

	// 黑洞 IP：用于模拟无响应网络a
	private static final String BLACK_HOLE_URL = "jdbc:kingbase8://192.0.2.1:54321/test";

	@Test
	public void compareTimeoutBehavior() throws Exception {
		Properties props = loadProps();

		// 1. 测试：设置了 3000ms 超时的情况
		long timeoutDuration = measureConnectionAttempt(props, 3000);
		System.out.println("【实验组】设置 3s 超时，实际耗时: " + timeoutDuration + "ms");
		assertTrue("设置了超时但耗时太久，参数可能失效", timeoutDuration < 8000);
		assertTrue("报错太快，可能触发了 Connection Refused 而非超时", timeoutDuration >= 2500);

		// 2. 测试：不设置超时（或设为 0）的情况
		// 注意：此步可能会卡很久，所以我们在 Future.get 设置了 10 秒死线
		System.out.println("【对照组】不设置超时，开始观察默认行为...");
		long defaultDuration = measureConnectionAttempt(props, 0);
		System.out.println("【对照组】默认行为耗时: " + defaultDuration + "ms (由于测试死线，此处可能被 Future 强行中断)");
	}

	private long measureConnectionAttempt(Properties props, int timeoutMs) throws Exception {
		DruidDataSource ds = new DruidDataSource();
		ds.setDriverClassName(props.getProperty("driverClassName", "com.kingbase8.Driver"));
		ds.setUrl(BLACK_HOLE_URL);
		ds.setUsername("test");
		ds.setPassword("test");

		// 设置参数
		ds.setConnectTimeout(timeoutMs);
		ds.setInitialSize(0);
		ds.setMaxWait(timeoutMs > 0 ? timeoutMs + 2000 : 10000); // 兜底

		ExecutorService executor = Executors.newSingleThreadExecutor();
		long start = System.currentTimeMillis();

		Future<Void> future = executor.submit(() -> {
			try (Connection conn = ds.getConnection()) {
				return null;
			}
		});

		try {
			// 给对照组设置 10 秒的硬死线，防止整个测试卡死
			future.get(10000, TimeUnit.MILLISECONDS);
		} catch (TimeoutException e) {
			future.cancel(true);
			return System.currentTimeMillis() - start;
		} catch (ExecutionException e) {
			// 预期：由于连不上，会抛出 SQLException
		} finally {
			ds.close();
			executor.shutdownNow();
		}

		return System.currentTimeMillis() - start;
	}

	private Properties loadProps() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		return props;
	}
}