package TestOnBorrow_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class TestOnBorrow_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			props.load(in);
		}
		dataSource = TestOnBorrow_Test.createDataSource(props);

		// 1. 基础配置
		dataSource.setInitialSize(1);
		dataSource.setMaxActive(1);
		dataSource.setTestWhileIdle(false);

		// 2. 这里的反射依然保留，作为双保险
		forceExpireConnection(dataSource);

		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}
	private void forceExpireConnection(DruidDataSource ds) {
		try {
			// 1. 获取 DruidDataSource 内部存储连接的数组字段
			java.lang.reflect.Field connectionsField = com.alibaba.druid.pool.DruidDataSource.class.getDeclaredField("connections");
			connectionsField.setAccessible(true);

			// 2. 获取当前的连接数组
			Object[] connections = (Object[]) connectionsField.get(ds);

			// 3. 如果数组里有连接，修改第一个连接的状态
			if (connections != null && connections.length > 0 && connections[0] != null) {
				Object holder = connections[0]; // 这是一个 DruidConnectionHolder 对象

				// 4. 找到 lastActiveTimeMillis 字段并设为 0 (1970年)
				java.lang.reflect.Field lastActiveField = holder.getClass().getDeclaredField("lastActiveTimeMillis");
				lastActiveField.setAccessible(true);
				lastActiveField.set(holder, 0L);

				System.out.println(">>> [反射成功] 已手动将连接标记为“陈旧”，强制触发下次借出校验。");
			}
		} catch (NoSuchFieldException | IllegalAccessException e) {
			System.err.println(">>> [警告] 反射失败，字段名可能在当前 Druid 版本中已更改: " + e.getMessage());
		}
	}
	@Test
	public void shouldReplaceInvalidConnectionOnBorrow() throws Exception {
		System.out.println(">>> 开始验证 TestOnBorrow (精准拦截法)...");

		// 1. 准备：获取一个正常连接并归还
		Connection connInitial = dataSource.getConnection();
		connInitial.close();

		// 2. 核心证据：记录初始丢弃计数（注意是 DiscardCount）
		long initialDiscardCount = dataSource.getDiscardCount();

		// 3. 注入毒药 SQL 并强制标记过期
		dataSource.setValidationQuery("SELECT 1 FROM non_existent_table_999");
		forceExpireConnection(dataSource);

		System.out.println(">>> 执行借出动作，触发校验失败...");
		try {
			// 设置极短的获取等待，因为我们知道它必错
			dataSource.setMaxWait(1000);
			dataSource.getConnection();
			fail("错误：由于设置了错误的 SQL，此时理应抛出异常并丢弃连接");
		} catch (Exception e) {
			System.out.println(">>> 成功捕获到校验失败异常 (Proof of Success!)");
		} finally {
			// 立刻恢复正常 SQL，平息后台补位线程的“愤怒”
			dataSource.setValidationQuery("SELECT 1");
		}

		// 4. --- 核心断言：检查丢弃计数 ---
		long finalDiscardCount = dataSource.getDiscardCount();
		System.out.println(">>> 最终丢弃计数 (DiscardCount): " + finalDiscardCount);

		// 只要丢弃计数增加了，就证明 TestOnBorrow 确实拦截并剔除了坏连接
		assertTrue("核心验证失败：TestOnBorrow 未能触发丢弃逻辑！", finalDiscardCount > initialDiscardCount);

		System.out.println(">>> [验证通过]：Druid 成功识别并丢弃了校验失败的连接。");
	}
}