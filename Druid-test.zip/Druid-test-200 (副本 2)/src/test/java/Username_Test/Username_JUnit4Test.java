package Username_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class Username_JUnit4Test {

	private DruidDataSource dataSource;
	private Properties props;

	@Before
	public void setUp() throws Exception {
		props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 正面行为：验证使用配置文件中的正确用户名能否成功建立连接
	 */
	@Test
	public void shouldConnectSuccessfullyWithCorrectUsername() throws SQLException {
		System.out.println(">>> 验证正确用户名的连接行为...");
		dataSource = Username_Test.createDataSource(props);

		// 触发物理连接建立
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接不应为空", conn);
			assertFalse("连接应处于开启状态", conn.isClosed());
			System.out.println("成功以用户 [" + dataSource.getUsername() + "] 身份登录。");
		}
	}

	/**
	 * 反面行为：故意使用一个不存在的用户名
	 * 证明驱动程序确实将这个参数透传给了数据库并被拦截
	 */
	@Test
	public void shouldFailWithInvalidUsername() {
		System.out.println(">>> 验证错误用户名的拦截行为...");

		// 注入一个显然错误的用户名
		props.setProperty("username", "NON_EXISTENT_USER_999");
		dataSource = Username_Test.createDataSource(props);

		try {
			// 这会触发数据库的 Access Denied 异常
			dataSource.getConnection();
			fail("错误：使用无效用户名理应连接失败");
		} catch (SQLException e) {
			System.out.println("捕获到预期异常: " + e.getMessage());

			// 核心断言：异常信息应包含认证失败相关的关键字
			String errorMsg = e.getMessage().toLowerCase();
			assertTrue("报错信息应包含认证或用户相关的关键字",
					errorMsg.contains("user") || errorMsg.contains("auth") || errorMsg.contains("denied"));

			System.out.println("【验证通过】：数据库成功识别并拦截了非法用户名。");
		}
	}

	/**
	 * 属性验证：保持基本的 getter 检查
	 */
	@Test
	public void verifyUsernameAttributeConsistency() {
		dataSource = Username_Test.createDataSource(props);
		assertEquals("数据源中的用户名必须与配置一致",
				props.getProperty("username"), dataSource.getUsername());
	}
}