package PhyMaxUseCount_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class PhyMaxUseCount_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = PhyMaxUseCount_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证物理连接在达到最大使用次数后是否被重新创建
	 */
	@Test
	public void shouldRecreatePhysicalConnectionAfterMaxUses() throws Exception {
		// 1. 获取初始的物理连接创建计数
		long initialConnectCount = dataSource.getCreateCount();
		System.out.println("初始物理连接创建数: " + initialConnectCount);

		int testCycles = PhyMaxUseCount_Test.PHY_MAX_USE_COUNT + 1;

		// 2. 循环使用并关闭连接
		for (int i = 1; i <= testCycles; i++) {
			try (Connection conn = dataSource.getConnection()) {
				assertNotNull("无法获取连接", conn);
				// 模拟数据库操作
				conn.getMetaData();
				System.out.println("第 " + i + " 次使用连接并归还...");
			}
			// Druid 在 recycle（归还）连接时会检查使用次数
		}

		// 3. 核心行为断言
		long finalConnectCount = dataSource.getCreateCount();
		System.out.println("最终物理连接创建数: " + finalConnectCount);

		// 解释：因为我们设定的重用上限是 2，所以第 3 次获取连接时，
		// Druid 发现之前的物理连接已“过期”，必须创建一个新的。
		assertTrue("物理连接数理应增加，说明旧连接已因达到 PhyMaxUseCount 而被销毁重建",
				finalConnectCount > initialConnectCount);

		assertEquals("参数值校验",
				PhyMaxUseCount_Test.PHY_MAX_USE_COUNT,
				dataSource.getPhyMaxUseCount());
	}
}