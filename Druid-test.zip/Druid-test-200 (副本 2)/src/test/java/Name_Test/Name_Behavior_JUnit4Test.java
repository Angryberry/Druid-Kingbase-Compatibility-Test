package Name_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.stat.DataSourceMonitorable;
import com.alibaba.druid.stat.DruidDataSourceStatManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Properties;
import java.io.InputStream;
import java.util.Set;

import static org.junit.Assert.*;

public class Name_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = Name_Test.createDataSource(props);
		// init 会触发 JMX 注册和 StatManager 登记
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证该名称是否已在 Druid 全局统计管理器中注册
	 */
	@Test
	public void shouldBeRegisteredInGlobalStatManagerWithName() {
		System.out.println(">>> 开始验证 Name 属性的全局登记行为...");

		// 1. 获取 Druid 全局管理的所有数据源实例
		Set<DataSourceMonitorable> instances = DruidDataSourceStatManager.getDruidDataSourceInstances();

		System.out.println("当前全局管理器中已注册的数据源数量: " + instances.size());

		// 2. 核心行为断言：在所有实例中寻找我们的 DATA_SOURCE_NAME
		boolean isRegistered = false;
		for (DataSourceMonitorable ds : instances) {
			if (Name_Test.DATA_SOURCE_NAME.equals(ds.getName())) {
				isRegistered = true;
				System.out.println("【验证通过】：在全局管理器中成功找到名为 [" + ds.getName() + "] 的实例。");
				break;
			}
		}

		assertTrue("设置了 name 之后，数据源应在 Druid 全局统计管理器中以该名称注册", isRegistered);
	}

	/**
	 * 属性验证：确保基本的 getter 返回正确
	 */
	@Test
	public void verifyNameAttribute() {
		assertEquals("数据源名称属性不符", Name_Test.DATA_SOURCE_NAME, dataSource.getName());
	}
}