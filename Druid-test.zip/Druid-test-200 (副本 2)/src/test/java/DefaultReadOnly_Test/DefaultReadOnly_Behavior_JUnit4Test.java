package DefaultReadOnly_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class DefaultReadOnly_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private static final String TEST_TABLE = "test_readonly_behavior";

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 调用工厂方法创建数据源
		dataSource = DefaultReadOnly_Test.createDataSource(props);
		dataSource.init();

		// 2. 准备环境：强制开启一个非只读连接来建表
		try (Connection conn = dataSource.getConnection()) {
			// 注意：因为 dataSource 默认是只读的，我们要手动改一下这个连接的状态来建表
			conn.setReadOnly(false);
			conn.setAutoCommit(true);
			try (Statement stmt = conn.createStatement()) {
				stmt.execute("CREATE TABLE IF NOT EXISTS " + TEST_TABLE + " (id INT PRIMARY KEY, val VARCHAR(20))");
			}
		}
	}

	@After
	public void tearDown() throws Exception {
		if (dataSource != null) {
			try (Connection conn = dataSource.getConnection()) {
				conn.setReadOnly(false);
				try (Statement stmt = conn.createStatement()) {
					stmt.execute("DROP TABLE IF EXISTS " + TEST_TABLE);
				}
			}
			dataSource.close();
		}
	}

	/**
	 * 行为验证 1：验证从池中获取的 Connection 状态是否为只读
	 */
	/**
	 * 行为验证：在显式事务中验证只读约束
	 */
	@Test
	public void shouldThrowExceptionInReadOnlyTransaction() throws Exception {
		try (Connection conn = dataSource.getConnection()) {
			// 1. 验证初始状态
			assertTrue("连接池返回的连接应当标记为只读", conn.isReadOnly());

			// 2. 【核心改进】关闭自动提交，强制进入事务模式
			// 在 Kingbase 中，事务内的只读检查通常更严格
			conn.setAutoCommit(false);

			try (Statement stmt = conn.createStatement()) {
				System.out.println("尝试在只读事务中执行写入...");
				stmt.executeUpdate("INSERT INTO " + TEST_TABLE + " VALUES (100, 'strict_test')");

				// 如果执行成功了，尝试 commit，有些驱动是在提交时报错
				conn.commit();

				fail("只读事务竟然允许写入并提交，这不合理！");
			} catch (SQLException e) {
				// 预期会走到这里
				System.out.println("成功触发数据库只读异常: " + e.getMessage());
				// Kingbase 的错误信息通常包含 "read-only"
				assertTrue(e.getMessage().toLowerCase().contains("read-only"));
			} finally {
				// 回滚以清理事务状态
				try { conn.rollback(); } catch (Exception ignored) {}
			}
		}
	}
}