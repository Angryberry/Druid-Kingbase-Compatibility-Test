package DefaultTransactionIsolation_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.*;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class DefaultTransactionIsolation_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private static final String TEST_TABLE = "test_isolation_behavior";

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 创建数据源（假设配置中设置了 TRANSACTION_READ_COMMITTED）
		dataSource = ParameterTest.DefaultTransactionIsolation_Test.DefaultTransactionIsolation_Test.createDataSource(props);
		dataSource.init();

		// 2. 环境准备
		try (Connection conn = dataSource.getConnection()) {
			conn.setAutoCommit(true);
			try (Statement stmt = conn.createStatement()) {
				stmt.execute("CREATE TABLE IF NOT EXISTS " + TEST_TABLE + " (id INT PRIMARY KEY, val VARCHAR(20))");
				stmt.execute("DELETE FROM " + TEST_TABLE);
				stmt.execute("INSERT INTO " + TEST_TABLE + " VALUES (1, 'original')");
			}
		}
	}

	@After
	public void tearDown() throws Exception {
		if (dataSource != null) {
			try (Connection conn = dataSource.getConnection();
				 Statement stmt = conn.createStatement()) {
				stmt.execute("DROP TABLE IF EXISTS " + TEST_TABLE);
			} finally {
				dataSource.close();
			}
		}
	}

	/**
	 * 行为验证 1：验证 Connection 对象的隔离级别属性
	 */
	@Test
	public void shouldReflectIsolationInConnection() throws Exception {
		try (Connection conn = dataSource.getConnection()) {
			int expected = ParameterTest.DefaultTransactionIsolation_Test.DefaultTransactionIsolation_Test.DEFAULT_TRANSACTION_ISOLATION;
			assertEquals("Connection 对象的隔离级别与配置不一致", expected, conn.getTransactionIsolation());
		}
	}

	/**
	 * 行为验证 2：通过“防止脏读”来验证 READ_COMMITTED 级别是否生效
	 */
	@Test
	public void shouldPreventDirtyReadUnderReadCommitted() throws Exception {
		int isolation = ParameterTest.DefaultTransactionIsolation_Test.DefaultTransactionIsolation_Test.DEFAULT_TRANSACTION_ISOLATION;

		// 只有在 RC 或更高时，该行为验证才有意义
		if (isolation >= Connection.TRANSACTION_READ_COMMITTED) {

			try (Connection connA = dataSource.getConnection();
				 Connection connB = dataSource.getConnection()) {

				// 1. A 开启事务并修改数据，但不提交
				connA.setAutoCommit(false);
				try (Statement stmtA = connA.createStatement()) {
					stmtA.executeUpdate("UPDATE " + TEST_TABLE + " SET val = 'dirty' WHERE id = 1");
				}

				// 2. B 尝试读取数据
				try (Statement stmtB = connB.createStatement();
					 ResultSet rs = stmtB.executeQuery("SELECT val FROM " + TEST_TABLE + " WHERE id = 1")) {
					rs.next();
					String val = rs.getString(1);

					// 核心断言：B 应该依然看到 'original'，而不是 'dirty'
					assertEquals("脏读发生了！RC 隔离级别未生效", "original", val);
				}

				connA.rollback(); // 清理 A
			}
		}
	}
}