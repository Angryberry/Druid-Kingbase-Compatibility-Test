package NumTestsPerEvictionRun_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class NumTestsPerEvictionRun_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = NumTestsPerEvictionRun_Test.createDataSource(props);
		dataSource.init();

		// 借出再归还，刷新 lastActiveTimeMillis
		Connection[] conns = new Connection[5];
		for (int i = 0; i < 5; i++) conns[i] = dataSource.getConnection();
		for (int i = 0; i < 5; i++) conns[i].close();

		// 等待超过 keepAliveBetweenTimeMillis(600ms)，使连接进入保活待检状态
		Thread.sleep(800);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	@Test
	public void shouldVerifyNumTestsPerRunByKeepAliveCount() throws Exception {
		System.out.println(">>> 开始验证 NumTestsPerEvictionRun 行为...");

		Field checkField = DruidDataSource.class.getDeclaredField("keepAliveCheckCount");
		checkField.setAccessible(true);

		int count1 = (int) checkField.get(dataSource);
		System.out.println("初始保活检查计数: " + count1);

		// 等待多次异步扫描：500ms/次，3秒内约 6 次，每次检查 3 个连接
		System.out.println("等待 3 秒让 DestroyTask 按步长(" +
				NumTestsPerEvictionRun_Test.NUM_TESTS_PER_EVICTION_RUN + ")执行扫描...");
		Thread.sleep(3000);

		int count2 = (int) checkField.get(dataSource);
		int increment = count2 - count1;
		System.out.println("最终保活检查计数: " + count2 + " (期间增加: " + increment + ")");

		// 断言1：保活检查必须发生
		assertTrue("保活检查计数未增长！后台任务可能未运行", increment > 0);

		// 断言2：步长控制有效，增量应 >= NUM_TESTS_PER_EVICTION_RUN
		assertTrue("步长控制未生效，增量 [" + increment + "] 低于步长 [" +
						NumTestsPerEvictionRun_Test.NUM_TESTS_PER_EVICTION_RUN + "]",
				increment >= NumTestsPerEvictionRun_Test.NUM_TESTS_PER_EVICTION_RUN);

		System.out.println("【验证成功】后台线程已按步长(" +
				NumTestsPerEvictionRun_Test.NUM_TESTS_PER_EVICTION_RUN + ")执行保活任务，总计检查: " + increment + " 次");
	}
}