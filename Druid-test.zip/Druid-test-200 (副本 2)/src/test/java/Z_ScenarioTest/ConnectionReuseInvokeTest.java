package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

/**
 * 自动化调用 ConnectionReuseDruidTest 并验证结果
 */
public class ConnectionReuseInvokeTest {

    @Test
    public void verifyConnectionReuseScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，用于最后还原
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备缓冲区：捕获 main 方法产生的所有内容
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 剩下的逻辑完全不用动

            try {
                // 重定向标准输出和错误输出（场景 5 的 recycle error 就在 err 里）
                System.setOut(captureStream);
                System.setErr(captureStream);

                // 3. 调用你的自动化工具类
                // 注意：如果原类有 System.exit()，此处会崩溃
                ConnectionReuseDruidTest.main(new String[0]);

            } catch (Exception e) {
                // 如果执行期间崩了，立刻还原流，否则你看不到报错堆栈
                System.setOut(originalOut);
                e.printStackTrace();
                Assert.fail("执行回归测试工具时抛出异常: " + e.getMessage());
            } finally {
                // 4. 无论如何都要还原系统流
                System.setOut(originalOut);
                System.setErr(originalErr);
            }
        }

        // 5. 获取捕获到的完整日志
        String fullOutput = outputBuffer.toString("UTF-8");

        // 把结果打印回真实的控制台，这样你运行 mvn test 时能看到过程
        System.out.println("--- 捕获到的回归测试报告 ---\n");
        System.out.println(fullOutput);
        System.out.println("---------------------------\n");

        // 6. 核心行为断言
        Assert.assertTrue("回归测试未检测到统计简报，可能程序中途崩溃！",
                fullOutput.contains("📊 自动化测试简报"));

        // 匹配成功率。注意：原代码中可能有多余空格，这里用 contains 比较稳
        Assert.assertTrue("连接复用测试未达到 100% 成功率，请检查上方的错误详情！",
                fullOutput.contains("成功率:   100%"));

        System.out.println("🎉 [JUnit] 自动化回归验证圆满完成。");
    }
}