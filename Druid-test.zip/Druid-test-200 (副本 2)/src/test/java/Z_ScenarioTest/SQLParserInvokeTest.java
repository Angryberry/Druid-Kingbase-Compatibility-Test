package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 自动化集成测试：调用 SQLParserDruidTest 并验证解析与防火墙成功率
 */
public class SQLParserInvokeTest {

    @Test
    public void verifySQLParserScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，确保测试结束后控制台还原
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备捕获缓冲区
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造方式 (使用 String 类型的 "UTF-8")
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出
            // 场景 3 的 SQL 注入拦截和场景 5 的语法错误信息通常在 err 流中
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 调用逻辑类的 main 方法
            // 包含了 6 个解析场景，运行速度通常很快（约 10 秒左右）
            SQLParserDruidTest.main(new String[0]);

            // 4. 立即还原系统流，防止断言失败时看不到输出
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取并回显捕获到的日志到真实控制台
            String fullOutput = outputBuffer.toString("UTF-8");
            System.out.println("--- [Captured SQL Parser Test Output] ---");
            System.out.println(fullOutput);
            System.out.println("------------------------------------------");

            // 6. 核心行为断言
            // 验证是否输出了统计简报标题
            Assert.assertTrue("未检测到 SQL 解析测试简报，程序可能运行异常！",
                    fullOutput.contains("📊 SQL 解析专项测试简报"));

            // 验证成功率是否为 100%
            // 注意：contains 里的空格需与逻辑类打印格式 "成功率:   100%" 保持一致
            Assert.assertTrue("SQL 解析或 WallFilter 验证未达到 100% 成功率！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] SQL 解析与防火墙自动化验证圆满完成。");

        } catch (Exception e) {
            // 异常时强制还原流，避免 IDE 控制台“变哑巴”
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("执行 SQL 解析测试工具时抛出异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}