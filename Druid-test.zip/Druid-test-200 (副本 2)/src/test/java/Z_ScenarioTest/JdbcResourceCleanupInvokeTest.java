package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 自动化回归测试：调用 JdbcResourceCleanupDruidTest 并验证资源清理成功率
 */
public class JdbcResourceCleanupInvokeTest {

    @Test
    public void verifyJdbcResourceCleanupScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，确保测试后能还原 IDE 控制台
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备缓冲区捕获控制台输出
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造函数（使用字符串 "UTF-8" 而非 Charset 对象）
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 调用逻辑类的 main 方法
            // 注意：此时 JdbcResourceCleanupDruidTest 内部不应含有 System.exit(0)
            JdbcResourceCleanupDruidTest.main(new String[0]);

            // 4. 立即还原系统流，否则后面的 System.out.println 会打进缓冲区看不见
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取捕获到的完整日志内容
            String fullOutput = outputBuffer.toString("UTF-8");

            // 将结果回显到真实控制台，方便在 Maven 报告中查看详细过程
            System.out.println("--- [Captured Output] ---");
            System.out.println(fullOutput);
            System.out.println("-------------------------");

            // 6. 核心行为断言
            // 验证是否打印了简报头
            Assert.assertTrue("未检测到测试简报，程序可能中途崩溃！",
                    fullOutput.contains("📊 JDBC 资源清理测试简报"));

            // 验证成功率是否为 100%
            Assert.assertTrue("JDBC 资源清理验证未达到 100% 成功率！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 JUnit 断言成功：JDBC 资源清理所有场景通过。");

        } catch (Exception e) {
            // 确保发生异常时也能还原流
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("执行回归测试时发生非预期异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}