package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 集成测试：自动化调用 RemoveAbandonedDruidTest 并验证回收成功率
 */
public class RemoveAbandonedInvokeTest {

    @Test
    public void verifyRemoveAbandonedScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备缓冲区捕获控制台输出
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造函数
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 调用逻辑类的 main 方法
            // 提示：此测试会运行约 40-50 秒，因为包含多次超时等待
            RemoveAbandonedDruidTest.main(new String[0]);

            // 4. 立即还原系统流
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取捕获到的完整日志内容
            String fullOutput = outputBuffer.toString("UTF-8");

            // 将结果回显到真实控制台，方便查看
            System.out.println("--- [Captured removeAbandoned Output] ---");
            System.out.println(fullOutput);
            System.out.println("------------------------------------------");

            // 6. 核心行为断言
            Assert.assertTrue("未检测到回收机制测试简报，程序运行不完整！",
                    fullOutput.contains("📊 removeAbandoned 回收机制测试简报"));

            Assert.assertTrue("遗弃连接回收验证未达到 100% 成功率！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] 遗弃连接回收机制所有场景验证通过。");

        } catch (Exception e) {
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("测试执行期间发生非预期异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}