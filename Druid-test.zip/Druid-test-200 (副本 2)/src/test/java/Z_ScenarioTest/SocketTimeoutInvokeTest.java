package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 自动化集成测试：触发 Socket-Timeout 场景并断言 100% 成功率
 */
public class SocketTimeoutInvokeTest {

    @Test
    public void verifySocketTimeoutScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，确保 JUnit 运行后不影响 IDE 控制台
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备缓冲区抓取 main 方法的输出
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造函数（使用字符串 "UTF-8"）
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出（场景 2 和 4 的异常堆栈都在 err 里）
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 执行刚才修改好的自动化逻辑类
            // 提示：因为包含超时等待，此测试预计运行 30 秒左右
            SocketTimeoutDruidTest.main(new String[0]);

            // 4. 立即还原系统流
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取并回显捕获到的日志到真实控制台，方便在 Maven 报告中审计
            String fullOutput = outputBuffer.toString("UTF-8");
            System.out.println("--- [Captured Socket-Timeout Output] ---");
            System.out.println(fullOutput);
            System.out.println("----------------------------------------");

            // 6. 核心行为断言
            // 验证是否打印了报告头
            Assert.assertTrue("未检测到回归报告，程序可能中途意外崩溃！",
                    fullOutput.contains("📊 Socket-Timeout 专项回归报告"));

            // 验证成功率是否为 100%
            // 如果你在 logic 类里修复了判定逻辑，这里应该稳稳拿到 100%
            Assert.assertTrue("Socket-Timeout 验证存在失败场景，请检查上面的异常判定逻辑！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] Socket-Timeout 自动化矩阵验证通过！");

        } catch (Exception e) {
            // 异常时还原流，否则你看不到 JUnit 的报错
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("集成测试执行异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}