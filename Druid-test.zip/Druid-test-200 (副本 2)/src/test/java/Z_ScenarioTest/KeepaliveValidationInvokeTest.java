package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 自动化集成测试：调用 KeepaliveValidation 逻辑并验证保活成功率
 */
public class KeepaliveValidationInvokeTest {

    @Test
    public void verifyKeepaliveScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，确保测试结束后控制台恢复正常
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备捕获缓冲区
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造方式
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 调用逻辑类的 main 方法
            // 自动化版本的 KeepaliveValidation 现在运行约 15-20 秒
            KeepaliveValidation.main(new String[0]);

            // 4. 立即还原系统流
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取并回显捕获到的日志
            String fullOutput = outputBuffer.toString("UTF-8");
            System.out.println("--- [Captured Keepalive Output] ---");
            System.out.println(fullOutput);
            System.out.println("-----------------------------------");

            // 6. 核心断言
            // 验证是否输出了统计简报
            Assert.assertTrue("未检测到保活测试简报，程序可能中途异常退出！",
                    fullOutput.contains("📊 Keepalive 专项测试简报"));

            // 验证成功率是否为 100%
            // 注意：contains 里的空格需与逻辑类打印格式保持一致
            Assert.assertTrue("保活验证测试未达到 100% 成功率！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] 保活机制自动化验证圆满通过。");

        } catch (Exception e) {
            // 异常时也要确保流被还原，否则 IDE 的控制台会失效
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("执行保活测试工具时抛出非预期异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}