package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * 自动化集成测试：调用 PreparedStatementCacheTest 逻辑并验证 PSCache 成功率
 */
public class PreparedStatementCacheInvokeTest {

    @Test
    public void verifyPreparedStatementCacheScenarios() throws UnsupportedEncodingException {
        // 1. 备份原始输出流，确保测试结束后控制台还原
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;

        // 2. 准备捕获缓冲区
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        // 使用 Java 8 兼容的构造方式 (使用 String 类型的 "UTF-8")
        try (PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8")) {
            // 重定向标准输出和错误输出（捕捉可能出现的各种日志）
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 3. 调用逻辑类的 main 方法
            // 自动化版本现在运行约 10-15 秒（包含场景3的物理等待）
            PreparedStatementCacheTest.main(new String[0]);

            // 4. 立即还原系统流，防止断言失败时看不到输出
            System.setOut(originalOut);
            System.setErr(originalErr);

            // 5. 获取并回显捕获到的日志
            String fullOutput = outputBuffer.toString("UTF-8");
            System.out.println("--- [Captured PSCache Test Output] ---");
            System.out.println(fullOutput);
            System.out.println("---------------------------------------");

            // 6. 核心行为断言
            // 验证是否输出了统计简报标题
            Assert.assertTrue("未检测到 PSCache 测试简报，程序可能中途崩溃！",
                    fullOutput.contains("📊 PreparedStatement 缓存测试简报"));

            // 验证成功率是否为 100%
            // 注意：如果之前场景2失败了，这里会抛出断言错误，Maven 会标记为 Failure
            Assert.assertTrue("PSCache 验证未达到 100% 成功率，请检查场景 2 的对象复用逻辑！",
                    fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] PSCache 机制自动化验证圆满完成。");

        } catch (Exception e) {
            // 异常时强制还原流，避免 IDE 控制台“失灵”
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("执行 PSCache 测试工具时抛出异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}