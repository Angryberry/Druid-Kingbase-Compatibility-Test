package RemoveAbandoned_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class RemoveAbandoned_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置极短的泄露超时阈值：1秒
	private static final int TEST_REMOVE_ABANDONED_TIMEOUT_MS = 1000;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 使用工厂方法创建数据源
		dataSource = ParameterTest.RemoveAbandoned_Test.RemoveAbandoned_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 开启强制回收
		dataSource.setRemoveAbandoned(true);
		// 设置 1 秒超时（注意：此参数在 Druid 中单位是毫秒）
		dataSource.setRemoveAbandonedTimeoutMillis(TEST_REMOVE_ABANDONED_TIMEOUT_MS);
		// 设置后台清理周期为 0.5s，确保它能频繁检查泄露
		dataSource.setTimeBetweenEvictionRunsMillis(500);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证泄露的连接是否被 Druid 强制回收
	 */
	@Test
	public void shouldForciblyRemoveLeakedConnection() throws Exception {
		System.out.println(">>> 开始验证 RemoveAbandoned 行为...");

		// 2. 模拟泄露：获取连接且【不关闭】
		Connection leakedConn = dataSource.getConnection();
		assertNotNull("应成功获取连接", leakedConn);
		System.out.println(">>> 成功获取连接，故意不关闭，模拟泄露中...");

		// 获取初始回收计数
		long initialCount = dataSource.getRemoveAbandonedCount();
		System.out.println(">>> 初始回收计数: " + initialCount);

		// 3. 等待足够的时间（超时 1s + 清理周期 0.5s + 缓冲 0.5s）
		System.out.println(">>> 等待后台线程执行泄露扫描 (2秒)...");
		Thread.sleep(2000);

		// 4. 获取当前的回收计数
		long currentCount = dataSource.getRemoveAbandonedCount();
		System.out.println(">>> 当前回收计数: " + currentCount);

		// --- 核心断言 ---

		// 验证回收总数是否增加
		assertTrue("错误：泄露的连接未被回收！removeAbandonedCount 应当增加。",
				currentCount > initialCount);

		// 验证连接是否已失效
		// 被强制回收的连接在物理上已经关闭，再次使用通常会报错
		System.out.println(">>> [验证通过]：Druid 检测到连接泄露并成功执行了强制回收动作。");
	}
}