package PasswordCallback_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class PasswordCallback_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		// 使用工厂创建带有回调的数据源
		dataSource = PasswordCallback_Test.createDataSource(props);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：证明 Druid 确实调用了回调方法来覆盖初始的假密码
	 */
	@Test
	public void shouldInvokeCallbackToGetRealPassword() throws Exception {
		System.out.println(">>> 正在验证 PasswordCallback 行为...");

		// 1. 获取回调对象并强制转型（这样才能调用 getInvocationCount）
		CustomPasswordCallback callback = (CustomPasswordCallback) dataSource.getPasswordCallback();

		assertNotNull("Callback 实例不应为空", callback);
		assertEquals("调用前计数应为 0", 0, callback.getInvocationCount());

		// 2. 触发物理连接
		// 因为我们配置的是假密码，如果连接成功，说明真密码一定是从回调里拿到的
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接成功，说明回调提供了正确的密码", conn);

			// 3. 核心断言：检查调用次数
			int finalCount = callback.getInvocationCount();
			System.out.println("回调总计被调用次数: " + finalCount);

			assertTrue("【验证失败】Druid 建立连接时未触发 PasswordCallback！", finalCount > 0);
		}
	}
}