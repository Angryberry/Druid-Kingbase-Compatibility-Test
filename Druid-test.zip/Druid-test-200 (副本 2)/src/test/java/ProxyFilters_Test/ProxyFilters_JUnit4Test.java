package ProxyFilters_Test;

import org.junit.Test;
import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.ProxyFilters_Test.ProxyFilters_Test;
import com.alibaba.druid.filter.Filter;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class ProxyFilters_JUnit4Test {

	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			ProxyFilters_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 Executed SQL", output.contains("Executed SQL:"));
			assertTrue(output.contains("INSERT INTO users"));
			assertTrue(output.contains("UPDATE users"));
			assertTrue(output.contains("DELETE FROM users"));
		} finally {
			System.setOut(originalOut);
		}
	}

	@Test
	public void shouldCreateDataSourceWithProxyFilters() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidDataSource ds = ProxyFilters_Test.createDataSource(props);
		try {
			List<Filter> filters = ds.getProxyFilters();
			assertNotNull("ProxyFilters 未设置", filters);
			assertEquals("过滤器数量不符合预期", ProxyFilters_Test.EXPECTED_FILTERS_COUNT, filters.size());
		} finally {
			ds.close();
		}
	}
}

