package MaxPoolPreparedStatementPerConnectionSize_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxPoolPreparedStatementPerConnectionSize_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置一个小上限，便于快速填满测试
	private static final int TEST_PER_CONN_CACHE_SIZE = 3;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxPoolPreparedStatementPerConnectionSize_Test.MaxPoolPreparedStatementPerConnectionSize_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 1. 开启语句缓存开关（这是前提）
		dataSource.setPoolPreparedStatements(true);
		// 2. 设定单连接缓存数上限
		dataSource.setMaxPoolPreparedStatementPerConnectionSize(TEST_PER_CONN_CACHE_SIZE);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证单条连接产生的缓存语句数不会超过设定上限
	 */
	@Test
	public void shouldEnforcePerConnectionStatementCacheLimit() throws Exception {
		System.out.println(">>> 开始验证 MaxPoolPreparedStatementPerConnectionSize 行为...");
		System.out.println(">>> 设定单连接缓存上限: " + TEST_PER_CONN_CACHE_SIZE);

		// 获取一条物理连接
		try (DruidPooledConnection conn = (DruidPooledConnection) dataSource.getConnection()) {

			// 1. 执行 10 条完全不同的 SQL 语句，尝试撑爆缓存
			for (int i = 1; i <= 10; i++) {
				String sql = "SELECT " + i + " AS test_val";
				try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
					// 执行一下，确保语句被放入 PSCache
					pstmt.executeQuery();
				}
			}

			// 2. 获取 Druid 内部统计的缓存总数
			// 因为 initialSize=1 且我们只用了一个连接，此值直接反映了该连接的缓存现状
			long totalCached = dataSource.getCachedPreparedStatementCount();
			System.out.println(">>> 实际物理缓存的语句总数: " + totalCached);

			// --- 核心断言 ---

			// 确认缓存功能已启用
			assertTrue("PSCache 未能正常启用", dataSource.isPoolPreparedStatements());

			// 确认缓存数量被压制在 TEST_PER_CONN_CACHE_SIZE 之内
			// Druid 会使用 LRU 算法剔除最早的 SELECT 1, SELECT 2...
			assertTrue("单连接缓存数 (" + totalCached + ") 超过了设定上限 " + TEST_PER_CONN_CACHE_SIZE,
					totalCached <= TEST_PER_CONN_CACHE_SIZE);

			System.out.println(">>> 验证成功：单连接 PSCache 严格执行了 " + TEST_PER_CONN_CACHE_SIZE + " 的容量限制。");
		}
	}
}