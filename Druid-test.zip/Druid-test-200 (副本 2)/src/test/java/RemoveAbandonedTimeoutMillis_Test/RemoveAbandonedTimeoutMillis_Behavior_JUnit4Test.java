package RemoveAbandonedTimeoutMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class RemoveAbandonedTimeoutMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设定明确的超时阈值：3000ms (3秒)
	private static final long TEST_TIMEOUT_MS = 3000;
	// 缩短扫描周期，确保能及时发现泄露
	private static final long SCAN_INTERVAL_MS = 500;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.RemoveAbandonedTimeoutMillis_Test.RemoveAbandonedTimeoutMillis_Test.createDataSource(props);

		// --- 核心行为配置 ---
		dataSource.setRemoveAbandoned(true);
		dataSource.setRemoveAbandonedTimeoutMillis(TEST_TIMEOUT_MS);
		dataSource.setTimeBetweenEvictionRunsMillis(SCAN_INTERVAL_MS);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证连接是否严格在超过设定毫秒数后才被回收
	 */
	@Test
	public void shouldOnlyRemoveConnectionAfterTimeoutThreshold() throws Exception {
		System.out.println(">>> 开始验证 RemoveAbandonedTimeoutMillis 行为...");
		System.out.println(">>> 设定超时门槛: " + TEST_TIMEOUT_MS + "ms");

		// 1. 模拟泄露：获取连接但不关闭
		Connection conn = dataSource.getConnection();
		long startTime = System.currentTimeMillis();
		System.out.println(">>> 连接已借出，开始计时...");

		// 2. 第一阶段：等待 2 秒（小于 3 秒的阈值）
		Thread.sleep(2000);
		long countAfter2s = dataSource.getRemoveAbandonedCount();
		System.out.println(">>> 等待 2s 后，回收计数: " + countAfter2s);

		// 断言：此时不应发生回收
		assertEquals("错误：未到超时时间，连接就被过早回收了！", 0, countAfter2s);

		// 3. 第二阶段：再等 2 秒（总时长达到 4s，超过 3s 阈值）
		System.out.println(">>> 继续等待 2s (累计 4s)...");
		Thread.sleep(2000);

		long countAfter4s = dataSource.getRemoveAbandonedCount();
		System.out.println(">>> 累计 4s 后，回收计数: " + countAfter4s);

		// --- 核心断言 ---

		// 验证回收行为是否发生
		assertTrue("错误：超过超时时间后，连接未被强制回收！", countAfter4s > 0);

		long duration = System.currentTimeMillis() - startTime;
		System.out.println(">>> 验证成功：连接在 " + duration + "ms 时被检测并回收，符合阈值设定。");
	}
}