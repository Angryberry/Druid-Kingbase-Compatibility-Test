package Url_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class Url_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private Properties props;

	@Before
	public void setUp() throws Exception {
		props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 正面行为验证：验证使用正确的 URL 能否成功建立物理连接
	 */
	@Test
	public void shouldConnectSuccessfullyWithCorrectUrl() throws SQLException {
		System.out.println(">>> 正在验证 URL 的正确连接行为...");
		dataSource = Url_Test.createDataSource(props);

		// 触发物理连接
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接不应为空", conn);
			assertFalse("连接应处于开启状态", conn.isClosed());
			System.out.println("成功连接至: " + dataSource.getUrl());
		}
	}

	/**
	 * 反面行为验证：故意使用一个无法访问的“黑洞 URL”
	 * 证明驱动程序确实尝试去访问了这个错误的地址
	 */
	@Test
	public void shouldFailToConnectWithInvalidUrl() {
		System.out.println(">>> 正在验证 URL 的拦截报错行为...");

		// 修改配置，指向一个不存在的端口/地址
		props.setProperty("url", "jdbc:kingbase8://192.0.2.1:12345/nonexistent");
		dataSource = Url_Test.createDataSource(props);

		long startTime = System.currentTimeMillis();
		try {
			// 这会导致驱动尝试建立 Socket 连接并最终超时
			dataSource.getConnection();
			fail("错误：使用无效 URL 理应连接失败");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("捕获到预期异常，耗时: " + duration + "ms");
			System.out.println("报错信息: " + e.getMessage());

			// 核心断言：证明错误源于网络/地址问题，而非用户名密码
			// 不同的驱动报错关键字不同，通常包含 "refused", "timeout" 或 "unreachable"
			assertTrue("报错信息应包含连接失败特征",
					e.getMessage().toLowerCase().contains("connection") ||
							e.getMessage().toLowerCase().contains("url"));
		}
	}

	/**
	 * 属性验证：保持原有的 getter 检查
	 */
	@Test
	public void verifyUrlAttributeConsistency() {
		dataSource = Url_Test.createDataSource(props);
		assertEquals("数据源中的 URL 必须与工厂配置一致",
				props.getProperty("url", Url_Test.TEST_URL), dataSource.getUrl());
	}
}