package MaxWaitThreadCount_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.io.InputStream;

import static org.junit.Assert.*;

public class MaxWaitThreadCount_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = MaxWaitThreadCount_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证当等待线程数超过 MaxWaitThreadCount 时，是否立即拒绝请求
	 */
	@Test
	public void shouldRejectImmediatelyWithOverload() throws Exception {
		// 1. 占满唯一的连接
		Connection blockConn = dataSource.getConnection();
		System.out.println("【步骤1】物理连接已占用 (Active=1)");

		int waitLimit = MaxWaitThreadCount_Test.MAX_WAIT_THREAD_COUNT; // 假设是 2
		int attackers = 10; // 派 10 个人去把门堵死，远超上限 2
		CountDownLatch readyLatch = new CountDownLatch(attackers);

		// 2. 启动大量线程去挤兑
		for (int i = 0; i < attackers; i++) {
			new Thread(() -> {
				try {
					readyLatch.countDown();
					dataSource.getConnection();
				} catch (SQLException ignored) {}
			}).start();
		}

		// 3. 轮询检查：确保队列真的已经“爆”了
		System.out.println("【步骤2】正在疯狂挤兑队列...");
		long startCheck = System.currentTimeMillis();
		// 只要等待线程数 >= 限制，就说明下一个进来的必死
		while (dataSource.getNotEmptyWaitThreadCount() < waitLimit) {
			Thread.sleep(20);
			if (System.currentTimeMillis() - startCheck > 5000) {
				fail("挤兑失败：后台线程没能把队列占满");
			}
		}

		// 给系统一点缓冲时间，确保状态稳定
		Thread.sleep(200);

		// 4. 发起测试请求
		System.out.println("【步骤3】队列已爆满，主线程发起请求...");
		long startTime = System.currentTimeMillis();
		try {
			dataSource.getConnection();
			fail("错误：队列已满，理应立即拒绝！");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("【结果】成功捕获异常！耗时: " + duration + "ms");
			System.out.println("异常详情: " + e.getMessage());

			// 验证 1: 必须瞬间拒绝（0ms - 几十ms）
			assertTrue("拒绝应该是瞬间的，实际耗时：" + duration, duration < 1000);

			// 验证 2: 修正字符串匹配逻辑，使其兼容带空格或不带空格的情况
			String msg = e.getMessage().toLowerCase();
			assertTrue("报错信息应包含 maxwaitthreadcount 相关提示",
					msg.contains("maxwaitthreadcount") || msg.contains("wait thread count"));
		}
	}
}