package KeepConnectionUnderlyingTransactionIsolation_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class KeepConnectionUnderlyingTransactionIsolation_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = KeepConnectionUnderlyingTransactionIsolation_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证连接归还后再取出，是否保留了自定义的隔离级别
	 */
	@Test
	public void shouldKeepIsolationLevelAfterRecycle() throws Exception {
		int customIsolation = Connection.TRANSACTION_SERIALIZABLE;

		// 1. 第一次获取连接，并修改隔离级别
		try (Connection conn1 = dataSource.getConnection()) {
			System.out.println("修改连接隔离级别为: SERIALIZABLE (8)");
			conn1.setTransactionIsolation(customIsolation);
			assertEquals(customIsolation, conn1.getTransactionIsolation());
		} // 此时连接归还到池中

		// 2. 第二次获取连接（由于 maxActive=1，拿到的是同一个物理连接）
		try (Connection conn2 = dataSource.getConnection()) {
			int currentIsolation = conn2.getTransactionIsolation();
			System.out.println("再次获取连接，当前隔离级别为: " + currentIsolation);

			// --- 核心断言逻辑 ---
			if (KeepConnectionUnderlyingTransactionIsolation_Test.KEEP_UNDERLYING_TX_ISOLATION) {
				// 如果参数生效，应该维持修改后的级别
				assertEquals("连接应保留之前的隔离级别而不被 Druid 重置",
						customIsolation, currentIsolation);
				System.out.println("验证成功：隔离级别被保留。");
			}
		}
	}
}