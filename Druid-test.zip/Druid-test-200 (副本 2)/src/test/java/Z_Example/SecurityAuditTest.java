package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class SecurityAuditTest {

    private SecurityAuditRunner_3 runner;

    @Before
    public void setUp() {
        runner = new SecurityAuditRunner_3();
    }

    @Test
    public void testSecurityAndLeakAudit() throws Exception {
        System.out.println("▶️ 开始金融安全场景自动化集成测试...");

        // 1. 启动
        runner.startProcess();
        DruidDataSource ds = runner.getDataSource();

        // 2. 断言 1：SQL 防火墙必须生效
        boolean isBlocked = runner.verifyWallFilter();
        assertTrue("金融级配置必须成功拦截无 WHERE 的删除操作", isBlocked);
        System.out.println("✅ 断言成功：WallFilter 防火墙防御正常。");

        // 3. 断言 2：泄露回收逻辑
        assertEquals("初始状态活跃连接应为 0", 0, ds.getActiveCount());

        runner.triggerConnectionLeak();
        assertEquals("泄露后活跃连接应为 1", 1, ds.getActiveCount());

        // 4. 自动化等待回收 (根据配置的 removeAbandonedTimeout=5s)
        System.out.println("⏳ 等待 8 秒，让 Druid 自动强制回收泄露的连接...");
        Thread.sleep(8000);

        // 5. 断言 3：连接是否被强制收回
        // 活跃连接数应该回到 0，并且被回收的连接会记入监控统计
        assertEquals("回收后活跃连接数应恢复为 0", 0, ds.getActiveCount());
        System.out.println("✅ 断言成功：Druid 已自动处决泄露连接。");
    }

    @After
    public void tearDown() {
        if (runner != null) {
            runner.stopProcess();
        }
    }
}