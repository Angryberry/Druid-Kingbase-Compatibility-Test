package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HighPerfDruidTest {

    private HighPerfDruidRunner_2 runner;

    @Before
    public void setUp() {
        runner = new HighPerfDruidRunner_2();
    }

    @Test
    public void testHighPerfFlashSaleScenario() throws Exception {
        System.out.println("▶️ 开始高并发场景自动化集成测试...");

        // 1. 启动流程
        runner.startProcess();
        DruidDataSource ds = runner.getDataSource();

        // 2. 断言 1：验证预热配置 (initialSize 应为 50)
        assertNotNull("数据源不应为空", ds);
        assertEquals("秒杀场景下，初始连接数应为 50", 50, ds.getInitialSize());
        assertEquals("启动后 PoolingCount 应立即等于 50", 50, ds.getPoolingCount());
        System.out.println("✅ 断言成功：50 条初始连接已全量预热。");

        // 3. 模拟瞬间 200 并发压力
        runner.simulateTraffic(100, 200);

        // 4. 断言 2：验证高并发后的状态
        // 峰值后活跃连接应回归，但 PoolingCount 可能因为伸缩保持在较高水平
        assertTrue("监控服务器应保持运行", runner.getJettyServer().isRunning());
        assertTrue("最大连接数应支持到 300", ds.getMaxActive() >= 300);

        // 校验是否存在连接泄露
        assertEquals("活跃连接数应归零", 0, ds.getActiveCount());
        System.out.println("✅ 断言成功：200 次秒杀请求处理完成，无连接泄露。");
    }

    @After
    public void tearDown() throws Exception {
        if (runner != null) {
            runner.stopProcess();
        }
    }
}