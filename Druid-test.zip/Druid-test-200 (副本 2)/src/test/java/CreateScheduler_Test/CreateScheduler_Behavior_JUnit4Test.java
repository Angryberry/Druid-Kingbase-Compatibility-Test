package CreateScheduler_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;
import java.util.concurrent.ScheduledExecutorService;

import static org.junit.Assert.*;

public class CreateScheduler_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = CreateScheduler_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			ScheduledExecutorService scheduler = dataSource.getCreateScheduler();
			if (scheduler != null) scheduler.shutdown();
			dataSource.close();
		}
	}

	/**
	 * 行为验证：验证自定义调度器是否成功接管了连接创建任务
	 */
	@Test
	public void shouldVerifyCustomSchedulerIsActive() throws Exception {
		System.out.println(">>> 开始验证 CreateScheduler 行为...");

		// 1. 验证对象注入
		ScheduledExecutorService scheduler = dataSource.getCreateScheduler();
		assertNotNull("CreateScheduler 应该已被成功注入", scheduler);
		assertFalse("调度器不应该已经关闭", scheduler.isShutdown());

		// 2. 核心行为验证：由于 Druid 会把创建连接的任务提交到该线程池，
		// 我们通过获取连接触发创建，并观察 Druid 内部状态（或者简单通过线程池状态判定）
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("应该能成功获取到异步创建的连接", conn);
			System.out.println("成功获取连接，底层异步调度已触发。");
		}

		// 3. 验证内部字段（确保 Druid 内部确实引用了我们的调度器）
		// 只要这个 Getter 返回的是我们在工厂类里定义的那个对象，Druid 就会在其内部循环中使用它
		assertTrue("调度器类型不匹配", scheduler.toString().contains("ScheduledThreadPoolExecutor"));
	}
}