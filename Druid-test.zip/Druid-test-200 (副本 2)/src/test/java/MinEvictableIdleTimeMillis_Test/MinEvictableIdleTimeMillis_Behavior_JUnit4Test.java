package MinEvictableIdleTimeMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class MinEvictableIdleTimeMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置便于观测的短阈值
	private static final long TEST_MIN_EVICT_MS = 2000;
	private static final long SCAN_INTERVAL_MS = 500;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 调用工厂类创建数据源
		dataSource = ParameterTest.MinEvictableIdleTimeMillis_Test.MinEvictableIdleTimeMillis_Test.createDataSource(props);

		// --- 核心行为配置：制造“多余”连接并缩短等待时间 ---
		dataSource.setInitialSize(2); // 初始 2 个
		dataSource.setMinIdle(1);    // 缩容目标 1 个

		// 设置最小空闲驱逐时间为 2s
		dataSource.setMinEvictableIdleTimeMillis(TEST_MIN_EVICT_MS);
		// 设置后台清理周期为 0.5s
		dataSource.setTimeBetweenEvictionRunsMillis(SCAN_INTERVAL_MS);

		dataSource.setValidationQuery("SELECT 1");
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证多余的空闲连接在达到 minEvictableIdleTimeMillis 后被自动销毁
	 */
	@Test
	public void shouldEvictExtraIdleConnectionsAfterTimeout() throws Exception {
		System.out.println(">>> 开始验证 MinEvictableIdleTimeMillis 行为...");
		dataSource.init();

		// 2. 初始检查：由于 initialSize=2，池里应该有 2 个连接
		int initialCount = dataSource.getPoolingCount();
		System.out.println(">>> 初始池内连接数: " + initialCount);
		assertEquals("初始连接数应等于 initialSize", 2, initialCount);

		// 3. 第一阶段：等待时间小于阈值（例如等 1s）
		System.out.println(">>> 等待 1s (未达驱逐阈值)...");
		Thread.sleep(1000);
		System.out.println(">>> 此时池内连接数: " + dataSource.getPoolingCount());
		assertEquals("未达阈值前，多余连接不应被销毁", 2, dataSource.getPoolingCount());

		// 4. 第二阶段：等待总时间超过阈值（累计等待 3s）
		// 2s(阈值) + 1s(缓冲)，确保清理线程运行
		System.out.println(">>> 继续等待直至超过 2s 阈值...");
		Thread.sleep(2500);

		int finalCount = dataSource.getPoolingCount();
		System.out.println(">>> 最终池内连接数: " + finalCount);

		// --- 核心断言 ---
		// 既然超过了 minEvictableIdleTimeMillis，那个多出的连接必须被回收
		assertEquals("多余的空闲连接应已被销毁，池内应只剩 minIdle 个连接",
				dataSource.getMinIdle(), finalCount);

		System.out.println(">>> [验证通过]：Druid 成功根据 minEvictableIdleTimeMillis 进行了缩容。");
	}
}