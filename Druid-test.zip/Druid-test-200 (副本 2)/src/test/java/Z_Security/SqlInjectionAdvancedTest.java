package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.sql.Statement;
import static org.junit.Assert.*;

public class SqlInjectionAdvancedTest {

    private DruidDataSource ds;

    @Before
    public void setUp() throws Exception {
        // 【修改点】同步工厂类新接口：不再需要布尔参数
        ds = DruidSecurityFactory.createSecurityDataSource();
    }

    /**
     * 场景 1：注释符截断与语义绕过
     */
    @Test
    public void testCommentTruncation() {
        System.out.println("🚩 [测试] 验证注释符阻断...");
        String attack = "SELECT * FROM USERS WHERE username = 'admin' --' AND status = 'ACTIVE'";
        assertAttackIsBlocked(attack, "注释符截断");
    }

    /**
     * 场景 2：数值型恒真绕过
     */
    @Test
    public void testNumericTautology() {
        System.out.println("🚩 [测试] 验证数值型恒真绕过...");
        String attack = "SELECT * FROM USERS WHERE id = 100 OR 2 > 1";
        assertAttackIsBlocked(attack, "数值恒真条件");
    }

    /**
     * 场景 3：十六进制/编码绕过
     */
    @Test
    public void testHexEncodingBypass() {
        System.out.println("🚩 [测试] 验证十六进制编码绕过...");
        String attack = "SELECT * FROM USERS WHERE username = x'61646d696e'";
        assertAttackIsBlocked(attack, "十六进制字符串");
    }

    /**
     * 场景 4：高危系统函数调用
     * 得益于工厂类中 setFunctionCheck(true) 和 DenyFunctions 的配置
     * 这一次 pg_sleep 将无法逃逸
     */
    @Test
    public void testSystemFunctionProbe() {
        System.out.println("🚩 [测试] 验证高危函数调用...");
        // 时间盲注常用技巧：让数据库“发呆” 5 秒
        String attack = "SELECT * FROM USERS WHERE id = 1 AND pg_sleep(5) IS NOT NULL";
        assertAttackIsBlocked(attack, "时间盲注函数");
    }

    /**
     * 场景 5：非法字符拼接
     */
    @Test
    public void testSpecialCharConcatenation() {
        System.out.println("🚩 [测试] 验证字符拼接注入...");
        String attack = "SELECT * FROM USERS WHERE username = 'adm' || 'in'";
        assertAttackIsBlocked(attack, "非法字符拼接");
    }

    /**
     * 辅助工具：模拟执行攻击并断言失败
     */
    private void assertAttackIsBlocked(String sql, String type) {
        try (DruidPooledConnection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute(sql);
            // 如果代码执行到这一行，说明拦截失败，测试不通过
            fail("❌ 安全漏洞：未拦截场景 [" + type + "]");

        } catch (Exception e) {
            // 预期结果：进入 catch 块，并打印出 Druid 的正义执行日志
            System.out.println("🛡️ [拦截成功] 场景: " + type + " -> 拦截详情: " + e.getMessage());
            // 只要捕获到异常（注入违规），测试就视为通过
            assertTrue(true);
        }
    }

    @After
    public void tearDown() {
        if (ds != null) {
            ds.close();
        }
    }
}