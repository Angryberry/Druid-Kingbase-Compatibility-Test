package MaxWait_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.GetConnectionTimeoutException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxWait_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置便于测试的阈值
	private static final int TEST_MAX_ACTIVE = 2;
	private static final long TEST_MAX_WAIT = 2000; // 等待 2000ms

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxWait_Test.MaxWait_Test.createDataSource(props);

		// --- 核心行为配置 ---
		dataSource.setMaxActive(TEST_MAX_ACTIVE);
		dataSource.setMaxWait(TEST_MAX_WAIT); // 设置我们的测试目标值

		dataSource.setInitialSize(TEST_MAX_ACTIVE);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证在资源耗尽时，线程是否真的等待了 maxWait 毫秒
	 */
	@Test
	public void shouldWaitExactlyMaxWaitBeforeTimeout() throws SQLException {
		System.out.println(">>> 开始验证 MaxWait 行为...");
		System.out.println(">>> 设定等待时间: " + TEST_MAX_WAIT + " ms");

		List<Connection> leakConnections = new ArrayList<>();

		try {
			// 1. 占满连接池
			for (int i = 0; i < TEST_MAX_ACTIVE; i++) {
				leakConnections.add(dataSource.getConnection());
			}
			System.out.println(">>> 连接池已占满，活跃连接数: " + dataSource.getActiveCount());

			// 2. 发起溢出请求并计时
			long startTime = System.currentTimeMillis();
			try {
				System.out.println(">>> 正在发起第 " + (TEST_MAX_ACTIVE + 1) + " 个连接请求，预期等待 " + TEST_MAX_WAIT + "ms...");
				dataSource.getConnection();
				fail("错误：超过 maxActive 后未发生等待或报错，限制失效！");
			} catch (GetConnectionTimeoutException e) {
				// 3. 验证时间偏差
				long duration = System.currentTimeMillis() - startTime;
				System.out.println(">>> 实际等待时长: " + duration + " ms");

				// --- 核心断言 ---
				// 允许 10% 的系统调度误差，但绝不应小于设定值
				assertTrue("等待时长 (" + duration + ") 应该大于等于设定值 " + TEST_MAX_WAIT,
						duration >= TEST_MAX_WAIT - 100);

				System.out.println(">>> [验证通过]：MaxWait 参数成功让线程进入了预期的等待状态。");
			}
		} finally {
			// 释放连接
			for (Connection c : leakConnections) {
				try { c.close(); } catch (SQLException ignored) {}
			}
		}
	}
}