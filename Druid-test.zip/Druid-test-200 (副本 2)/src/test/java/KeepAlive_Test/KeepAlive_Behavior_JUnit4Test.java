package KeepAlive_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class KeepAlive_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 获取你在 KeepAlive_Test 类中定义的常量
	private static final boolean EXPECTED_KEEP_ALIVE = ParameterTest.KeepAlive_Test.KeepAlive_Test.KEEP_ALIVE_ENABLED;

	@Before
	public void setUp() throws Exception {
		// 1. 【关键】必须先定义并初始化 props 变量
		Properties props = new Properties();

		// 2. 加载配置文件
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) {
				props.load(in);
			} else {
				System.err.println("警告：未找到 druid.properties，将使用默认配置。");
			}
		}

		// 3. 调用工厂方法创建数据源
		dataSource = ParameterTest.KeepAlive_Test.KeepAlive_Test.createDataSource(props);

		// 4. 配置保活参数（满足之前的报错约束：keepAliveBetweenTimeMillis > timeBetweenEvictionRunsMillis）
		dataSource.setKeepAlive(true);
		dataSource.setValidationQuery("SELECT 1");
		dataSource.setTestWhileIdle(true);

		// 后台清理线程每 1 秒运行一次
		dataSource.setTimeBetweenEvictionRunsMillis(1000);
		// 保活检查间隔设为 1.1 秒（略大于清理周期），绕过 Druid 校验
		dataSource.setKeepAliveBetweenTimeMillis(1100);

		dataSource.setMinIdle(1);
		dataSource.setInitialSize(1);
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			dataSource.close();
		}
	}

	/**
	 * 行为验证：验证在一段时间后，keepAliveCheckCount 是否增加
	 */
	@Test
	public void shouldIncreaseKeepAliveCheckCountOverTime() throws Exception {
		System.out.println("开始验证 keepAlive 行为...");
		dataSource.init();

		// 1. 【关键改进】热身：获取一次连接再归还
		// 刚初始化的连接可能被视为“新连接”，归还动作能明确刷新它的“最后活跃时间”
		dataSource.getConnection().close();

		// 2. 获取保活检查计数 (使用更稳健的获取方式)
		long initialCheckCount = getKeepAliveCount(dataSource);
		System.out.println("初始保活检查计数: " + initialCheckCount);

		// 3. 等待足够的时间
		// 清理周期 1s，保活门槛 1.1s。等待 5s 理论上会有 3-4 次“撞线”机会
		System.out.println("等待后台线程执行探测...");
		Thread.sleep(6000);

		long currentCheckCount = getKeepAliveCount(dataSource);
		System.out.println("当前保活检查计数: " + currentCheckCount);

		// --- 核心断言 ---
		assertTrue("保活检查计数应当增加。如果为 0，说明后台线程未认为连接已'空闲'到需要保活的程度。",
				currentCheckCount > initialCheckCount);
	}

	/**
	 * 兼容性方法：尝试多种方式获取保活计数
	 */
	private long getKeepAliveCount(DruidDataSource ds) {
		// 优先尝试直接获取（即使 IDE 报错，只要编译器能过就可以）
		try {
			return ds.getDataSourceStat().getKeepAliveCheckCount();
		} catch (NoSuchMethodError e) {
			// 如果方法真的不存在，尝试从 Druid 的 Map 统计信息中抓取
			Object val = ds.getStatValueAndReset();
			return val instanceof Long ? (Long) val : 0L;
		}
	}
}