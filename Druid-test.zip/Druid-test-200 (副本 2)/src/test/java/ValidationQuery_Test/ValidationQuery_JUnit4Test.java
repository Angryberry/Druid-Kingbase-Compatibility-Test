package ValidationQuery_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class ValidationQuery_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			props.load(in);
		}

		// 1. 调用工厂方法
		dataSource = ValidationQuery_Test.createDataSource(props);

		// 2. 初始状态：先设为正常 SQL，确保池子能初始化成功
		dataSource.setValidationQuery("SELECT 1");
		dataSource.setTestOnBorrow(true);
		forceSetThreshold(dataSource, -1L); // 强制校验，不跳过

		dataSource.setInitialSize(1);
		dataSource.setMaxActive(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：通过切换 SQL 验证校验逻辑是否真正运行
	 */
	@Test
	public void shouldDiscardConnectionWhenValidationQueryIsInvalid() throws Exception {
		System.out.println(">>> 开始验证 validationQuery 行为...");

		// 1. 先确保池里有一个正常的连接
		Connection connValid = dataSource.getConnection();
		connValid.close();

		long initialDiscardCount = dataSource.getDiscardCount();

		// 2. 【核心注入】切换为错误的校验 SQL
		// 这样下次借出时，Druid 执行此 SQL 必报错
		dataSource.setValidationQuery("SELECT 1 FROM non_existent_table_999");

		System.out.println(">>> 正在借出连接（预期触发 SQL 错误并丢弃连接）...");
		try {
			// 设置获取等待，防止死等
			dataSource.setMaxWait(1000);
			dataSource.getConnection();
		} catch (Exception e) {
			System.out.println(">>> 成功捕获到校验失败报错。");
		} finally {
			// 【关键】：立刻恢复正常的 SQL，否则后台创建线程会一直报错刷屏
			dataSource.setValidationQuery("SELECT 1");
		}

		// 3. 断言验证
		long finalDiscardCount = dataSource.getDiscardCount();
		System.out.println(">>> 最终丢弃计数 (DiscardCount): " + finalDiscardCount);

		assertTrue("validationQuery 未能触发丢弃逻辑！", finalDiscardCount > initialDiscardCount);
		System.out.println(">>> [验证通过]：Druid 成功执行了错误的校验 SQL 并清理了坏连接。");
	}

	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			ValidationQuery_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 Executed SQL", output.contains("Executed SQL:"));
		} finally {
			System.setOut(originalOut);
		}
	}

	private void forceSetThreshold(DruidDataSource ds, long value) {
		Class<?> clazz = ds.getClass();
		while (clazz != null) {
			for (java.lang.reflect.Field field : clazz.getDeclaredFields()) {
				String name = field.getName().toLowerCase();
				if (name.contains("borrow") && name.contains("threshold")) {
					try {
						field.setAccessible(true);
						field.set(ds, value);
					} catch (Exception ignored) {}
				}
			}
			clazz = clazz.getSuperclass();
		}
	}
}