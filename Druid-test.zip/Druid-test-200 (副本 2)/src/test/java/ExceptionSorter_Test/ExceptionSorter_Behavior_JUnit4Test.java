package ExceptionSorter_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.pool.ExceptionSorter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

import static org.junit.Assert.*;

public class ExceptionSorter_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 假设这是你自定义分类器识别的致命状态码
	private static final String FATAL_STATE = "08006";

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) {
				props.load(in);
			}
		}

		// 使用你原本的工厂方法创建数据源
		// 确保该方法里执行了：dataSource.setExceptionSorter(new YourCustomSorter());
		dataSource = ParameterTest.ExceptionSorter_Test.ExceptionSorter_Test.createDataSource(props);

		// 补全基础配置
		dataSource.setValidationQuery("SELECT 1");
		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			dataSource.close();
		}
	}

	/**
	 * 行为验证：当触发致命异常时，Druid 应该剔除连接
	 */
	@Test
	public void shouldDiscardConnectionWhenFatalExceptionOccurs() throws SQLException {
		// 1. 获取你类中定义的真实致命状态码
		// 注意：这里要确保引用的是你 ExceptionSorter_Test 里定义的那个常量
		String expectedFatalState = ParameterTest.ExceptionSorter_Test.ExceptionSorter_Test.FATAL_SQL_STATE;

		System.out.println("开始验证 ExceptionSorter 行为...");
		System.out.println("预期致命状态码: " + expectedFatalState);

		// 2. 检查数据源是否真的配置了 Sorter
		ExceptionSorter sorter = dataSource.getExceptionSorter();
		System.out.println("当前使用的 Sorter 类型: " + (sorter != null ? sorter.getClass().getName() : "null"));

		long initialDiscardCount = dataSource.getDiscardCount();

		// 3. 获取连接并模拟异常
		try (DruidPooledConnection conn = (DruidPooledConnection) dataSource.getConnection()) {
			// 先手动验证一下 Sorter 到底认不认这个异常
			SQLException fatalEx = new SQLException("模拟致命异常", expectedFatalState);
			boolean isFatal = sorter != null && sorter.isExceptionFatal(fatalEx);
			System.out.println("Sorter 判定结果 (isExceptionFatal): " + isFatal);

			// 4. 触发 Druid 的异常处理逻辑
			try {
				conn.handleException(fatalEx);
			} catch (SQLException e) {
				// 忽略抛出的异常
			}

			// 5. 验证计数
			// 给 Druid 一点点时间处理异步逻辑（虽然通常是同步的）
			long currentDiscardCount = dataSource.getDiscardCount();
			System.out.println("最终丢弃计数: " + currentDiscardCount);

			// --- 核心断言 ---
			assertTrue("Sorter 判定为非致命，请检查 FATAL_SQL_STATE 是否匹配", isFatal);
			assertTrue("连接未被剔除，discardCount 没有增加", currentDiscardCount > initialDiscardCount);
		}
	}

	/**
	 * 对照验证：普通异常不应导致连接被剔除
	 */
	@Test
	public void shouldNOTDiscardConnectionWhenNormalExceptionOccurs() throws SQLException {
		long initialDiscardCount = dataSource.getDiscardCount();

		try (DruidPooledConnection conn = (DruidPooledConnection) dataSource.getConnection()) {
			// 模拟一个普通异常（例如语法错误 42000）
			SQLException normalEx = new SQLException("语法错误", "42000");

			try {
				conn.handleException(normalEx);
			} catch (SQLException e) {}

			assertEquals("普通异常不应导致连接被剔除",
					initialDiscardCount, dataSource.getDiscardCount());
		}
	}
}