package Z_Plugins_Test;

import org.junit.Test;
import ParameterTest.Plugins_Test.WallFilter_Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class WallFilter_JUnit4Test {

	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			WallFilter_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 WallFilter 相关信息", output.contains("WallFilter") || output.contains("wall"));
		} finally {
			System.setOut(originalOut);
		}
	}

	@Test
	public void shouldCreateWallProvider() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		// 测试工厂方法
		com.alibaba.druid.wall.WallConfig config = new com.alibaba.druid.wall.WallConfig();
		com.alibaba.druid.wall.spi.KingbaseWallProvider provider = WallFilter_Test.createWallProvider(config);
		assertNotNull("WallProvider 应该被创建", provider);
	}
}
