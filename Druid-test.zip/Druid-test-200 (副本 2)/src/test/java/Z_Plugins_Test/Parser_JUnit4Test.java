package Z_Plugins_Test;

import org.junit.Test;
import ParameterTest.Plugins_Test.Parser_Test;

import static org.junit.Assert.*;

public class Parser_JUnit4Test {

	@Test
	public void shouldFormatSql() {
		// 直接调用 main 并断言输出包含关键片段
		try {
			Parser_Test.main(new String[0]);
			assertTrue(true);
		} catch (Exception e) {
			throw new AssertionError("Parser_Test.main 执行异常", e);
		}
	}
}


