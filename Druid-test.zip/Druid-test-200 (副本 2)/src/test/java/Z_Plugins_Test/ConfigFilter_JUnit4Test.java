package Z_Plugins_Test;

import org.junit.Test;
import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.Plugins_Test.ConfigFilter_Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class ConfigFilter_JUnit4Test {

	@Test
	public void shouldInitWithConfigFilter() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidDataSource ds = ConfigFilter_Test.createDataSource(props);
		try {
			ds.init();
			assertTrue(true);
		} finally {
			ds.close();
		}
	}
}


