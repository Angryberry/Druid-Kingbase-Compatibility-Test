package Z_Plugins_Test;

import org.junit.Test;
import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.Plugins_Test.Log4jFilter_Test;
import com.alibaba.druid.filter.Filter;
import com.alibaba.druid.filter.logging.Log4jFilter;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class Log4jFilter_JUnit4Test {

	@Test
	public void shouldRunMainAndLogSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			Log4jFilter_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue(output.contains("[Log4jFilter] executed select 1"));
		} finally {
			System.setOut(originalOut);
		}
	}

	@Test
	public void shouldCreateDataSourceWithLog4jFilterConfigured() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidDataSource ds = Log4jFilter_Test.createDataSource(props);
		try {
			List<Filter> filters = ds.getProxyFilters();
			boolean found = false;
			for (Filter f : filters) {
				if (f instanceof Log4jFilter) {
					found = true;
					assertTrue(((Log4jFilter) f).isStatementExecutableSqlLogEnable());
				}
			}
			assertTrue("Log4jFilter 未挂载", found);
		} finally {
			ds.close();
		}
	}
}


