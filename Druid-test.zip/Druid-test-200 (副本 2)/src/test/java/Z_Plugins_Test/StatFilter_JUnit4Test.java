package Z_Plugins_Test;

import org.junit.Test;
import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.Plugins_Test.StatFilter_Test;
import com.alibaba.druid.filter.Filter;
import com.alibaba.druid.filter.stat.StatFilter;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class StatFilter_JUnit4Test {

	@Test
	public void shouldRunMainAndPrintResult() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			StatFilter_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue(output.contains("[StatFilter] result:"));
		} finally {
			System.setOut(originalOut);
		}
	}

	@Test
	public void shouldCreateDataSourceWithStatFilterConfigured() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidDataSource ds = StatFilter_Test.createDataSource(props);
		try {
			List<Filter> filters = ds.getProxyFilters();
			boolean found = false;
			for (Filter f : filters) {
				if (f instanceof StatFilter) {
					found = true;
					assertEquals(StatFilter_Test.SLOW_SQL_MILLIS, ((StatFilter) f).getSlowSqlMillis());
				}
			}
			assertTrue("StatFilter 未挂载", found);
		} finally {
			ds.close();
		}
	}
}


