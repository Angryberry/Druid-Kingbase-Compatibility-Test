package Z_Plugins_Test;

import org.junit.Test;
import com.alibaba.druid.pool.xa.DruidXADataSource;
import ParameterTest.Plugins_Test.XAUtil_Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class XAUtil_JUnit4Test {

	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			XAUtil_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 XAUtil 相关信息", output.contains("XAUtil") || output.contains("XA"));
		} finally {
			System.setOut(originalOut);
		}
	}

	@Test
	public void shouldCreateXADataSource() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidXADataSource xaDs = XAUtil_Test.createXADataSource(props);
		try {
			assertNotNull("XADataSource 应该被创建", xaDs);
			assertEquals("dbType 未按预期生效", XAUtil_Test.DEFAULT_DB_TYPE, xaDs.getDbType());
		} finally {
			xaDs.close();
		}
	}
}
