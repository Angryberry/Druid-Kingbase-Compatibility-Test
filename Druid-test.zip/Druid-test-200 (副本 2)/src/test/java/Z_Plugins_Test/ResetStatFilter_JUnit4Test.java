package Z_Plugins_Test;

import org.junit.Test;
import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.Plugins_Test.ResetStatFilter_Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class ResetStatFilter_JUnit4Test {

	@Test
	public void shouldResetStat() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}
		DruidDataSource ds = ResetStatFilter_Test.createDataSource(props);
		try {
			ds.init();
			int before = ds.getActiveCount();
			ds.resetStat();
			int after = ds.getActiveCount();
			assertEquals(before, after);
		} finally {
			ds.close();
		}
	}
}


