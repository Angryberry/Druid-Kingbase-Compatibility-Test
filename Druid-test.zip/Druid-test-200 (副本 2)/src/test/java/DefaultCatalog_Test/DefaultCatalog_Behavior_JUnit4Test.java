package DefaultCatalog_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class DefaultCatalog_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = DefaultCatalog_Test.createDataSource(props);
		// 初始化池
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：证明从 Druid 获取的连接已经自动切换到了指定的 Catalog
	 */
	@Test
	public void shouldApplyDefaultCatalogToNewConnection() throws Exception {
		System.out.println(">>> 正在验证 DefaultCatalog 自动切换行为...");

		// 1. 从池中获取连接
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接不应为空", conn);

			// 2. 核心行为断言：
			// 检查连接目前的 Catalog 是否等于我们在工厂里设置的那个值
			String actualCatalog = conn.getCatalog();
			System.out.println("连接当前的 Catalog 是: " + actualCatalog);

			assertEquals("【验证失败】：连接未自动切换到预设的 Catalog！",
					DefaultCatalog_Test.EXPECTED_CATALOG, actualCatalog);

			System.out.println("【验证成功】：Druid 已成功在借出连接时自动应用了 Catalog 配置。");
		}
	}

	/**
	 * 属性一致性验证
	 */
	@Test
	public void verifyCatalogProperty() {
		assertEquals("数据源属性中的 Catalog 必须与配置一致",
				DefaultCatalog_Test.EXPECTED_CATALOG, dataSource.getDefaultCatalog());
	}
}