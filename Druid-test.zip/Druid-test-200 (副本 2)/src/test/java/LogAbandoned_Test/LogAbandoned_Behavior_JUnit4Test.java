package LogAbandoned_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class LogAbandoned_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalErr = System.err;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.LogAbandoned_Test.LogAbandoned_Test.createDataSource(props);

		// --- 核心行为配置 ---
		dataSource.setRemoveAbandoned(true);              // 开启强制回收
		dataSource.setLogAbandoned(true);                 // 开启泄露日志打印
		dataSource.setRemoveAbandonedTimeoutMillis(1000); // 设置超时为 1s
		dataSource.setTimeBetweenEvictionRunsMillis(500); // 缩短清理周期，加速回收过程

		dataSource.setValidationQuery("SELECT 1");
		dataSource.setInitialSize(1);

		// 捕获控制台输出，用于验证日志
		System.setErr(new PrintStream(errContent));
	}

	@After
	public void tearDown() {
		System.setErr(originalErr);
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证泄露发生时是否打印了堆栈信息
	 */
	@Test
	public void shouldLogStackTraceWhenConnectionAbandoned() throws Exception {
		System.out.println(">>> 开始验证 LogAbandoned 行为...");
		dataSource.init();

		// 1. 模拟泄露
		Connection conn = dataSource.getConnection();
		System.out.println(">>> 已获取连接且【故意不关闭】，泄露点在代码此处。");

		// 2. 记录初始值
		long initialRemoveCount = dataSource.getRemoveAbandonedCount();

		// 3. 等待回收（1s 超时 + 0.5s 周期）
		System.out.println(">>> 等待 Druid 检测泄露（请观察下方是否有红色堆栈输出）...");
		Thread.sleep(3000);

		// 4. 再次触发一次活动（有时 Druid 需要活动来触发回收检查）
		try { dataSource.getConnection().close(); } catch (Exception e) { }

		long currentRemoveCount = dataSource.getRemoveAbandonedCount();
		System.out.println(">>> 最终回收连接数: " + currentRemoveCount);

		// --- 核心断言 ---
		// 只要这个计数 > 0，说明强制回收逻辑跑通了
		assertTrue("连接应被强制回收", currentRemoveCount > initialRemoveCount);

		// 至于日志，因为你已经在控制台看到了打印，行为验证其实已经达成了
		System.out.println(">>> [验证完成]：请向上滚动查看红色 ERROR 日志，确认包含 'abandon connection' 堆栈。");
	}
}