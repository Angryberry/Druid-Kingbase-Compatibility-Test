package ConnectionProperties_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class ConnectionProperties_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = ConnectionProperties_Test.createDataSource(props);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证 Druid 内部是否成功将字符串解析为了 Properties 对象
	 * 如果之前的 String.valueOf(props) Bug 存在，这里的 assertEquals 会报错
	 */
	@Test
	public void shouldParseConnectionPropertiesIntoInternalMap() throws Exception {
		System.out.println(">>> 正在验证 ConnectionProperties 解析行为...");

		// 必须 init 才能触发解析逻辑
		dataSource.init();

		// 获取 Druid 内部解析后的结果
		Properties internalProps = dataSource.getConnectProperties();

		assertNotNull("解析后的内部属性对象不应为空", internalProps);

		// 验证具体属性是否生效
		assertEquals("UTF-8", internalProps.getProperty("characterEncoding"));
		assertEquals("false", internalProps.getProperty("useSSL"));
		assertEquals("UTC", internalProps.getProperty("serverTimezone"));

		System.out.println("【验证成功】：Druid 已成功解析分号分隔的连接属性字符串。");
	}

	/**
	 * 物理测试：证明带上这些扩展参数后，物理连接仍然畅通
	 */
	@Test
	public void shouldMaintainPhysicalConnectionWithProperties() throws Exception {
		try (java.sql.Connection conn = dataSource.getConnection()) {
			assertNotNull("带有扩展属性的连接应成功获取", conn);
			assertFalse("连接应处于活跃状态", conn.isClosed());
		}
	}
}