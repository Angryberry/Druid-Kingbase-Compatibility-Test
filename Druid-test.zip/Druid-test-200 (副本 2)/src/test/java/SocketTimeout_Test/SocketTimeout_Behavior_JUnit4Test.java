package SocketTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.*;

import static org.junit.Assert.*;

public class SocketTimeout_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设定 Socket 超时阈值：2000 毫秒
	private static final int TEST_SOCKET_TIMEOUT_MS = 2000;
	// 使用 RFC 定义的测试保留 IP，模拟无响应的网络环境
	private static final String BLACK_HOLE_URL = "jdbc:kingbase8://192.0.2.1:54321/test";

	@Before
	public void setUp() throws Exception {
		// 1. 先实例化对象，否则后面所有 dataSource.xxx 都会报空指针
		dataSource = new DruidDataSource();

		// 2. 加载配置（用于获取驱动名等）
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 3. 基础必要配置
		dataSource.setDriverClassName(props.getProperty("driverClassName", "com.kingbase8.Driver"));
		dataSource.setUrl(BLACK_HOLE_URL);
		dataSource.setUsername("test");
		dataSource.setPassword("test");

		// 4. --- 关键修正：禁止任何形式的重试 ---
		dataSource.setConnectionErrorRetryAttempts(0); // 刚才在这报错，现在没问题了
		dataSource.setBreakAfterAcquireFailure(true);
		dataSource.setMaxWait(4000);

		// 5. --- 驱动属性设置 ---
		dataSource.setConnectionProperties("connectTimeout=3;socketTimeout=3");

		// 6. 额外优化
		dataSource.setTestWhileIdle(false);
		dataSource.setInitialSize(0); // 设为 0，防止 init() 时就因为连不上而卡死在 setUp 里

		// 7. 最后手动初始化
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证当网络发生“静默挂起”时，SocketTimeout 是否能及时掐断连接
	 */
	@Test
	public void shouldBreakConnectionWhenSocketIsSilent() throws Exception {
		System.out.println(">>> 开始验证超时行为...");
		long startTime = System.currentTimeMillis();

		ExecutorService executor = Executors.newSingleThreadExecutor();
		Future<Void> future = executor.submit(() -> {
			dataSource.getConnection(); // 此时应该很快就抛出 SQLException
			return null;
		});

		try {
			// 给 15 秒，确保 Druid 有足够时间把异常抛出来，而不是被 Future 掐死
			future.get(15, TimeUnit.SECONDS);
			fail("不应连接成功");
		} catch (ExecutionException e) {
			long duration = System.currentTimeMillis() - startTime;
			double durationSec = duration / 1000.0;
			System.out.println(">>> 捕获到异常，耗时: " + String.format("%.2f", durationSec) + " 秒");

			// --- 核心断言 ---
			// 既然我们禁用了重试，耗时应该在 3s 到 5s 之间
			assertTrue("超时参数未生效，耗时太长: " + durationSec, durationSec < 7.0);
			assertTrue("报错太快，可能不是超时引起: " + durationSec, durationSec > 2.5);

			System.out.println(">>> [验证通过]：超时参数已成功约束驱动行为，且无多余重试。");
		} finally {
			executor.shutdownNow();
		}
	}
}