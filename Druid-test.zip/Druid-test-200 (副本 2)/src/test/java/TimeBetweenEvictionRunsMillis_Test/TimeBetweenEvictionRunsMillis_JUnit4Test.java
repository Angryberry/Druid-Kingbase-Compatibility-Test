package TimeBetweenEvictionRunsMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class TimeBetweenEvictionRunsMillis_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}

		// 1. 调用工厂方法
		dataSource = TimeBetweenEvictionRunsMillis_Test.createDataSource(props);

		// 2. --- 行为验证配置 ---
		// 设置后台清理周期为 500ms
		dataSource.setTimeBetweenEvictionRunsMillis(500);
		// 设置连接只要空闲 100ms 就算过期，方便触发清理
		dataSource.setMinEvictableIdleTimeMillis(100);

		dataSource.setInitialSize(1);
		dataSource.setMaxActive(1);

		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证后台清理线程是否真的在运行
	 */
	@Test
	public void shouldEvictConnectionBasedOnTimer() throws Exception {
		System.out.println(">>> 开始验证 TimeBetweenEvictionRunsMillis 行为...");

		// 1. 借出一个连接并立刻归还，使其进入空闲状态
		Connection conn = dataSource.getConnection();
		conn.close();
		System.out.println(">>> 连接已进入空闲状态，等待后台线程清理...");

		long initialDestroyCount = dataSource.getDestroyCount();

		// 2. 等待时间：必须大于 timeBetweenEvictionRunsMillis + 缓冲时间
		// 我们设的是 500ms，这里等 1500ms 确保线程至少跑了 2-3 次
		Thread.sleep(1500);

		long finalDestroyCount = dataSource.getDestroyCount();
		System.out.println(">>> 初始销毁数: " + initialDestroyCount + ", 当前销毁数: " + finalDestroyCount);

		// 3. 断言：如果后台线程在干活，销毁数应该增加
		assertTrue("清理线程未按预期周期运行或未销毁过期连接", finalDestroyCount > initialDiscardCount());

		System.out.println(">>> [验证通过]：后台清理线程运行正常。");
	}

	private long initialDiscardCount() {
		return dataSource.getDiscardCount();
	}

	/**
	 * 原有逻辑：验证 Main 方法运行
	 */
	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			TimeBetweenEvictionRunsMillis_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 Executed SQL", output.contains("Executed SQL:"));
		} finally {
			System.setOut(originalOut);
		}
	}
}