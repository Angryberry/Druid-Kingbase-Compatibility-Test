package NotFullTimeoutRetryCount_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class NotFullTimeoutRetryCount_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = NotFullTimeoutRetryCount_Test.createDataSource(props);

		// --- 关键修改 ---
		dataSource.setMaxActive(5);        // 确保池子“不满”
		dataSource.setInitialSize(0);     // 初始不创建连接
		dataSource.setMaxWait(1000);      // 单词获取超时 1s

		// 故意设置一个错误的密码，让物理连接创建失败
		dataSource.setPassword("wrong_password");

		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：通过获取连接的超时总时间来验证重试次数是否生效
	 */
	@Test
	public void shouldObserveRetryOnNotFullPool() throws Exception {
		// 确保池子现在是空的，且 active < maxActive
		assertEquals(0, dataSource.getActiveCount());
		assertTrue(dataSource.getActiveCount() < dataSource.getMaxActive());

		long startTime = System.currentTimeMillis();
		try {
			System.out.println("开始尝试获取连接（池未满但配置错误，预期将触发重试）...");
			dataSource.getConnection();
			fail("由于密码错误，理应获取失败");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("实际等待耗时: " + duration + "ms");

			// 因为池子未满，Druid 会在失败后进行重试
			// 预期耗时 ≈ maxWait * (retryCount + 1)
			int retryCount = dataSource.getNotFullTimeoutRetryCount();
			long expectedMinDuration = dataSource.getMaxWait() * retryCount;

			assertTrue("实际耗时 (" + duration + "ms) 应该体现出多次重试的累加",
					duration >= expectedMinDuration);

			System.out.println("行为验证成功：检测到重试导致的延迟累加。");
		}
	}
}