package DbType_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.util.JdbcConstants;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class DbType_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = DbType_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证 Druid 是否正确识别并应用了指定的 dbType
	 */
	@Test
	public void shouldVerifyInternalDialectMapping() throws Exception {
		System.out.println(">>> 开始验证 dbType 方言映射行为...");

		// 1. 获取连接触发初始化
		try (Connection conn = dataSource.getConnection()) {
			assertNotNull("连接获取失败", conn);
		}

		// 2. 检查数据源生效的 dbType
		String effectiveDbType = dataSource.getDbType();
		System.out.println("数据源当前生效的 dbType: " + effectiveDbType);

		assertEquals("手动配置的 dbType 未能生效", DbType_Test.DB_TYPE, effectiveDbType);

		// 3. 【修正点】对比时将 DbType 对象转换为 String
		if ("kingbase".equalsIgnoreCase(DbType_Test.DB_TYPE)) {
			// 使用 .toString() 或 .name() 将 DbType 对象转为字符串
			assertEquals("实际生效类型应与 Druid 官方 Kingbase 常量一致",
					JdbcConstants.KINGBASE.toString().toLowerCase(),
					effectiveDbType.toLowerCase());

			System.out.println("【验证通过】：Druid 已确认采用 Kingbase 方言解析器。");
		}
	}
}