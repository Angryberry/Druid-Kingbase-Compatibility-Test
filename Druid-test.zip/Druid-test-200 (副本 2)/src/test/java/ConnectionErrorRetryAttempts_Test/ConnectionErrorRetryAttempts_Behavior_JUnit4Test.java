package ConnectionErrorRetryAttempts_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class ConnectionErrorRetryAttempts_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ConnectionErrorRetryAttempts_Test.createDataSource(props);

		// --- 核心破坏动作：设置一个错误的端口，诱发物理连接失败 ---
		dataSource.setUrl("jdbc:kingbase8://localhost:9999/non_exist_db");
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证连接出错后是否真的执行了指定次数的重试
	 */
	@Test
	public void shouldRetrySpecifiedTimesOnConnectError() {
		long startTime = System.currentTimeMillis();

		try {
			System.out.println("开始获取连接（预期将重试 " +
					ConnectionErrorRetryAttempts_Test.CONNECTION_ERROR_RETRY_ATTEMPTS + " 次）...");
			dataSource.getConnection();
			fail("理应获取失败");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("最终捕获异常，总耗时: " + duration + "ms");

			// --- 核心断言逻辑 ---
			// 预期耗时下限 = 重试次数 * 每次重试间隔
			long retryInterval = dataSource.getTimeBetweenConnectErrorMillis();
			int retryAttempts = ConnectionErrorRetryAttempts_Test.CONNECTION_ERROR_RETRY_ATTEMPTS;
			long expectedMinDuration = retryInterval * retryAttempts;

			assertTrue("实际耗时 (" + duration + "ms) 未达到预期的重试累积时间 (" + expectedMinDuration + "ms)，说明未足额重试",
					duration >= expectedMinDuration);

			System.out.println("行为验证成功：耗时证明了 Druid 执行了多次重试。");
		}
	}
}