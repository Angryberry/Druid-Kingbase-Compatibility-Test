package MaxOpenPreparedStatements_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxOpenPreparedStatements_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设定一个较小的缓存上限用于测试
	private static final int TEST_CACHE_SIZE = 5;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxOpenPreparedStatements_Test.MaxOpenPreparedStatements_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 1. 必须开启 PSCache 开关
		dataSource.setPoolPreparedStatements(true);
		// 2. 设置每个连接缓存的语句数
		dataSource.setMaxOpenPreparedStatements(TEST_CACHE_SIZE);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证当执行大量不同 SQL 时，缓存的语句数不会超过上限
	 */
	@Test
	public void shouldLimitCachedStatementsPerConnection() throws Exception {
		System.out.println(">>> 开始验证 MaxOpenPreparedStatements 行为...");
		System.out.println(">>> 设定缓存上限: " + TEST_CACHE_SIZE);

		// 1. 获取一个物理连接
		try (DruidPooledConnection conn = (DruidPooledConnection) dataSource.getConnection()) {

			// 2. 执行超过缓存上限的不同 SQL 语句
			// 我们执行 10 个不同的 SQL，但缓存上限只有 5
			for (int i = 1; i <= 10; i++) {
				String sql = "SELECT " + i;
				try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
					pstmt.executeQuery();
				}
			}

			// 3. 获取当前数据源缓存的语句总数
			// 注意：由于只有 1 个连接，总缓存数应等于该连接的缓存数
			long cachedCount = dataSource.getCachedPreparedStatementCount();
			System.out.println(">>> 当前已缓存的语句总数: " + cachedCount);

			// --- 核心断言 ---

			// 验证 PSCache 是否真的在工作
			assertTrue("PSCache 应该处于开启状态", dataSource.isPoolPreparedStatements());

			// 验证缓存数量是否被压制在上限之内
			// Druid 的 LRU 策略会自动剔除旧的语句
			assertTrue("缓存的语句数 (" + cachedCount + ") 不应超过上限 " + TEST_CACHE_SIZE,
					cachedCount <= TEST_CACHE_SIZE);

			System.out.println(">>> 验证成功：PSCache 严格遵守了 " + TEST_CACHE_SIZE + " 的容量限制。");
		}
	}
}