package FailFast_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class FailFast_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = FailFast_Test.createDataSource(props);

		// --- 【核心修改】改用 localhost 和一个没开的随机端口 ---
		// 这样底层会立即返回 "Connection Refused"，耗时通常只有几十毫秒
		dataSource.setUrl("jdbc:kingbase8://localhost:59432/test_db");

		// 将物理连接超时设得更短
		dataSource.setConnectTimeout(1000);
	}
	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证开启 FailFast 后，初始化失败是否立即抛出异常
	 */
	@Test
	public void shouldThrowExceptionImmediatelyDuringInit() {
		System.out.println(">>> 开始验证 FailFast 行为 (预期立即报错)...");
		long startTime = System.currentTimeMillis();

		try {
			// 因为我们在工厂类里设了 initialSize=1 且 failFast=true
			// init() 会尝试建立物理连接，失败后应该立即甩出一个 SQLException
			dataSource.init();

			fail("错误：FailFast 开启时，初始化失败理应立即抛出异常，但它竟然初始化成功了！");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("【成功捕获异常】耗时: " + duration + "ms");
			System.out.println("捕获到的错误信息: " + e.getMessage());

			// 核心断言：
			// 1. 验证参数确实是开启的
			assertTrue("FailFast 模式应处于开启状态", dataSource.isFailFast());

			// 2. 验证响应速度：不应该经历漫长的重试（比如默认的 30秒或多次重试）
			// 如果耗时很短，说明它“快速”失败了
			assertTrue("FailFast 模式下，报错应该是及时的（当前耗时：" + duration + "ms）",
					duration < 5000);

		} catch (Exception e) {
			fail("预期捕获 SQLException，实际却捕获到了: " + e.getClass().getName());
		}
	}
}