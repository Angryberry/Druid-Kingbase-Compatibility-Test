package ConnectProperties_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class ConnectProperties_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = ConnectProperties_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：通过查询数据库中的 ApplicationName 验证透传参数是否生效
	 */
	@Test
	public void shouldVerifyApplicationNameInDatabaseSession() throws Exception {
		System.out.println(">>> 开始验证 ConnectProperties 透传行为...");

		try (Connection conn = dataSource.getConnection();
			 Statement stmt = conn.createStatement()) {

			// 对于 Kingbase8/PostgreSQL，执行以下 SQL 获取应用名
			// 注意：如果是 MySQL，可以尝试查询其他会话变量
			String sql = "SHOW application_name";

			try (ResultSet rs = stmt.executeQuery(sql)) {
				if (rs.next()) {
					String actualAppName = rs.getString(1);
					System.out.println("数据库中记录的当前应用名为: " + actualAppName);

					// 核心断言：验证数据库返回的名字是否等于我们配置的名字
					assertEquals("透传参数 ApplicationName 未生效",
							ConnectProperties_Test.APP_NAME,
							actualAppName);

					System.out.println("【验证通过】：底层驱动成功接收到了 ConnectProperties 中的配置。");
				} else {
					fail("无法获取 application_name，请确认数据库驱动支持该属性。");
				}
			}
		}
	}
}