package TimeBetweenConnectErrorMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class TimeBetweenConnectErrorMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = TimeBetweenConnectErrorMillis_Test.createDataSource(props);

		// --- 核心破坏动作：故意设置错误密码 ---
		dataSource.setPassword("wrong_password_to_trigger_error");

		// 设置 maxWait 略大于重试间隔，确保有时间进行重试
		dataSource.setMaxWait(5000);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证连接失败后的重试间隔是否符合预期
	 */
	@Test
	public void shouldObserveIntervalBetweenConnectRetries() {
		long startTime = System.currentTimeMillis();

		try {
			System.out.println("【开始验证】正在请求连接（已配置 initialSize=0 和非破坏性失败）...");
			// 此时 getConnection 会触发创建连接，失败后会触发 timeBetweenConnectErrorMillis 等待
			dataSource.getConnection();
			fail("预期应失败");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("【结果】捕获到异常，实际总耗时: " + duration + "ms");

			// 现在耗时应该会包含那 2000ms 的等待时间
			assertTrue("实际耗时 (" + duration + "ms) 应该体现出重试间隔的等待",
					duration >= TimeBetweenConnectErrorMillis_Test.TIME_BETWEEN_CONNECT_ERROR_MILLIS);
		}
	}
}