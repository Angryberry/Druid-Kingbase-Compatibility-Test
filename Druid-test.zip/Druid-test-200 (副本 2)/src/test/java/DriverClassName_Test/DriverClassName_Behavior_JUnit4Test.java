package DriverClassName_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Driver;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class DriverClassName_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = DriverClassName_Test.createDataSource(props);
		// init() 会触发驱动的加载和实例化
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证 Druid 内部真正持有的驱动实例是否正确
	 */
	@Test
	public void shouldVerifyActualDriverInstance() throws Exception {
		System.out.println(">>> 开始验证 DriverClassName 行为...");

		// 1. 获取 Druid 内部持有的 Driver 实例
		Driver internalDriver = dataSource.getDriver();
		assertNotNull("Druid 未能成功实例化驱动程序", internalDriver);

		String actualDriverClass = internalDriver.getClass().getName();
		System.out.println("Druid 实际加载的驱动类为: " + actualDriverClass);

		// 2. 核心断言：验证加载的类名是否符合预期
		// 如果你配置的是 Kingbase，而它加载了 MySQL，这里就会报错
		assertEquals("加载的驱动类与配置不符",
				DriverClassName_Test.DRIVER_CLASS_NAME,
				actualDriverClass);

		// 3. 连通性辅助验证
		try (Connection conn = dataSource.getConnection()) {
			assertTrue("连接应处于有效状态", conn.isValid(5));
			System.out.println("【验证通过】：成功通过指定驱动类建立数据库连接。");
		}
	}

	/**
	 * 容错性验证：验证非法类名是否会导致初始化失败
	 */
	@Test
	public void shouldFailWhenDriverClassIsInvalid() {
		DruidDataSource errorDs = new DruidDataSource();
		errorDs.setDriverClassName("com.non.existent.FakeDriver");
		errorDs.setUrl("jdbc:kingbase8://localhost:54321/test"); // 随便写一个

		try {
			errorDs.init();
			fail("错误的 DriverClassName 应当导致初始化失败");
		} catch (Exception e) {
			System.out.println("成功捕获到预期的类加载异常: " + e.getMessage());
			assertTrue(e.getMessage().contains("com.non.existent.FakeDriver"));
		} finally {
			errorDs.close();
		}
	}
}