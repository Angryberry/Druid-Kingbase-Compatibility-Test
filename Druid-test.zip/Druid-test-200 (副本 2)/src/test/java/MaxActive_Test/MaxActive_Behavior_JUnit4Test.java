package MaxActive_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.GetConnectionTimeoutException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxActive_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	// 使用你工厂类里定义的常量，或者设一个小值（如 2）方便测试
	private static final int TEST_MAX_ACTIVE = 2;
	private static final long TEST_MAX_WAIT = 2000; // 2秒超时

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxActive_Test.MaxActive_Test.createDataSource(props);

		// --- 核心行为配置 ---
		dataSource.setMaxActive(TEST_MAX_ACTIVE);
		dataSource.setMaxWait(TEST_MAX_WAIT); // 必须设置，否则测试会死锁

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			dataSource.close();
		}
	}

	/**
	 * 行为验证：当达到 maxActive 上限时，后续获取连接的请求应该超时报错
	 */
	@Test
	public void shouldThrowExceptionWhenExceedingMaxActive() throws SQLException {
		System.out.println(">>> 开始验证 MaxActive 行为...");
		System.out.println(">>> 设定最大激活连接数: " + TEST_MAX_ACTIVE);

		List<Connection> activeConnections = new ArrayList<>();

		try {
			// 1. 成功获取到最大数量的连接，模拟高并发占满连接池
			for (int i = 1; i <= TEST_MAX_ACTIVE; i++) {
				Connection conn = dataSource.getConnection();
				assertNotNull("第 " + i + " 个连接应获取成功", conn);
				activeConnections.add(conn);
				System.out.println(">>> 已成功占用第 " + i + " 个连接");
			}

			// 2. 尝试获取第 n+1 个连接
			System.out.println(">>> 尝试获取第 " + (TEST_MAX_ACTIVE + 1) + " 个连接 (预期将超时)...");
			long startTime = System.currentTimeMillis();

			try {
				dataSource.getConnection();
				fail("错误：超过 MaxActive 后竟然还能获取到连接，限制失效！");
			} catch (GetConnectionTimeoutException e) {
				// 预期捕获到 Druid 的超时异常
				long duration = System.currentTimeMillis() - startTime;
				System.out.println(">>> 捕获到预期超时，耗时: " + duration + "ms");

				// --- 核心断言 ---
				// 耗时应该大于等于我们设定的 2000ms
				assertTrue("超时时间应不小于 maxWait 设定值", duration >= TEST_MAX_WAIT);
				System.out.println(">>> 验证成功：连接池已满，溢出请求已被正确拦截。");
			}

		} finally {
			// 记得手动释放所有连接，否则数据库连接可能被耗尽
			for (Connection conn : activeConnections) {
				try { conn.close(); } catch (SQLException ignored) {}
			}
			System.out.println(">>> 测试结束，已归还所有占用连接。");
		}
	}
}