package InitialSize_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class InitialSize_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	// 获取你在 InitialSize_Test 类中定义的常量
	private static final int EXPECTED_INITIAL_SIZE = ParameterTest.InitialSize_Test.InitialSize_Test.INITIAL_SIZE;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) {
				props.load(in);
			}
		}

		// 1. 使用你的工厂方法创建数据源
		dataSource = ParameterTest.InitialSize_Test.InitialSize_Test.createDataSource(props);

		// 补全基础配置，确保初始化不报错
		dataSource.setValidationQuery("SELECT 1");
		dataSource.setTestWhileIdle(true);
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			dataSource.close();
		}
	}

	/**
	 * 行为验证：验证数据源初始化后，池中连接数是否等于 initialSize
	 */
	@Test
	public void shouldCreateInitialConnectionsOnInit() throws Exception {
		System.out.println("开始验证 initialSize 行为...");
		System.out.println("预期初始化连接数: " + EXPECTED_INITIAL_SIZE);

		// 2. 核心动作：显式调用初始化
		// 这一步会触发 Druid 的物理连接创建
		dataSource.init();

		// 3. 检查 Druid 内部统计指标
		int currentPoolingCount = dataSource.getPoolingCount();
		long totalCreateCount = dataSource.getCreateCount();

		System.out.println("初始化完成后的池内连接数 (poolingCount): " + currentPoolingCount);
		System.out.println("物理连接创建总数 (createCount): " + totalCreateCount);

		// --- 核心断言 ---

		// 验证池中空闲连接数是否符合预期
		assertEquals("初始化后的池内连接数不符合 initialSize 配置",
				EXPECTED_INITIAL_SIZE, currentPoolingCount);

		// 验证物理创建总数是否至少等于 initialSize
		assertTrue("物理连接创建总数应不小于 initialSize",
				totalCreateCount >= EXPECTED_INITIAL_SIZE);

		System.out.println("验证成功：Druid 确实在初始化阶段预创建了 " + EXPECTED_INITIAL_SIZE + " 个连接。");
	}
}