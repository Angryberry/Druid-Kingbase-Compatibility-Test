package LoginTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class LoginTimeout_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		// 使用工厂类创建，此时 URL 指向黑洞 IP
		dataSource = LoginTimeout_Test.createDataSource(props);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证物理连接建立过程是否受 loginTimeout 约束
	 */
	@Test
	public void shouldTimeoutAccurately() {
		System.out.println(">>> 开始验证 LoginTimeout 行为 (预期 3 秒超时)...");
		long startTime = System.currentTimeMillis();

		try {
			// 触发物理连接创建
			dataSource.getConnection();
			fail("错误：由于 IP 不可用，此处理应发生超时异常");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			double durationSec = duration / 1000.0;
			System.out.println(">>> 捕获到超时异常，实际耗时: " + String.format("%.2f", durationSec) + " 秒");

			// --- 核心断言 ---
			// 预期 3 秒，我们允许 1-2 秒的系统级网络握手误差
			assertTrue("超时时间过短，参数可能未生效: " + durationSec, durationSec >= LoginTimeout_Test.LOGIN_TIMEOUT_SEC - 0.5);
			assertTrue("超时时间过长，参数可能未生效: " + durationSec, durationSec <= LoginTimeout_Test.LOGIN_TIMEOUT_SEC + 5.0);

			// 验证字段值
            assertEquals("LoginTimeout 属性值不符", LoginTimeout_Test.LOGIN_TIMEOUT_SEC, dataSource.getLoginTimeout());
        }
	}
}