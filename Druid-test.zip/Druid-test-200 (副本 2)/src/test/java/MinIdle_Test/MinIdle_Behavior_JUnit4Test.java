package MinIdle_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class MinIdle_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 定义清晰的测试阈值
	private static final int TEST_MIN_IDLE = 2;
	private static final long SCAN_INTERVAL_MS = 1000; // 1秒扫描一次

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MinIdle_Test.MinIdle_Test.createDataSource(props);

		// --- 核心修正点 ---
		dataSource.setMinIdle(TEST_MIN_IDLE); // 2
		dataSource.setInitialSize(1);         // 1

		// 1. 【必须】开启 KeepAlive，这是触发后台主动补齐 minIdle 的“发令枪”
		dataSource.setKeepAlive(true);

		// 2. 【关键】设置保活检查间隔，设为一个较小的值（例如 2s）
		// 确保它能被 5s 的测试时间窗口覆盖
		dataSource.setKeepAliveBetweenTimeMillis(2000);

		// 3. 扫描周期设为 1s
		dataSource.setTimeBetweenEvictionRunsMillis(1000);

		dataSource.setValidationQuery("SELECT 1");
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			dataSource.close();
		}
	}

	/**
	 * 行为验证：验证 Druid 是否会自动将连接数补齐到 minIdle 设定值
	 */
	@Test
	public void shouldAutomaticallyReplenishToMinIdle() throws Exception {
		System.out.println(">>> 开始验证 MinIdle 行为...");
		dataSource.init();

		// 2. 初始状态检查
		int countAfterInit = dataSource.getPoolingCount();
		System.out.println(">>> 刚初始化后的空闲连接数 (poolingCount): " + countAfterInit);
		assertEquals("初始连接数应等于 initialSize", 1, countAfterInit);

		// 3. 等待后台线程发现“水位不足”并补齐
		// 扫描周期 1s，通常 1-2 个周期内会补齐
		System.out.println(">>> 等待后台线程自动补齐连接至 minIdle (" + TEST_MIN_IDLE + ")...");

		// 循环检查，最多等 5 秒，避免 Thread.sleep 此时过长或过短
		boolean replenished = false;
		for (int i = 0; i < 10; i++) {
			Thread.sleep(500);
			if (dataSource.getPoolingCount() >= TEST_MIN_IDLE) {
				replenished = true;
				break;
			}
		}

		int finalCount = dataSource.getPoolingCount();
		System.out.println(">>> 最终空闲连接数 (poolingCount): " + finalCount);

		// --- 核心断言 ---
		assertTrue("错误：Druid 未能自动将连接数补齐到 minIdle。当前: " + finalCount, replenished);
		assertEquals("连接数应稳定在 minIdle 设定值", TEST_MIN_IDLE, finalCount);

		System.out.println(">>> [验证通过]：检测到 Druid 后台线程已自动补齐空闲连接。");
	}
}