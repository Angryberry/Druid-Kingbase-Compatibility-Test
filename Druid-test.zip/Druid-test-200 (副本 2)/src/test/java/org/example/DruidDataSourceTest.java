package org.example;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static org.junit.Assert.*;

public class DruidDataSourceTest {

    private DruidDataSource dataSource;

    @After
    public void tearDown() {
        if (dataSource != null) {
            dataSource.close();
        }
    }

    @Test
    public void shouldLoadPropertiesAndInitDataSource() throws IOException {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            assertNotNull("druid.properties 未找到，请确认位于 src/main/resources", in);
            props.load(in);
        }

        dataSource = new DruidDataSource();
        dataSource.setDriverClassName(props.getProperty("driverClassName"));
        dataSource.setUrl(props.getProperty("url"));
        dataSource.setUsername(props.getProperty("username"));
        dataSource.setPassword(props.getProperty("password"));
        String initialSize = props.getProperty("initialSize");
        if (initialSize != null) dataSource.setInitialSize(Integer.parseInt(initialSize));
        String maxActive = props.getProperty("maxActive");
        if (maxActive != null) dataSource.setMaxActive(Integer.parseInt(maxActive));
        String minIdle = props.getProperty("minIdle");
        if (minIdle != null) dataSource.setMinIdle(Integer.parseInt(minIdle));
        String validationQuery = props.getProperty("validationQuery");
        if (validationQuery != null) dataSource.setValidationQuery(validationQuery);
        try {
            dataSource.init();
        } catch (Exception e) {
            fail("dataSource.init() 抛异常: " + e.getMessage());
        }
    }
}


