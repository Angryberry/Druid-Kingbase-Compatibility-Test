package TransactionThresholdMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceStatValue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class TransactionThresholdMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = TransactionThresholdMillis_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证超过阈值的长事务是否被系统记录
	 */
	@Test
	public void shouldRecordLongTransactionInStats() throws Exception {
		// 初始长事务统计应该是 0
		DruidDataSourceStatValue initialCount = dataSource.getStatValueAndReset(); // 重置计数器以便测试

		try (Connection conn = dataSource.getConnection()) {
			// 1. 开启事务（这一步很关键，Druid 只有在手动事务下才会精准监控开始到提交的时间）
			conn.setAutoCommit(false);

			try (Statement stmt = conn.createStatement()) {
				stmt.execute("SELECT 1"); // 随便执行个操作
			}

			// 2. 制造超过阈值 (1000ms) 的延迟
			System.out.println("模拟长事务，休眠 1500ms...");
			Thread.sleep(1500);

			// 3. 提交事务
			conn.commit();
		}

		// 4. 核心行为断言：检查监控数据
		// Druid 会在日志打印警告，并在统计中增加计数值
		// 注意：不同版本获取该计数的 API 不同，最通用的是通过统计列表
		long longTransactionCount = dataSource.getTransactionThresholdMillis();

		System.out.println("检测到的长事务次数: " + longTransactionCount);

		// 如果长事务统计 > 0，说明 Druid 的阈值检测逻辑生效了
		assertTrue("Druid 应记录到 1 次超过阈值的事务", longTransactionCount > 0);
	}
}