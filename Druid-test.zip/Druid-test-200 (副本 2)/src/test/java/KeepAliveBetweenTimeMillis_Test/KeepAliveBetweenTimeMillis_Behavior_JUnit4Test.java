package KeepAliveBetweenTimeMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class KeepAliveBetweenTimeMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设置一个明显的阈值：3秒
	private static final long TEST_BETWEEN_MS = 3000;
	// 后台扫描频率设高一点：0.5秒扫一次
	private static final long SCAN_INTERVAL_MS = 500;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.KeepAliveBetweenTimeMillis_Test.KeepAliveBetweenTimeMillis_Test.createDataSource(props);

		dataSource.setKeepAlive(true);
		// 关键配置：设置保活间隔为 3s
		dataSource.setKeepAliveBetweenTimeMillis(TEST_BETWEEN_MS);
		// 设置后台扫描为 0.5s，确保它能频繁检查，但受限于上面的 3s 门槛
		dataSource.setTimeBetweenEvictionRunsMillis(SCAN_INTERVAL_MS);

		dataSource.setValidationQuery("SELECT 1");
		dataSource.setInitialSize(1);
		dataSource.setMinIdle(1);
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	@Test
	public void verifyIntervalEffectiveness() throws Exception {
		System.out.println(">>> 开始精准验证 KeepAliveBetweenTimeMillis: " + TEST_BETWEEN_MS + "ms");
		dataSource.init();

		// 1. 激活连接，刷新其活跃起始时间
		try (Connection conn = dataSource.getConnection()) {
			System.out.println(">>> 连接已激活，开始倒计时...");
		}

		// 2. 第一阶段验证：等待 2 秒 (小于 3 秒门槛)
		// 此时后台扫描线程会运行约 4 次，但因为没满 3s，不应触发保活
		System.out.println(">>> 第一阶段：等待 2s (预期不触发保活)...");
		Thread.sleep(2000);
		long countAfter2s = getKeepAliveCount();
		System.out.println(">>> 2s 后的保活计数: " + countAfter2s);
		assertEquals("错误：未到时间间隔就触发了保活检查！", 0, countAfter2s);

		// 3. 第二阶段验证：再等 2 秒 (总计 4 秒，超过 3 秒门槛)
		System.out.println(">>> 第二阶段：再等待 2s (累计 4s，预期触发保活)...");
		Thread.sleep(2000);
		long countAfter4s = getKeepAliveCount();
		System.out.println(">>> 4s 后的保活计数: " + countAfter4s);

		// --- 核心断言 ---
		assertTrue("错误：超过时间间隔后，保活检查未触发！", countAfter4s > 0);

		System.out.println(">>> [验证通过]：保活检查严格遵守了 " + TEST_BETWEEN_MS + "ms 的时间门槛。");
	}

	private long getKeepAliveCount() {
		if (dataSource.getDataSourceStat() != null) {
			return dataSource.getDataSourceStat().getKeepAliveCheckCount();
		}
		return 0;
	}
}