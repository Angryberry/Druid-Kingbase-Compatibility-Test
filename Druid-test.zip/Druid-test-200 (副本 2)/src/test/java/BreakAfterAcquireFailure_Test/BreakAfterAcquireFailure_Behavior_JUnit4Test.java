package BreakAfterAcquireFailure_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class BreakAfterAcquireFailure_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = BreakAfterAcquireFailure_Test.createDataSource(props);

		// --- 核心破坏动作：设置错误端口 ---
		dataSource.setUrl("jdbc:kingbase8://localhost:9999/err_db");
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证 BreakAfterAcquireFailure 为 true 时是否立即中断重试
	 */
	@Test
	public void shouldBreakImmediatelyWhenFailureOccurs() {
		long startTime = System.currentTimeMillis();

		try {
			System.out.println("尝试获取连接（已配置 BreakAfterAcquireFailure = true）...");
			dataSource.getConnection();
			fail("理应报错退出");
		} catch (SQLException e) {
			long duration = System.currentTimeMillis() - startTime;
			System.out.println("捕获到异常，总耗时: " + duration + "ms");

			// 核心断言：
			// 虽然配置了 10 次重试，但因为 break=true，耗时应该极短（通常 < 1000ms）
			// 如果参数没生效，它会去尝试重试，耗时会超过 1000ms 甚至更多
			assertTrue("实际耗时 (" + duration + "ms) 过长，说明未能在失败后立即中断重试",
					duration < 2000);

			System.out.println("行为验证成功：Druid 在第一次连接失败后立即中断了请求。");
		}
	}
}