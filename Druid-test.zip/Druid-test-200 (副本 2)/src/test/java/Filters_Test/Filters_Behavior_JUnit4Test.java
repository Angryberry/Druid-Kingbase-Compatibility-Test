package Filters_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.stat.JdbcSqlStat;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Properties;
import java.io.InputStream;
import java.util.Map;

import static org.junit.Assert.*;

public class Filters_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = Filters_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证 stat 过滤器是否真的记录了 SQL 执行情况
	 */
	@Test
	public void shouldRecordSqlStatWhenFilterIsEnabled() throws Exception {
		System.out.println(">>> 开始验证 Filters 行为...");

		String testSql = "SELECT 1";

		// 1. 执行 SQL 之前，重置统计信息（确保测试纯净）
		dataSource.getDataSourceStat().reset();

		// 2. 借出连接并执行 SQL
		try (Connection conn = dataSource.getConnection();
			 Statement stmt = conn.createStatement()) {
			stmt.execute(testSql);
		}

		// 3. 核心行为断言：检查统计信息
		// 如果 stat 过滤器生效了，dataSource 的 SqlStatMap 里一定会有记录
		Map<String, JdbcSqlStat> sqlStatMap = dataSource.getSqlStatMap();

		System.out.println("检测到的 SQL 统计条数: " + sqlStatMap.size());

		// 验证过滤器是否抓到了 SQL
		assertFalse("stat 过滤器未生效，SQL 统计 Map 为空", sqlStatMap.isEmpty());

		// 验证具体 SQL 的执行次数
		boolean found = false;
		for (JdbcSqlStat stat : sqlStatMap.values()) {
			if (stat.getSql().contains(testSql)) {
				found = true;
				System.out.println("SQL: " + stat.getSql() + " | 执行次数: " + stat.getExecuteCount());
				assertTrue("执行次数应大于 0", stat.getExecuteCount() > 0);
			}
		}

		assertTrue("在统计数据中未找到执行的测试 SQL，Filter 拦截失败", found);
	}
}