package DefaultAutoCommit_Test;

import com.alibaba.druid.pool.DruidDataSource;
import ParameterTest.DefaultAutoCommit_Test.DefaultAutoCommit_Test;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.*;

public class DefaultAutoCommit_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	private static final String TEST_TABLE = "test_autocommit_behavior";

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 调用工厂方法
		dataSource = ParameterTest.DefaultAutoCommit_Test.DefaultAutoCommit_Test.createDataSource(props);
		dataSource.init();

		try (Connection conn = dataSource.getConnection()) {
			// 【关键】记录原始状态，手动管理建表事务
			boolean auto = conn.getAutoCommit();
			conn.setAutoCommit(true); // 强制开启自动提交以确保 DDL 立即生效

			try (Statement stmt = conn.createStatement()) {
				// Kingbase 建议表名加双引号或全小写
				String createSql = "CREATE TABLE IF NOT EXISTS test_autocommit_behavior (id INT PRIMARY KEY, name VARCHAR(255))";
				stmt.execute(createSql);

				// 清理旧数据
				stmt.execute("DELETE FROM test_autocommit_behavior");
			} finally {
				conn.setAutoCommit(auto); // 还原状态
			}
		}
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			// 健壮性处理：如果表不存在，静默退出，不让 tearDown 的异常淹没测试结果
			try (Connection conn = dataSource.getConnection();
				 Statement stmt = conn.createStatement()) {
				conn.setAutoCommit(true);
				stmt.execute("DROP TABLE IF EXISTS test_autocommit_behavior");
			} catch (Exception e) {
				System.err.println("清理环境时发生非致命错误: " + e.getMessage());
			} finally {
				dataSource.close();
			}
		}
	}

	/**
	 * 行为验证 1：验证 Connection 对象的初始 AutoCommit 状态
	 */
	@Test
	public void shouldReflectAutoCommitInConnection() throws Exception {
		try (Connection conn = dataSource.getConnection()) {
			// 这才是真正的行为验证：Connection 是否继承了 Pool 的配置
			assertEquals("从数据源获取的连接，其 AutoCommit 状态与配置不符",
					DefaultAutoCommit_Test.DEFAULT_AUTO_COMMIT,
					conn.getAutoCommit());
		}
	}

	/**
	 * 行为验证 2：验证数据持久化行为 (核心逻辑)
	 * 如果 defaultAutoCommit = false，执行 INSERT 后 rollback，数据应消失
	 */
	@Test
	public void shouldRespectTransactionBehavior() throws Exception {
		boolean expectedAutoCommit = DefaultAutoCommit_Test.DEFAULT_AUTO_COMMIT;

		try (Connection conn = dataSource.getConnection()) {
			// 1. 执行插入
			try (Statement stmt = conn.createStatement()) {
				stmt.execute("INSERT INTO " + TEST_TABLE + " VALUES (1, 'TestUser')");
			}

			// 2. 模拟回滚
			conn.rollback();

			// 3. 验证结果
			try (Statement stmt = conn.createStatement();
				 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + TEST_TABLE)) {
				rs.next();
				int count = rs.getInt(1);

				if (expectedAutoCommit) {
					// 如果是自动提交，rollback 无效，数据应该还在 (1 条)
					assertEquals("自动提交模式下，数据应已持久化", 1, count);
				} else {
					// 如果是非自动提交，rollback 后数据应该消失 (0 条)
					assertEquals("非自动提交模式下，回滚后数据应清空", 0, count);
				}
			}
		}
	}
}