package QueryTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.*;

public class QueryTimeout_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设定查询超时阈值：2 秒
	private static final int TEST_QUERY_TIMEOUT_SEC = 2;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		// 1. 使用工厂方法创建数据源
		dataSource = ParameterTest.QueryTimeout_Test.QueryTimeout_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 设置默认的查询超时时间（单位：秒）
		dataSource.setQueryTimeout(TEST_QUERY_TIMEOUT_SEC);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证当执行耗时 SQL 时，是否会在指定的秒数后触发超时中断
	 */
	@Test
	public void shouldInterruptSlowQueryWhenExceedingTimeout() throws SQLException {
		System.out.println(">>> 开始验证 QueryTimeout 行为...");
		System.out.println(">>> 设定查询超时: " + TEST_QUERY_TIMEOUT_SEC + " 秒");

		try (Connection conn = dataSource.getConnection();
			 Statement stmt = conn.createStatement()) {

			// 2. 执行一个模拟耗时 5 秒的查询 (Kingbase 兼容 pg_sleep)
			// 注意：由于我们设定的超时是 2s，这个 5s 的查询必须被中断
			String slowSql = "SELECT pg_sleep(5)";

			long startTime = System.currentTimeMillis();
			try {
				System.out.println(">>> 正在执行耗时 SQL: " + slowSql + " ...");
				stmt.executeQuery(slowSql);

				fail("错误：SQL 执行超过了超时时间却没有报错！");
			} catch (SQLException e) {
				long duration = System.currentTimeMillis() - startTime;
				double durationSec = duration / 1000.0;

				System.out.println(">>> 捕获到异常，耗时: " + String.format("%.2f", durationSec) + " 秒");
				System.out.println(">>> 异常信息: " + e.getMessage());

				// --- 核心断言 ---

				// 1. 验证时间：耗时应该在 2s 附近，而不应该达到 5s
				assertTrue("超时生效太慢或未生效，耗时: " + durationSec, durationSec < 4.0);
				assertTrue("报错太快，可能不是超时引起: " + durationSec, durationSec >= 1.5);

				// 2. 验证异常：通常包含 "timeout" 或特定的 SQLState
				// 金仓/Postgres 典型的超时错误包含 "canceling statement due to user request" 或 "timeout"
				assertTrue("异常信息应包含超时提示",
						e.getMessage().toLowerCase().contains("timeout") ||
								e.getMessage().toLowerCase().contains("cancel"));
			}
		}
		System.out.println(">>> [验证通过]：QueryTimeout 成功中断了慢查询。");
	}
}