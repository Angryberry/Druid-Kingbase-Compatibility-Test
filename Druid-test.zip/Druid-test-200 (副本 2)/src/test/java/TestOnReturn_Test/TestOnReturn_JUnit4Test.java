package TestOnReturn_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class TestOnReturn_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			props.load(in);
		}
		dataSource = TestOnReturn_Test.createDataSource(props);

		// 1. --- 强制禁用驱动自带的校验，确保 Druid 必须运行 validationQuery ---
		dataSource.setUsePingMethod(false);

		// 2. --- 暴力修改所有可能的归还检查阈值 ---
		forceSetAllThresholds(dataSource, -1L);

		dataSource.setInitialSize(1);
		dataSource.setMaxActive(1);
		dataSource.setTestOnReturn(true);
		dataSource.init();
	}

	private void forceSetAllThresholds(Object target, long value) {
		Class<?> clazz = target.getClass();
		while (clazz != null) {
			for (java.lang.reflect.Field field : clazz.getDeclaredFields()) {
				String name = field.getName().toLowerCase();
				// 只要包含 return 和 threshold，或者是 onReturnTestThresholdMillis，全部设为 -1
				if (name.contains("threshold") && name.contains("return")) {
					try {
						field.setAccessible(true);
						field.set(target, value);
						System.out.println(">>> [全局反射成功] 字段: " + field.getName() + " = " + value);
					} catch (Exception ignored) {}
				}
			}
			clazz = clazz.getSuperclass();
		}
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	private void forceSetGlobalReturnThreshold(DruidDataSource ds, long value) {
		Class<?> clazz = ds.getClass();
		while (clazz != null) {
			for (java.lang.reflect.Field field : clazz.getDeclaredFields()) {
				String name = field.getName();
				// 精准狙击控制归还校验频率的字段
				if (name.equals("onReturnTestThresholdMillis")) {
					try {
						field.setAccessible(true);
						field.set(ds, value);
						System.out.println(">>> [全局反射成功] 已修改归还阈值: " + name + " = " + value);
					} catch (Exception ignored) {}
				}
			}
			clazz = clazz.getSuperclass();
		}
	}

	private void forceExpireConnection(Connection conn) {
		try {
			DruidPooledConnection poolConn = (DruidPooledConnection) conn;
			java.lang.reflect.Field holderField = DruidPooledConnection.class.getDeclaredField("holder");
			holderField.setAccessible(true);
			Object holder = holderField.get(poolConn);

			java.lang.reflect.Field lastActiveField = holder.getClass().getDeclaredField("lastActiveTimeMillis");
			lastActiveField.setAccessible(true);
			lastActiveField.set(holder, 0L);
			System.out.println(">>> [连接反射成功] 已手动将当前连接标记为“极度陈旧”。");
		} catch (Exception e) {
			System.err.println(">>> [警告] 反射失败: " + e.getMessage());
		}
	}

	@Test
	public void shouldDiscardConnectionOnReturn() throws Exception {
		System.out.println(">>> 开始验证 TestOnReturn 终极模式...");

		// 1. 获取一个连接，并拿到它的物理底层连接
		DruidPooledConnection poolConn = (DruidPooledConnection) dataSource.getConnection();
		java.sql.Connection physicalConn = poolConn.getConnection();

		long initialDiscardCount = dataSource.getDiscardCount();

		// 2. 【核心动作】注入毒药 SQL 并手动关闭物理连接
		dataSource.setValidationQuery("SELECT 1 FROM non_existent_table_999");

		// 强制标记为陈旧
		forceExpireConnection(poolConn);

		// 物理切断（让校验必死）
		physicalConn.close();
		System.out.println(">>> 物理连接已手动关闭，正在执行 poolConn.close()...");

		// 3. 归还逻辑连接
		try {
			poolConn.close();
		} catch (Exception e) {
			System.out.println(">>> 归还时触发了预期异常: " + e.getMessage());
		}

		// 4. 断言
		long finalDiscardCount = dataSource.getDiscardCount();
		System.out.println(">>> 最终丢弃计数 (DiscardCount): " + finalDiscardCount);

		assertTrue("TestOnReturn 校验未触发！", finalDiscardCount > initialDiscardCount);
		System.out.println(">>> [全链路验证通过]：Druid 已成功丢弃坏连接。");
	}
}