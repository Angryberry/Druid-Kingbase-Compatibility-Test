package PhyTimeoutMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import static org.junit.Assert.*;

public class PhyTimeoutMillis_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	// 设定极短的物理寿命阈值：2秒
	private static final long TEST_PHY_TIMEOUT_MS = 2000;
	private static final long SCAN_INTERVAL_MS = 500;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.PhyTimeoutMillis_Test.PhyTimeoutMillis_Test.createDataSource(props);

		// --- 核心行为配置 ---
		// 1. 设置物理连接的最大寿命为 2s
		dataSource.setPhyTimeoutMillis(TEST_PHY_TIMEOUT_MS);
		// 2. 设置高频扫描周期
		dataSource.setTimeBetweenEvictionRunsMillis(SCAN_INTERVAL_MS);

		// 为了排除“空闲驱逐”的干扰，将空闲驱逐时间设得很长
		dataSource.setMinEvictableIdleTimeMillis(600000);

		dataSource.setInitialSize(1);
		dataSource.setMinIdle(1);
		dataSource.setValidationQuery("SELECT 1");
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证物理连接达到生存时长上限后，是否会被强制物理销毁
	 */
	@Test
	public void shouldDestroyConnectionWhenExceedingPhyTimeout() throws Exception {
		System.out.println(">>> 开始验证 PhyTimeoutMillis 行为...");
		dataSource.init();

		// 1. 记录初始状态：销毁计数和创建计数
		long initialDestroyCount = dataSource.getDestroyCount();
		System.out.println(">>> 初始销毁计数: " + initialDestroyCount);

		// 2. 为了证明这不是“空闲驱逐”，我们在中间通过使用一下连接来“刷新”它的空闲时间
		Thread.sleep(1000);
		try (Connection conn = dataSource.getConnection()) {
			System.out.println(">>> 1s 时使用了一次连接，证明其尚未空闲。");
		}

		// 3. 等待总时长超过 TEST_PHY_TIMEOUT_MS (2s)
		// 累计等待超过 2s 后，phyTimeoutMillis 应该触发
		System.out.println(">>> 继续等待，直到连接“寿命”到期...");
		Thread.sleep(1500);

		// 4. 获取当前销毁计数
		long currentDestroyCount = dataSource.getDestroyCount();
		System.out.println(">>> 最终销毁计数: " + currentDestroyCount);

		// --- 核心断言 ---

		// 虽然我们中间用过连接，它不符合“空闲驱逐”条件，
		// 但因为它“年龄”超过了 2s，必须被销毁。
		assertTrue("错误：物理连接达到寿命上限后未被销毁！",
				currentDestroyCount > initialDestroyCount);

		System.out.println(">>> [验证通过]：物理连接因达到 PhyTimeoutMillis 寿命上限而被强制回收。");
	}
}