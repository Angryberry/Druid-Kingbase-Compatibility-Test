package Z_ParserValidationTest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assume;
import java.lang.reflect.Method;
import java.sql.SQLException;
import static org.junit.Assert.*;

/**
 * MySQL 解析器验证的集成测试
 */
public class MySQLParserValidationTest {

    private MySQLParserValidation validator;

    @Before
    public void setUp() throws SQLException {
        validator = new MySQLParserValidation();
        System.out.println(">>> 正在初始化 MySQL 测试环境...");
        validator.initDatabase();

        // --- 环境预检守门员 ---
        // 如果不是 MySQL 模式，后续所有测试都会被标记为 Skipped（已跳过）
        Assume.assumeTrue("环境检测：当前数据库非 MySQL 模式，自动跳过此套件。",
                validator.isMySQLMode());

        System.out.println(">>> 环境预检通过，开始执行 MySQL 解析验证...");
    }

    @After
    public void tearDown() {
        if (validator != null) {
            validator.closeDatabase();
        }
    }

    /**
     * 运行逻辑类中定义的完整 MySQL 测试套件
     */
    @Test
    public void shouldRunFullMySQLValidationSuite() {
        validator.runAllTests();
        // 验证执行完成后，连接是否依然有效
        try {
            assertFalse("连接不应在运行中被关闭", validator.connection.isClosed());
        } catch (SQLException e) {
            fail("状态检查异常");
        }
    }

    /**
     * 手动验证特定的 MySQL 语法（如 LIMIT）
     */
    @Test
    public void testSpecificMySQLSyntax() {
        String sql = "SELECT * FROM users ORDER BY id LIMIT 5, 10";
        validator.testSQLParsing("LIMIT语法验证", sql);
        assertTrue(true);
    }

    /**
     * 连接池业务场景测试
     */
    @Test
    public void testConnectionPoolBusinessScenarios() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testConnectionPoolBusinessScenarios");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 连接池业务场景测试完成");
        } catch (Exception e) {
            fail("连接池业务场景测试失败: " + e.getMessage());
        }
    }

    /**
     * 数据类型映射测试
     */
    @Test
    public void testDataTypeMapping() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testDataTypeMapping");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 数据类型映射测试完成");
        } catch (Exception e) {
            fail("数据类型映射测试失败: " + e.getMessage());
        }
    }

    /**
     * 分页查询测试
     */
    @Test
    public void testPaginationQueries() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testPaginationQueries");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 分页查询测试完成");
        } catch (Exception e) {
            fail("分页查询测试失败: " + e.getMessage());
        }
    }

    /**
     * 批量操作测试
     */
    @Test
    public void testBatchOperations() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testBatchOperations");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 批量操作测试完成");
        } catch (Exception e) {
            fail("批量操作测试失败: " + e.getMessage());
        }
    }

    /**
     * LOB操作测试
     */
    @Test
    public void testLobOperations() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testLobOperations");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ LOB操作测试完成");
        } catch (Exception e) {
            fail("LOB操作测试失败: " + e.getMessage());
        }
    }

    /**
     * 协议兼容性测试
     */
    @Test
    public void testProtocolCompatibility() {
        try {
            Method method = MySQLParserValidation.class.getDeclaredMethod("testProtocolCompatibility");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 协议兼容性测试完成");
        } catch (Exception e) {
            fail("协议兼容性测试失败: " + e.getMessage());
        }
    }

    /**
     * 综合测试：所有新增功能一起测试
     */
    @Test
    public void testAllNewFeatures() {
        System.out.println("--- 执行所有新增功能综合测试 ---");
        
        // 连接池业务场景测试
        testConnectionPoolBusinessScenarios();
        
        // 数据类型映射测试
        testDataTypeMapping();
        
        // 分页查询测试
        testPaginationQueries();
        
        // 批量操作测试
        testBatchOperations();
        
        // LOB操作测试
        testLobOperations();
        
        // 协议兼容性测试
        testProtocolCompatibility();
        
        System.out.println("✓ 所有新增功能测试完成");
    }

    /**
     * 性能压力测试：多次运行完整验证套件
     */
    @Test
    public void testMassSqlParsing() {
        System.out.println("--- 执行性能压力测试 ---");
        
        int iterations = 3; // 减少迭代次数以节省时间
        for (int i = 0; i < iterations; i++) {
            System.out.println("第 " + (i + 1) + " 次迭代:");
            validator.runAllTests();
        }
        
        System.out.println("✓ 性能压力测试完成，共执行 " + iterations + " 次完整验证");
    }
}