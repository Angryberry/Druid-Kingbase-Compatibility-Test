package Z_ParserValidationTest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assume;
import java.lang.reflect.Method;
import java.sql.SQLException;
import static org.junit.Assert.*;

/**
 * SQL Server 解析器验证集成测试
 */
public class SqlServerParserValidationTest {

    private SqlServerParserValidation validator;

    @Before
    public void setUp() throws SQLException {
        validator = new SqlServerParserValidation();
        System.out.println(">>> 正在初始化 SQL Server 测试环境...");
        validator.initDatabase();

        // --- 环境拦截器 ---
        // 如果检测到当前数据库不是 SQL Server 模式，则跳过后续所有测试
        Assume.assumeTrue("环境检测：当前数据库非 SQL Server 模式，已自动跳过此套件。",
                validator.isSqlServerMode());

        System.out.println(">>> 环境预检通过，开始执行 T-SQL 解析验证...");
    }

    @After
    public void tearDown() {
        if (validator != null) {
            validator.closeDatabase();
        }
    }

    /**
     * 集成测试：运行完整验证套件（基础 SQL、TOP、OFFSET-FETCH 等）
     */
    @Test
    public void shouldRunFullSqlServerValidationSuite() {
        validator.runAllTests();
        // 验证执行完成后，连接是否依然有效
        try {
            assertNotNull("连接对象不应为空", validator.connection);
            assertFalse("连接在测试结束前不应关闭", validator.connection.isClosed());
        } catch (SQLException e) {
            fail("状态检查异常");
        }
    }

    /**
     * 行为验证：专门测试 SQL Server 的 TOP 和 IDENTITY 语法
     */
    @Test
    public void testSqlServerSpecificFeatures() {
        System.out.println("--- 执行 SQL Server 特有语法专项验证 ---");

        // 1. 测试 TOP 语法
        validator.testSQLParsing("TOP语法", "SELECT TOP 5 name FROM users ORDER BY age");

        // 2. 测试分页 OFFSET-FETCH 语法 (SQL Server 2012+)
        validator.testSQLParsing("分页语法", "SELECT * FROM users ORDER BY id OFFSET 10 ROWS FETCH NEXT 5 ROWS ONLY");

        assertTrue("专项语法调用完成", true);
    }

    /**
     * 连接池业务场景测试
     */
    @Test
    public void testConnectionPoolBusinessScenarios() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testConnectionPoolBusinessScenarios");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 连接池业务场景测试完成");
        } catch (Exception e) {
            fail("连接池业务场景测试失败: " + e.getMessage());
        }
    }

    /**
     * 数据类型映射测试
     */
    @Test
    public void testDataTypeMapping() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testDataTypeMapping");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 数据类型映射测试完成");
        } catch (Exception e) {
            fail("数据类型映射测试失败: " + e.getMessage());
        }
    }

    /**
     * 分页查询测试
     */
    @Test
    public void testPaginationQueries() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testPaginationQueries");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 分页查询测试完成");
        } catch (Exception e) {
            fail("分页查询测试失败: " + e.getMessage());
        }
    }

    /**
     * 批量操作测试
     */
    @Test
    public void testBatchOperations() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testBatchOperations");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 批量操作测试完成");
        } catch (Exception e) {
            fail("批量操作测试失败: " + e.getMessage());
        }
    }

    /**
     * LOB操作测试
     */
    @Test
    public void testLobOperations() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testLobOperations");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ LOB操作测试完成");
        } catch (Exception e) {
            fail("LOB操作测试失败: " + e.getMessage());
        }
    }

    /**
     * 协议兼容性测试
     */
    @Test
    public void testProtocolCompatibility() {
        try {
            Method method = SqlServerParserValidation.class.getDeclaredMethod("testProtocolCompatibility");
            method.setAccessible(true);
            method.invoke(validator);
            System.out.println("✓ 协议兼容性测试完成");
        } catch (Exception e) {
            fail("协议兼容性测试失败: " + e.getMessage());
        }
    }

    /**
     * 综合测试：所有新增功能一起测试
     */
    @Test
    public void testAllNewFeatures() {
        System.out.println("--- 执行所有新增功能综合测试 ---");
        
        // 连接池业务场景测试
        testConnectionPoolBusinessScenarios();
        
        // 数据类型映射测试
        testDataTypeMapping();
        
        // 分页查询测试
        testPaginationQueries();
        
        // 批量操作测试
        testBatchOperations();
        
        // LOB操作测试
        testLobOperations();
        
        // 协议兼容性测试
        testProtocolCompatibility();
        
        System.out.println("✓ 所有新增功能测试完成");
    }

    /**
     * 性能压力测试：多次运行完整验证套件
     */
    @Test
    public void testMassSqlParsing() {
        System.out.println("--- 执行性能压力测试 ---");
        
        int iterations = 3; // 减少迭代次数以节省时间
        for (int i = 0; i < iterations; i++) {
            System.out.println("第 " + (i + 1) + " 次迭代:");
            validator.runAllTests();
        }
        
        System.out.println("✓ 性能压力测试完成，共执行 " + iterations + " 次完整验证");
    }
}