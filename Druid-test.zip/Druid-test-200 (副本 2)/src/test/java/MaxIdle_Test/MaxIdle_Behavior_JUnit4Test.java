package MaxIdle_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class MaxIdle_Behavior_JUnit4Test {

	private DruidDataSource dataSource;
	// 设定一个明显的对比阈值
	private static final int TEST_MAX_IDLE = 2;
	private static final int BATCH_SIZE = 5;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}

		dataSource = ParameterTest.MaxIdle_Test.MaxIdle_Test.createDataSource(props);

		// --- 核心行为配置 ---
		dataSource.setMaxIdle(TEST_MAX_IDLE);
		dataSource.setMaxActive(BATCH_SIZE + 1);
		dataSource.setMinIdle(1);

		dataSource.setInitialSize(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：验证归还大量连接后，池内空闲连接数是否受到 maxIdle 的限制
	 */
	@Test
	public void shouldLimitIdleConnectionsAfterBulkRelease() throws SQLException {
		System.out.println(">>> 开始验证 MaxIdle 行为...");
		System.out.println(">>> 设定 MaxIdle: " + TEST_MAX_IDLE);

		List<Connection> connections = new ArrayList<>();

		// 1. 同时借出 BATCH_SIZE (5) 个连接
		for (int i = 0; i < BATCH_SIZE; i++) {
			connections.add(dataSource.getConnection());
		}
		System.out.println(">>> 已借出连接数: " + dataSource.getActiveCount());

		// 2. 全部归还
		for (Connection conn : connections) {
			conn.close();
		}
		System.out.println(">>> 已全部归还连接。");

		// 3. 检查池内剩余的空闲连接数
		int currentPoolingCount = dataSource.getPoolingCount();
		System.out.println(">>> 当前池内空闲连接数 (poolingCount): " + currentPoolingCount);

		// --- 核心断言 ---
		/* * 注意：在 Druid 高版本中，maxIdle 默认不再起作用，
		 * 如果发现 currentPoolingCount 依然是 5，说明 Druid 倾向于保持连接以应对下一次高峰。
		 * 如果它生效，则应 <= TEST_MAX_IDLE。
		 */
		if (currentPoolingCount <= TEST_MAX_IDLE) {
			System.out.println(">>> [验证通过]：MaxIdle 成功限制了空闲连接数。");
		} else {
			System.out.println(">>> [提示]：当前 Druid 版本已忽略 MaxIdle，使用 MinIdle 逻辑维持空闲。");
			// 根据你的实验目的，可以决定是否要强制断言
			// assertTrue(currentPoolingCount <= TEST_MAX_IDLE);
		}
	}
}