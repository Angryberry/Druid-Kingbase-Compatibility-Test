package ValidationQueryTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import static org.junit.Assert.*;

public class ValidationQueryTimeout_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			assertNotNull("druid.properties 未找到", in);
			props.load(in);
		}

		// 1. 调用工厂方法
		dataSource = ValidationQueryTimeout_Test.createDataSource(props);

		// 2. --- 行为验证核心配置 ---
		dataSource.setTestOnBorrow(true);
		// 设置校验超时为 1 秒
		dataSource.setValidationQueryTimeout(1);

		// 关键：反射修改阈值，确保校验 SQL 100% 执行
		forceSetThreshold(dataSource, -1L);

		dataSource.setInitialSize(1);
		dataSource.setMaxActive(1);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) dataSource.close();
	}

	/**
	 * 行为验证：当校验 SQL 执行超时时，连接应被丢弃
	 */
	@Test
	public void shouldDiscardConnectionWhenValidationQueryTimesOut() throws Exception {
		System.out.println(">>> 开始验证 validationQueryTimeout 行为...");

		long initialDiscardCount = dataSource.getDiscardCount();

		// 1. 【核心注入】设置一个耗时 3 秒的校验 SQL (预期 1 秒超时)
		// 金仓/PostgreSQL 语法：sys_sleep(3) 或 pg_sleep(3)
		dataSource.setValidationQuery("SELECT sys_sleep(3)");

		System.out.println(">>> 正在借出连接（预期触发校验超时并丢弃）...");
		try {
			// 设置获取等待，防止线程卡死
			dataSource.setMaxWait(4000);
			dataSource.getConnection();
			fail("错误：校验 SQL 执行了 3 秒且超时设为 1 秒，此处理应抛出异常");
		} catch (SQLException e) {
			System.out.println(">>> 成功捕获到超时异常: " + e.getMessage());
		} finally {
			// 恢复正常的校验 SQL，防止后台创建线程陷入死循环报错
			dataSource.setValidationQuery("SELECT 1");
		}

		// 2. 断言验证
		long finalDiscardCount = dataSource.getDiscardCount();
		System.out.println(">>> 最终丢弃计数 (DiscardCount): " + finalDiscardCount);

		// 验证：丢弃计数器必须增加
		assertTrue("validationQueryTimeout 未能触发丢弃逻辑！",
				finalDiscardCount > initialDiscardCount);

		System.out.println(">>> [验证通过]：Druid 成功拦截并清理了校验超时的连接。");
	}

	@Test
	public void shouldRunMainAndExecuteSql() throws Exception {
		PrintStream originalOut = System.out;
		ByteArrayOutputStream captured = new ByteArrayOutputStream();
		System.setOut(new PrintStream(captured));
		try {
			ValidationQueryTimeout_Test.main(new String[0]);
			String output = captured.toString();
			assertTrue("未打印 Executed SQL", output.contains("Executed SQL:"));
		} finally {
			System.setOut(originalOut);
		}
	}

	/**
	 * 反射工具：确保校验逻辑不被 Druid 的新鲜度检查跳过
	 */
	private void forceSetThreshold(DruidDataSource ds, long value) {
		Class<?> clazz = ds.getClass();
		while (clazz != null) {
			for (java.lang.reflect.Field field : clazz.getDeclaredFields()) {
				String name = field.getName().toLowerCase();
				if (name.contains("borrow") && name.contains("threshold")) {
					try {
						field.setAccessible(true);
						field.set(ds, value);
					} catch (Exception ignored) {}
				}
			}
			clazz = clazz.getSuperclass();
		}
	}
}