package DestroyScheduler_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Properties;
import java.io.InputStream;
import java.util.concurrent.ScheduledExecutorService;

import static org.junit.Assert.*;

public class DefaultScheduler_Behavior_JUnit4Test {

	private DruidDataSource dataSource;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
			if (in != null) props.load(in);
		}
		dataSource = DestroyScheduler_Test.createDataSource(props);
		dataSource.init();
	}

	@After
	public void tearDown() {
		if (dataSource != null) {
			ScheduledExecutorService scheduler = dataSource.getDestroyScheduler();
			if (scheduler != null) scheduler.shutdownNow();
			dataSource.close();
		}
	}

	/**
	 * 行为验证：验证自定义销毁调度器是否正在后台运行
	 */
	@Test
	public void shouldVerifyCustomDestroyerIsWorking() throws Exception {
		System.out.println(">>> 开始验证 DestroyScheduler 行为...");

		// 1. 验证配置已注入
		ScheduledExecutorService scheduler = dataSource.getDestroyScheduler();
		assertNotNull("DestroyScheduler 应该已注入", scheduler);

		// 2. 验证连接池状态（初始 5 个）
		System.out.println("初始连接数 (PoolingCount): " + dataSource.getPoolingCount());

		// 3. 核心行为验证：检查 JVM 中是否有我们的自定义销毁线程
		boolean foundDestroyThread = false;
		Thread[] threads = new Thread[Thread.activeCount() * 2];
		Thread.enumerate(threads);

		for (Thread t : threads) {
			if (t != null && t.getName().contains(DestroyScheduler_Test.DESTROY_THREAD_PREFIX)) {
				foundDestroyThread = true;
				System.out.println("成功定位到自定义销毁线程: " + t.getName());
				break;
			}
		}

		assertTrue("JVM 中未找到自定义命名的销毁线程，说明调度器未按预期运行", foundDestroyThread);

		// 4. 可选：等待一段时间观察连接数是否下降（瘦身成功）
		Thread.sleep(1500);
		System.out.println("瘦身后连接数 (PoolingCount): " + dataSource.getPoolingCount());
		// 理想情况下连接数会趋向 minIdle (1)
	}
}