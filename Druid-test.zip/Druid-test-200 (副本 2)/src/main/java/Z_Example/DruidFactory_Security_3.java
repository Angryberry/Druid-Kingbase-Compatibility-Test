package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import java.io.InputStream;
import java.util.Properties;

public class DruidFactory_Security_3 {

    public static DruidDataSource createSecurityDataSource() throws Exception {
        Properties props = new Properties();
        // 对齐点 1：确保加载的文件名与实际文件名一致
        try (InputStream is = DruidFactory_Security_3.class.getClassLoader().getResourceAsStream("DruidFactory_3.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("找不到 DruidFactory_3.properties");
            props.load(is);
        }

        DruidDataSource ds = new DruidDataSource();

        // 1. 基础映射 (保持不变)
        ds.setDriverClassName(props.getProperty("driverClassName"));
        ds.setUrl(props.getProperty("url"));
        ds.setUsername(props.getProperty("username"));
        ds.setPassword(props.getProperty("password"));

        // 2. 规模控制 (保持不变)
        ds.setInitialSize(Integer.parseInt(props.getProperty("initialSize")));
        ds.setMaxActive(Integer.parseInt(props.getProperty("maxActive")));
        ds.setMaxWait(Long.parseLong(props.getProperty("maxWait")));

        // 3. 连接泄露回收逻辑 (保持不变)
        ds.setRemoveAbandoned(Boolean.parseBoolean(props.getProperty("removeAbandoned")));
        ds.setRemoveAbandonedTimeout(Integer.parseInt(props.getProperty("removeAbandonedTimeout")));
        ds.setLogAbandoned(Boolean.parseBoolean(props.getProperty("logAbandoned")));

        // 4. 超时控制 (保持不变)
        ds.setQueryTimeout(Integer.parseInt(props.getProperty("queryTimeout")));
        ds.setTransactionQueryTimeout(Integer.parseInt(props.getProperty("transactionQueryTimeout")));

// 5. 过滤器与解密配置 (进行硬核对齐)
        ds.setFilters(props.getProperty("filters"));

        // --- 核心修正：手动强制开启 WallFilter 的硬核模式 ---
        // 只有手动配置 WallConfig，才能确保 100% 拦截无 WHERE 的操作
        com.alibaba.druid.wall.WallConfig wallConfig = new com.alibaba.druid.wall.WallConfig();
        wallConfig.setDeleteWhereNoneCheck(true); // 禁止无 WHERE 删除
        wallConfig.setUpdateWhereNoneCheck(true); // 禁止无 WHERE 更新
        wallConfig.setConditionAndAlwayTrueAllow(false); // 禁止 '1'='1'

        com.alibaba.druid.wall.WallFilter wallFilter = new com.alibaba.druid.wall.WallFilter();
        wallFilter.setConfig(wallConfig);
        wallFilter.setDbType("postgresql"); // 金仓数据库适配 PG 语法

        // 把这个硬核防火墙加入到数据源的过滤器链中
        ds.getProxyFilters().add(wallFilter);

        // 原有的 connectionProperties 保持，用于 config 解密等
        ds.setConnectionProperties(props.getProperty("connectionProperties"));
        // 6. 生命周期 (关键对齐)
        ds.setTimeBetweenEvictionRunsMillis(Long.parseLong(props.getProperty("timeBetweenEvictionRunsMillis")));
        // 补上这一行：确保 keepAlive 间隔大于巡检周期，防止报错
        ds.setKeepAliveBetweenTimeMillis(Long.parseLong(props.getProperty("keepAliveBetweenTimeMillis")));

        // 7. 固化配置 (保持不变)
        ds.setValidationQuery("SELECT 1");
        ds.setTestWhileIdle(true);
        // 显式开启 keepAlive，与配置文件逻辑对齐
        ds.setKeepAlive(true);

        return ds;
    }
}