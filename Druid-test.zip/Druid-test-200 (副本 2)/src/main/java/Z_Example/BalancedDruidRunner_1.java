package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.util.Properties;

public class BalancedDruidRunner_1 {

    private DruidDataSource dataSource;
    private Server jettyServer;

    public static void main(String[] args) {
        BalancedDruidRunner_1 runner = new BalancedDruidRunner_1();
        try {
            runner.startProcess();
            System.out.println("🚀 [Runner] 启动成功，按 Ctrl+C 手动停止。");
            // 注意：这里仍然保留 join 仅仅是为了 main 方法手动运行不退出
            // 在单元测试中，我们不会调用 main，而是直接调用 startProcess
            runner.jettyServer.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 核心启动逻辑：初始化数据源并启动监控服务器
     * @return 返回当前 Runner 实例以便操作
     */
    public BalancedDruidRunner_1 startProcess() throws Exception {
        System.out.println("🚀 正在初始化自动化流程...");

        // 1. 加载配置
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("DruidFactory_1.properties")) {
            if (is == null) throw new RuntimeException("找不到 DruidFactory_1.properties");
            props.load(is);
        }

        // 2. 初始化数据源
        this.dataSource = DruidFactory_Fixed_1.createBalancedDataSource();
        this.dataSource.init();

        // 3. 启动 Jetty (不使用 server.join() 阻塞)
        this.jettyServer = new Server(8080);
        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        jettyServer.setHandler(context);

        ServletHolder holder = new ServletHolder(new StatViewServlet());
        holder.setInitParameter("loginUsername", props.getProperty("loginUsername", "admin"));
        holder.setInitParameter("loginPassword", props.getProperty("loginPassword", "admin_pass"));
        context.addServlet(holder, "/druid/*");

        this.jettyServer.start();
        return this;
    }

    /**
     * 优雅停止：释放资源
     */
    public void stopProcess() throws Exception {
        if (jettyServer != null) jettyServer.stop();
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 资源已安全释放。");
    }

    // 提供 Getter 供测试类断言
    public DruidDataSource getDataSource() { return dataSource; }
    public Server getJettyServer() { return jettyServer; }
}