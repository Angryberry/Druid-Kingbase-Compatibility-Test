package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import java.io.InputStream;
import java.util.Properties;

public class DruidFactory_Fixed_1 {

    public static DruidDataSource createBalancedDataSource() throws Exception {
        Properties props = new Properties();
        try (InputStream is = DruidFactory_Fixed_1.class.getClassLoader().getResourceAsStream("DruidFactory_1.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 找不到 druid.properties");
            props.load(is);
        }

        DruidDataSource ds = new DruidDataSource();

        // 1. 基础连接映射
        ds.setDriverClassName(props.getProperty("driverClassName"));
        ds.setUrl(props.getProperty("url"));
        ds.setUsername(props.getProperty("username"));
        ds.setPassword(props.getProperty("password"));

        // 2. 池规模与超时控制
        ds.setInitialSize(Integer.parseInt(props.getProperty("initialSize", "10")));
        ds.setMaxActive(Integer.parseInt(props.getProperty("maxActive", "100")));
        ds.setMinIdle(Integer.parseInt(props.getProperty("minIdle", "10")));
        ds.setMaxWait(Long.parseLong(props.getProperty("maxWait", "60000")));

        // 3. 稳定性与保鲜逻辑 (补齐关键指标)
        ds.setValidationQuery(props.getProperty("validationQuery", "SELECT 1"));
        ds.setTestWhileIdle(Boolean.parseBoolean(props.getProperty("testWhileIdle", "true")));
        ds.setTestOnBorrow(Boolean.parseBoolean(props.getProperty("testOnBorrow", "false")));
        ds.setTestOnReturn(Boolean.parseBoolean(props.getProperty("testOnReturn", "false")));
        ds.setKeepAlive(Boolean.parseBoolean(props.getProperty("keepAlive", "true")));
        ds.setTimeBetweenEvictionRunsMillis(Long.parseLong(props.getProperty("timeBetweenEvictionRunsMillis", "60000")));

        // --- 新增：补齐空闲连接存活最小时间 ---
        ds.setMinEvictableIdleTimeMillis(Long.parseLong(props.getProperty("minEvictableIdleTimeMillis", "300000")));

        // 4. 缓存性能优化 (PSCache)
        ds.setPoolPreparedStatements(Boolean.parseBoolean(props.getProperty("poolPreparedStatements", "true")));
        ds.setMaxPoolPreparedStatementPerConnectionSize(
                Integer.parseInt(props.getProperty("maxPoolPreparedStatementPerConnectionSize", "20")));

        // 5. 过滤器与全局统计
        ds.setFilters(props.getProperty("filters", "stat"));

        // --- 新增：补齐多数据源全局汇总开关 ---
        ds.setUseGlobalDataSourceStat(Boolean.parseBoolean(props.getProperty("useGlobalDataSourceStat", "true")));

        // 慢查询与 SQL 合并等扩展属性
        ds.setConnectionProperties(props.getProperty("connectionProperties"));

        return ds;
    }
}