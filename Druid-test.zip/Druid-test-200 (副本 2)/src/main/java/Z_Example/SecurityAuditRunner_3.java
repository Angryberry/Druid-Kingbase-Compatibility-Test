package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import java.sql.Statement;

public class SecurityAuditRunner_3 {

    private DruidDataSource dataSource;

    /**
     * 自动化启动流程
     */
    public SecurityAuditRunner_3 startProcess() throws Exception {
        System.out.println("🛡️ 正在启动金融级安全型数据源自动化流程...");
        this.dataSource = DruidFactory_Security_3.createSecurityDataSource();
        this.dataSource.init();
        return this;
    }

    /**
     * 自动化验证：SQL 防火墙拦截
     * @return 如果拦截成功返回 true
     */
    public boolean verifyWallFilter() {
        System.out.println("🔥 [验证] 尝试执行无 WHERE 的 DELETE...");
        try (DruidPooledConnection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM USERS");
            return false; // 如果走到这里，说明没拦住
        } catch (Exception e) {
            System.out.println("🛡️ [拦截成功] 捕获异常: " + e.getMessage());
            return true;
        }
    }

    /**
     * 自动化验证：模拟连接泄露
     */
    public void triggerConnectionLeak() throws Exception {
        System.out.println("💧 [验证] 借走连接且不释放...");
        // 故意泄露
        dataSource.getConnection();
    }

    public void stopProcess() {
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 安全审计环境已关闭。");
    }

    public DruidDataSource getDataSource() { return dataSource; }
}