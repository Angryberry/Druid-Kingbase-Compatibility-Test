package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import java.io.InputStream;
import java.util.Properties;

public class DruidFactory_HighPerf_2 {

    public static DruidDataSource createHighPerfDataSource() throws Exception {
        Properties props = new Properties();
        try (InputStream is = DruidFactory_HighPerf_2.class.getClassLoader().getResourceAsStream("DruidFactory_2.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("找不到 DruidFactory_2.properties");
            props.load(is);
        }

        DruidDataSource ds = new DruidDataSource();

        // 1. 基础连接
        ds.setDriverClassName(props.getProperty("driverClassName"));
        ds.setUrl(props.getProperty("url"));
        ds.setUsername(props.getProperty("username"));
        ds.setPassword(props.getProperty("password"));

        // 2. 规模与超时
        ds.setInitialSize(Integer.parseInt(props.getProperty("initialSize", "50")));
        ds.setMaxActive(Integer.parseInt(props.getProperty("maxActive", "300")));
        ds.setMinIdle(Integer.parseInt(props.getProperty("minIdle", "50")));
        ds.setMaxWait(Long.parseLong(props.getProperty("maxWait", "30000")));

        // 3. 核心修复：生命周期参数 (补齐关键方法调用)
        long evictionRun = Long.parseLong(props.getProperty("timeBetweenEvictionRunsMillis", "120000"));
        ds.setTimeBetweenEvictionRunsMillis(evictionRun);

        // --- 核心补全点 1：必须手动设置这个值，否则默认值可能小于 120000 导致报错 ---
        String keepAliveInterval = props.getProperty("keepAliveBetweenTimeMillis");
        if (keepAliveInterval != null) {
            ds.setKeepAliveBetweenTimeMillis(Long.parseLong(keepAliveInterval));
        } else {
            // 如果文件没配，强制给一个符合逻辑的大于 evictionRun 的值
            ds.setKeepAliveBetweenTimeMillis(evictionRun + 30000);
        }

        // --- 核心补全点 2：存活时长区间 ---
        ds.setMinEvictableIdleTimeMillis(Long.parseLong(props.getProperty("minEvictableIdleTimeMillis", "600000")));
        String maxIdleTime = props.getProperty("maxEvictableIdleTimeMillis");
        if (maxIdleTime != null) {
            ds.setMaxEvictableIdleTimeMillis(Long.parseLong(maxIdleTime));
        }

        ds.setValidationQuery(props.getProperty("validationQuery", "SELECT 1"));
        ds.setTestWhileIdle(true);
        ds.setKeepAlive(true);

        // 4. PSCache 性能增强
        ds.setPoolPreparedStatements(true);
        ds.setMaxPoolPreparedStatementPerConnectionSize(
                Integer.parseInt(props.getProperty("maxPoolPreparedStatementPerConnectionSize", "50")));

        // 5. 性能优先过滤
        ds.setFilters(props.getProperty("filters", "stat"));
        ds.setUseGlobalDataSourceStat(true);

        return ds;
    }
}