package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.sql.Statement;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class HighPerfDruidRunner_2 {

    private DruidDataSource dataSource;
    private Server jettyServer;
    private ExecutorService executor;

    public static void main(String[] args) {
        HighPerfDruidRunner_2 runner = new HighPerfDruidRunner_2();
        try {
            runner.startProcess();
            System.out.println("🔥 [Runner] 高并发环境已就绪。");
            // 生产环境下可能需要 join，但自动化测试中不需要
            runner.jettyServer.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 自动化启动流程
     */
    public HighPerfDruidRunner_2 startProcess() throws Exception {
        System.out.println("🔥 正在启动高并发秒杀型数据源自动化流程...");

        // 1. 初始化数据源 (使用高并发配置)
        this.dataSource = DruidFactory_HighPerf_2.createHighPerfDataSource();
        long start = System.currentTimeMillis();
        this.dataSource.init();
        long end = System.currentTimeMillis();
        System.out.println("✅ 预热完成，耗时: " + (end - start) + "ms");

        // 2. 启动监控 (8081端口)
        this.jettyServer = new Server(8081);
        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        jettyServer.setHandler(context);
        context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
        this.jettyServer.start();

        return this;
    }

    /**
     * 模拟高并发秒杀压力
     * @param threadCount 线程池大小
     * @param taskCount 总任务数
     */
    public void simulateTraffic(int threadCount, int taskCount) throws InterruptedException {
        System.out.println("🚀 开始模拟秒杀压力: " + taskCount + " 个请求...");
        this.executor = Executors.newFixedThreadPool(threadCount);
        for (int i = 0; i < taskCount; i++) {
            executor.execute(() -> {
                try (DruidPooledConnection conn = dataSource.getConnection();
                     Statement stmt = conn.createStatement()) {
                    stmt.executeQuery("SELECT 1");
                } catch (Exception ignored) {}
            });
        }
        executor.shutdown();
        // 等待所有任务完成（最多等待 10 秒）
        executor.awaitTermination(10, TimeUnit.SECONDS);
    }

    public void stopProcess() throws Exception {
        if (executor != null) executor.shutdownNow();
        if (jettyServer != null) jettyServer.stop();
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 高并发资源已释放。");
    }

    // Getters for Assertions
    public DruidDataSource getDataSource() { return dataSource; }
    public Server getJettyServer() { return jettyServer; }
}