package DestroyScheduler_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class DestroyScheduler_Test {
    // 定义销毁线程池的特殊名称前缀
    public static final String DESTROY_THREAD_PREFIX = "MyCustomDestroyer-";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数 ---
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, new ThreadFactory() {
            private final AtomicInteger counter = new AtomicInteger(1);
            @Override
            public Thread newThread(Runnable r) {
                return new Thread(r, DESTROY_THREAD_PREFIX + counter.getAndIncrement());
            }
        });

        // 1. 设置自定义销毁调度器
        dataSource.setDestroyScheduler(scheduler);

        // 2. 诱发销毁行为的配置：
        // 初始 5 个连接，最小空闲 1 个。
        dataSource.setInitialSize(5);
        dataSource.setMinIdle(1);

        // 3. 【关键】将检测间隔设为 500ms（默认 60s），让销毁任务立即频繁运行
        dataSource.setTimeBetweenEvictionRunsMillis(500);
        // 只要空闲超过 100ms 就可以被回收
        dataSource.setMinEvictableIdleTimeMillis(100);

        return dataSource;
    }
}