package TestWhileIdle_Test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestWhileIdle_Test {
    // 开启空闲时检测，通常配合 timeBetweenEvictionRunsMillis 和 validationQuery 使用
    public static final boolean TEST_WHILE_IDLE = true;
    // 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒 (为了测试可以设置短一点，比如 2000 毫秒)
    public static final long TIME_BETWEEN_EVICTION_RUNS_MILLIS = 2000;

    public static void main(String[] args) {
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建并配置 Druid 数据源
        DruidDataSource dataSource = createDataSource(properties);

        try {
            // 1. 第一次获取连接并执行数据库操作
            try (Connection connection = dataSource.getConnection()) {
                System.out.println("--- 第一次获取连接 ---");
                executeDatabaseOperations(connection);
            } // 离开 try-with-resources 块，连接归还给连接池

            // 2. 模拟连接在池中空闲一段时间
            // 这里睡眠的时间大于 TIME_BETWEEN_EVICTION_RUNS_MILLIS，
            // 下次获取连接时 Druid 就会触发 testWhileIdle 逻辑执行 validationQuery
            System.out.println("--- 模拟连接空闲等待 3 秒 ---");
            Thread.sleep(3000);

            // 3. 空闲后再次获取连接
            try (Connection connection = dataSource.getConnection()) {
                System.out.println("--- 空闲后第二次获取连接 ---");
                executeDatabaseOperations(connection);
            }

        } catch (SQLException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        
        // --- 基础设置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // testWhileIdle 强依赖 validationQuery，必须配置用来检测连接是否存活的 SQL
        if ("oracle".equalsIgnoreCase(getModel(properties.getProperty("url")))) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }

        // --- testWhileIdle 核心参数设置 ---
        // 申请连接的时候检测，如果空闲时间大于 timeBetweenEvictionRunsMillis，执行 validationQuery 检测连接是否有效
        dataSource.setTestWhileIdle(TEST_WHILE_IDLE);
        dataSource.setTimeBetweenEvictionRunsMillis(TIME_BETWEEN_EVICTION_RUNS_MILLIS);
        
        // 注意：通常建议把 testOnBorrow 设为 false，把 testWhileIdle 设为 true，以兼顾性能和安全性
        dataSource.setTestOnBorrow(false); 

        return dataSource;
    }

    private static void executeDatabaseOperations(Connection connection) {
        // 插入数据
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "TestWhileIdleUser", 25);

        // 删除数据（清理测试数据）
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "TestWhileIdleUser");
    }

    // 稍微优化了一下 getModel，直接把 url 传进来判断，避免重新 new DruidDataSource 导致 url 为空
    private static String getModel(String url) {
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}