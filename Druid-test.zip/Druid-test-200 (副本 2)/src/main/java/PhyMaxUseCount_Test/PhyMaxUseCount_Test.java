package PhyMaxUseCount_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class PhyMaxUseCount_Test {
    // 设置物理连接最多重用 2 次，第 3 次获取时应该触发物理连接重建
    public static final int PHY_MAX_USE_COUNT = 2;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数 ---
        dataSource.setPhyMaxUseCount(PHY_MAX_USE_COUNT);

        // 为了精准观察单个连接的变化，我们将池大小限制为 1
        dataSource.setMaxActive(1);
        dataSource.setInitialSize(1);
        // 禁用公平锁以提高性能
        dataSource.setUseUnfairLock(true);

        return dataSource;
    }
}