package Name_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class Name_Test {
    // 定义一个独特的业务名称
    public static final String DATA_SOURCE_NAME = "Order-Database-Pool-01";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心参数设置 ---
        dataSource.setName(DATA_SOURCE_NAME);

        return dataSource;
    }
}