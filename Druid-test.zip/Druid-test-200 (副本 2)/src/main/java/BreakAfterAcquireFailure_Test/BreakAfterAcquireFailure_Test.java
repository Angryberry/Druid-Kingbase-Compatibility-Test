package BreakAfterAcquireFailure_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class BreakAfterAcquireFailure_Test {
    // 设置为 true，代表一旦获取连接失败，立即中断并抛出异常，不再重试
    public static final boolean BREAK_AFTER_ACQUIRE_FAILURE = true;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全，防止 url not set ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        dataSource.setBreakAfterAcquireFailure(true); // 核心参数

        // 【关键修改 1】：设置初始连接数为 1
        // 这样 Druid 在执行 init() 时会立即尝试建立连接
        dataSource.setInitialSize(1);

        // 【关键修改 2】：将重试间隔和次数设短，方便观察中断
        dataSource.setConnectionErrorRetryAttempts(2);
        dataSource.setTimeBetweenConnectErrorMillis(500);

        // 【关键修改 3】：缩短主线程等待时间，对齐测试逻辑
        dataSource.setMaxWait(2000);

        return dataSource;
    }
}