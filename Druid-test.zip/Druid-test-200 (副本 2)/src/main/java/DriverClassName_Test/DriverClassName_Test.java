package DriverClassName_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class DriverClassName_Test {
    // 【核心修正】V8 和 V9 版本的金仓驱动，类名几乎都是这个
    public static final String DRIVER_CLASS_NAME = "com.kingbase8.Driver";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // 1. 设置驱动类名
        dataSource.setDriverClassName(DRIVER_CLASS_NAME);

        // 2. 补全其他基础配置
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 触发初始化，验证类加载
        dataSource.setInitialSize(1);

        return dataSource;
    }
}