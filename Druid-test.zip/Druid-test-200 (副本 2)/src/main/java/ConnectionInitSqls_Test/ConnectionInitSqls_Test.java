package ConnectionInitSqls_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class ConnectionInitSqls_Test {
    // 定义初始化 SQL：设置应用名称和时区（Kingbase/PG 兼容）
    public static final String APP_NAME_SQL = "SET application_name = 'Druid_Init_Tester'";
    public static final List<String> INIT_SQLS = Arrays.asList(APP_NAME_SQL, "SET CLIENT_ENCODING TO 'UTF8'");

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置，防止 url not set ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心参数设置 ---
        // 这些 SQL 会在每个物理连接创建后立即执行
        dataSource.setConnectionInitSqls(INIT_SQLS);

        // 为了测试效果明显，我们让它初始就创建一个物理连接
        dataSource.setInitialSize(1);
        dataSource.setMaxActive(5);

        // 补全探活配置
        dataSource.setValidationQuery("SELECT 1");
        dataSource.setTestWhileIdle(true);

        return dataSource;
    }

    public static void main(String[] args) {
        // 这里的 main 方法可以保留你之前的增删改查逻辑作为冒烟测试
    }
}