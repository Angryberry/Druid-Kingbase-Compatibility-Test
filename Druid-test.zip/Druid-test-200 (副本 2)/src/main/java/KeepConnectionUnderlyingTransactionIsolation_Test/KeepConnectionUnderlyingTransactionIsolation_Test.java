package KeepConnectionUnderlyingTransactionIsolation_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class KeepConnectionUnderlyingTransactionIsolation_Test {
    // 设置为 true，告知 Druid 不要重置底层的事务隔离级别
    public static final boolean KEEP_UNDERLYING_TX_ISOLATION = true;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数 ---
        dataSource.setKeepConnectionUnderlyingTransactionIsolation(KEEP_UNDERLYING_TX_ISOLATION);

        // 为了行为验证，将池大小限制为 1
        dataSource.setMaxActive(1);
        dataSource.setInitialSize(1);

        return dataSource;
    }
}