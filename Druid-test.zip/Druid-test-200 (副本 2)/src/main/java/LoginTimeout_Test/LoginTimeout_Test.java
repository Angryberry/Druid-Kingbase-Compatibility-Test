package LoginTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.SQLException;
import java.util.Properties;

public class LoginTimeout_Test {
    // JDBC 标准 loginTimeout 单位是秒
    public static final int LOGIN_TIMEOUT_SEC = 3;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        // 故意使用一个无法访问的 IP (RFC 5737 测试保留地址)
        dataSource.setUrl("jdbc:kingbase8://192.0.2.1:54321/test");
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心参数：LoginTimeout ---
        // 这是 javax.sql.CommonDataSource 定义的方法
        dataSource.setLoginTimeout(LOGIN_TIMEOUT_SEC);

        // 配合参数：防止 Druid 默认的无限重试
        dataSource.setInitialSize(1);
        dataSource.setConnectionErrorRetryAttempts(0);
        dataSource.setBreakAfterAcquireFailure(true);

        return dataSource;
    }
}