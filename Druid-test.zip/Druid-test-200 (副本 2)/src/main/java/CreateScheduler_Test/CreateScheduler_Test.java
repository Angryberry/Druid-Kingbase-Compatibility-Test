package CreateScheduler_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class CreateScheduler_Test {
    // 定义一个带有特殊前缀的线程池，方便识别
    public static final String SCHEDULER_THREAD_NAME_PREFIX = "MyCustomScheduler-Thread-";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数：设置自定义调度器 ---
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2, new ThreadFactory() {
            private final AtomicInteger counter = new AtomicInteger(1);
            @Override
            public Thread newThread(Runnable r) {
                return new Thread(r, SCHEDULER_THREAD_NAME_PREFIX + counter.getAndIncrement());
            }
        });

        // 关键点：将外部定义的调度器传给 Druid
        dataSource.setCreateScheduler(scheduler);

        // 配合参数：为了触发异步创建，我们将连接池设大，并允许异步初始化
        dataSource.setMaxActive(5);
        dataSource.setInitialSize(0); // 初始为 0，等到用时再异步创建

        return dataSource;
    }
}