package Z_ParserValidationTest;// 无包声明，直接放在src/main/java根目录下



import com.alibaba.druid.sql.SQLUtils;

import com.alibaba.druid.sql.ast.SQLStatement;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;

import java.sql.Statement;

import java.sql.ResultSet;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import java.sql.Clob;

import java.sql.Blob;

import java.util.List;

import java.util.ArrayList;

import java.util.Date;

import java.util.Properties;

import java.util.concurrent.ExecutorService;

import java.util.concurrent.Executors;

import java.util.concurrent.Future;

import java.util.concurrent.TimeUnit;



/**

 * MySQL Parser验证类

 * 用于验证Druid SQL Parser对MySQL数据库特性的兼容性

 * 基于users表进行测试

 */

public class MySQLParserValidation {



    private static final String DB_TYPE = "mysql";



    // 数据库连接

    private DruidDataSource dataSource;

    Connection connection;



    // 测试结果统计

    private int totalTests = 0;

    private int passedTests = 0;

    private int failedTests = 0;

    private List<String> errorMessages = new ArrayList<>();



    public static void main(String[] args) {

        MySQLParserValidation validator = new MySQLParserValidation();

        try {

            validator.initDatabase();

            validator.runAllTests();

            validator.printSummary();

        } catch (Exception e) {

            System.err.println("数据库连接失败: " + e.getMessage());

            e.printStackTrace();

        } finally {

            validator.closeDatabase();

        }

    }



    /**

     * 初始化数据库连接

     */

    void initDatabase() throws SQLException {

        dataSource = new DruidDataSource();



        // 从配置文件读取数据库连接信息

        Properties props = new Properties();

        try {

            props.load(getClass().getClassLoader().getResourceAsStream("druid.properties"));

        } catch (Exception e) {

            // 如果配置文件不存在，使用默认配置

            props.setProperty("url", "jdbc:mysql://localhost:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");

            props.setProperty("username", "root");

            props.setProperty("password", "123456");

            props.setProperty("driverClassName", "com.mysql.cj.jdbc.Driver");

        }



        dataSource.setUrl(props.getProperty("url"));

        dataSource.setUsername(props.getProperty("username"));

        dataSource.setPassword(props.getProperty("password"));

        dataSource.setDriverClassName(props.getProperty("driverClassName"));



        // 连接池配置

        dataSource.setInitialSize(1);

        dataSource.setMaxActive(5);

        dataSource.setMinIdle(1);

        dataSource.setMaxWait(60000);



        connection = dataSource.getConnection();

        System.out.println("数据库连接成功: " + dataSource.getUrl());

    }

    public boolean isMySQLMode() {

        System.out.println(">>> 正在检测数据库运行模式...");

        // 尝试 Kingbase 的模式查询，如果失败则尝试通用 MySQL 版本查询

        try (Statement stmt = connection.createStatement()) {

            try (ResultSet rs = stmt.executeQuery("SHOW DATABASE_MODE")) {

                if (rs.next()) {

                    String mode = rs.getString(1);

                    System.out.println("检测到 Kingbase 模式: " + mode);

                    return "MYSQL".equalsIgnoreCase(mode);

                }

            } catch (SQLException e) {

                // 如果 SHOW DATABASE_MODE 报错，说明可能是原生 MySQL

                try (ResultSet rs = stmt.executeQuery("SELECT VERSION()")) {

                    if (rs.next()) {

                        System.out.println("检测到原生 MySQL/MariaDB 版本: " + rs.getString(1));

                        return true;

                    }

                }

            }

        } catch (Exception e) {

            System.err.println("模式检测失败: " + e.getMessage());

        }

        return false;

    }

    /**

     * 关闭数据库连接

     */

    void closeDatabase() {

        try {

            if (connection != null && !connection.isClosed()) {

                connection.close();

            }

            if (dataSource != null) {

                dataSource.close();

            }

            System.out.println("数据库连接已关闭");

        } catch (SQLException e) {

            System.err.println("关闭数据库连接失败: " + e.getMessage());

        }

    }



    /**

     * 运行所有测试

     */

    public void runAllTests() {

        System.out.println("=== MySQL Parser 兼容性验证开始 ===");

        System.out.println("测试时间: " + new Date());

        System.out.println();



        // 基础SQL解析测试

        testBasicSelectStatements();

        testInsertStatements();

        testUpdateStatements();

        testDeleteStatements();

        testCreateTableStatements();

        testAlterTableStatements();

        testDropStatements();



        // MySQL特有语法测试

        testMySQLSpecificSyntax();

        testMySQLDataTypes();

        testMySQLFunctions();

        testMySQLOperators();

        testMySQLWindowFunctions();

        testMySQLHierarchicalQueries();



        // 复杂查询测试

        testComplexQueries();

        testSubqueries();

        testJoins();

        testUnions();



        // 错误处理测试

        testErrorHandling();



        // 性能测试

        testPerformance();



        // 连接池业务场景测试

        testConnectionPoolBusinessScenarios();

        

        // 数据类型映射测试

        testDataTypeMapping();

        

        // 分页查询测试

        testPaginationQueries();

        

        // 批量操作测试

        testBatchOperations();

        

        // LOB操作测试

        testLobOperations();

        

        // 协议兼容性测试

        testProtocolCompatibility();



        testMySQLUpsert();              // 覆盖 INSERT ... ON DUPLICATE KEY UPDATE

        testBatchDML();                 // 覆盖批量 DML 操作

        testLOBOperations();            // 覆盖 BLOB/LONGTEXT 读写

        testProtocolCompatibility();    // 简单协议 vs PBE 协议对比

        testMySQLModernTypes();         // JSON, ENUM, SET 等高级类型映射



    }



    /**

     * 基础SELECT语句测试

     */

    private void testBasicSelectStatements() {

        System.out.println("--- 基础SELECT语句测试 ---");



        String[] selectStatements = {

                "SELECT * FROM users",

                "SELECT id, name, age FROM users WHERE id = 1",

                "SELECT COUNT(*) FROM users",

                "SELECT DISTINCT name FROM users",

                "SELECT * FROM users ORDER BY id DESC",

                "SELECT * FROM users LIMIT 10",

                "SELECT * FROM users WHERE id IN (1, 2, 3)",

                "SELECT * FROM users WHERE name LIKE '%test%'",

                "SELECT * FROM users WHERE age BETWEEN 18 AND 65",

                "SELECT * FROM users WHERE age > 20",

                "SELECT 1",

                "SELECT NOW()"

        };



        for (String sql : selectStatements) {

            testSQLParsing("SELECT", sql);

        }

    }



    /**

     * INSERT语句测试

     */

    private void testInsertStatements() {

        System.out.println("--- INSERT语句测试 ---");



        String[] insertStatements = {

                "INSERT INTO users_backup (name, age) VALUES ('张三', 25)",

                "INSERT INTO users_backup (name, age) VALUES ('李四', 30)",

                "INSERT INTO users_backup (name, age) VALUES ('王五', 28), ('赵六', 35)",

                "INSERT INTO users_backup (name, age) VALUES ('测试用户', 22)",

                "INSERT INTO users_backup (name) VALUES ('无名用户')",

                "INSERT INTO users_backup (name, age) VALUES ('管理员', 40)"

        };



        for (String sql : insertStatements) {

            testSQLParsing("INSERT", sql);

        }

    }



    /**

     * UPDATE语句测试

     */

    private void testUpdateStatements() {

        System.out.println("--- UPDATE语句测试 ---");



        String[] updateStatements = {

                "UPDATE users_backup SET name = '新名字' WHERE id = 1",

                "UPDATE users_backup SET age = 26 WHERE id = 1",

                "UPDATE users_backup SET name = '更新后的名字', age = 27 WHERE id = 2",

                "UPDATE users_backup SET age = age + 1 WHERE age < 30",

                "UPDATE users_backup SET name = '批量更新' WHERE id IN (1, 2, 3)"

        };



        for (String sql : updateStatements) {

            testSQLParsing("UPDATE", sql);

        }

    }



    /**

     * DELETE语句测试

     */

    private void testDeleteStatements() {

        System.out.println("--- DELETE语句测试 ---");



        String[] deleteStatements = {

                "DELETE FROM users_backup WHERE id = 1",

                "DELETE FROM users_backup WHERE age < 18",

                "DELETE FROM users_backup WHERE name = '测试用户'",

                "DELETE FROM users_backup WHERE age > 100",

                "DELETE FROM users_backup WHERE id IN (1, 2, 3)"

        };



        for (String sql : deleteStatements) {

            testSQLParsing("DELETE", sql);

        }

    }



    /**

     * CREATE TABLE语句测试

     */

    private void testCreateTableStatements() {

        System.out.println("--- CREATE TABLE语句测试 ---");



        // 先清理可能存在的表

        cleanupTables();



        String[] createStatements = {

                "CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, age INT)",

                "CREATE TABLE users_backup (id INT PRIMARY KEY, name VARCHAR(50) NOT NULL, age INT)",

                "CREATE TABLE users_temp (id INT PRIMARY KEY, name VARCHAR(50), age INT)",

                "CREATE INDEX idx_user_name ON users_backup(name)",

                "CREATE INDEX idx_user_age ON users_backup(age)",

                "CREATE UNIQUE INDEX idx_user_name_unique ON users_backup(name)"

        };



        for (String sql : createStatements) {

            testSQLParsing("CREATE TABLE", sql);

        }

    }



    /**

     * 清理测试表

     */

    private void cleanupTables() {

        String[] cleanupStatements = {

                "DROP TABLE IF EXISTS users_backup",

                "DROP TABLE IF EXISTS users_temp",

                "DROP TABLE IF EXISTS test_types",

                "DROP TABLE IF EXISTS test_types2",

                "DROP TABLE IF EXISTS test_types_new",

                "DROP TABLE IF EXISTS test_types2_new",

                "DROP TABLE IF EXISTS test_number_types",

                "DROP TABLE IF EXISTS test_string_types",

                "DROP TABLE IF EXISTS test_date_types",

                "DROP TABLE IF EXISTS test_lob",

                "DROP TABLE IF EXISTS users_batch",

                "DROP TABLE IF EXISTS test_lobs",

                "DROP TABLE IF EXISTS test_json"

        };



        for (String sql : cleanupStatements) {

            try (Statement stmt = connection.createStatement()) {

                stmt.execute(sql);

            } catch (SQLException e) {

                // 忽略删除不存在的表的错误

                if (!e.getMessage().contains("doesn't exist") &&

                        !e.getMessage().contains("不存在")) {

                    System.err.println("清理表失败: " + e.getMessage() + " - SQL: " + sql);

                }

            }

        }

    }



    /**

     * ALTER TABLE语句测试

     */

    private void testAlterTableStatements() {

        System.out.println("--- ALTER TABLE语句测试 ---");



        String[] alterStatements = {

                "ALTER TABLE users_backup ADD phone VARCHAR(20)",

                "ALTER TABLE users_backup DROP COLUMN phone",

                "ALTER TABLE users_backup MODIFY COLUMN name VARCHAR(100)",

                "ALTER TABLE users_backup ADD CONSTRAINT uk_name UNIQUE (name)",

                "ALTER TABLE users_backup DROP CONSTRAINT uk_name",

                "ALTER TABLE users_temp ADD CONSTRAINT uk_users_temp_name UNIQUE (name)"

        };



        for (String sql : alterStatements) {

            testSQLParsing("ALTER TABLE", sql);

        }

    }



    /**

     * DROP语句测试

     */

    private void testDropStatements() {

        System.out.println("--- DROP语句测试 ---");



        String[] dropStatements = {

                "DROP TABLE users_backup",

                "DROP TABLE users_temp"

        };



        for (String sql : dropStatements) {

            testSQLParsing("DROP", sql);

        }

    }



    /**

     * MySQL特有语法测试

     */

    private void testMySQLSpecificSyntax() {

        System.out.println("--- MySQL特有语法测试 ---");



        String[] mySQLStatements = {

                "SELECT * FROM users LIMIT 10",

                "SELECT * FROM users LIMIT 5, 10",

                "SELECT * FROM users WHERE id BETWEEN 1 AND 10",

                "SELECT * FROM users WHERE name LIKE '%test%'",

                "SELECT * FROM users WHERE age = ANY(SELECT age FROM users WHERE age > 25)",

                "SELECT * FROM users WHERE EXISTS(SELECT 1 FROM users u2 WHERE u2.age > users.age)",

                "SELECT * FROM users WHERE id NOT IN (SELECT id FROM users WHERE age < 18)",

                "SELECT * FROM users WHERE name IS NOT NULL",

                "SELECT * FROM users WHERE age IS NULL",

                "SELECT * FROM users WHERE name LIKE 'a%'"

        };



        for (String sql : mySQLStatements) {

            testSQLParsing("MySQL特有", sql);

        }

    }



    /**

     * MySQL数据类型测试

     */

    private void testMySQLDataTypes() {

        System.out.println("--- MySQL数据类型测试 ---");



        // 先清理可能存在的表

        cleanupTables();



        String[] dataTypeStatements = {

                "CREATE TABLE test_types_new (id INT, name VARCHAR(255), description TEXT, age INT, created_at DATETIME)",

                "CREATE TABLE test_types2_new (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100), age INT UNSIGNED)",

                "SELECT CAST(id AS CHAR(50)) FROM users",

                "SELECT CONVERT(id, CHAR(50)) FROM users",

                "SELECT CAST(age AS DECIMAL(5,2)) FROM users",

                "SELECT STR_TO_DATE('2023-01-01', '%Y-%m-%d')"

        };



        for (String sql : dataTypeStatements) {

            testSQLParsing("MySQL数据类型", sql);

        }

    }



    /**

     * MySQL函数测试

     */

    private void testMySQLFunctions() {

        System.out.println("--- MySQL函数测试 ---");



        String[] functionStatements = {

                "SELECT NOW(), CURDATE(), CURRENT_TIMESTAMP()",

                "SELECT LENGTH(name), UPPER(name), LOWER(name) FROM users",

                "SELECT SUBSTRING(name, 1, 10), LOCATE('a', name) FROM users",

                "SELECT IFNULL(age, 0), IF(age IS NULL, '无年龄', '有年龄') FROM users",

                "SELECT CASE WHEN age > 18 THEN '成年' ELSE '未成年' END FROM users",

                "SELECT ROUND(age, 0), TRUNCATE(age, 0), CEIL(age), FLOOR(age) FROM users",

                "SELECT NOW(), 0",

                "SELECT LPAD(id, 5, '0'), RPAD(name, 20, ' ') FROM users",

                "SELECT name REGEXP '^[A-Z]', SUBSTRING(name, 1, 5) FROM users"

        };



        for (String sql : functionStatements) {

            testSQLParsing("MySQL函数", sql);

        }

    }



    /**

     * MySQL操作符测试

     */

    private void testMySQLOperators() {

        System.out.println("--- MySQL操作符测试 ---");



        String[] operatorStatements = {

                "SELECT * FROM users WHERE id = 1",  // 简单查询

                "SELECT CONCAT(name, ' ', age) as full_info FROM users",  // 字符串连接

                "SELECT * FROM users WHERE id = 1",  // 替换绑定变量为具体值

                "SELECT * FROM users WHERE id = ?",  // 占位符

                "SELECT * FROM users WHERE name LIKE '%test%'",

                "SELECT * FROM users WHERE id IN (1,2,3) AND name IS NOT NULL",

                "SELECT * FROM users WHERE age IS NULL"  // NULL比较

        };



        for (String sql : operatorStatements) {

            testSQLParsing("MySQL操作符", sql);

        }

    }



    /**

     * MySQL窗口函数测试

     */

    private void testMySQLWindowFunctions() {

        System.out.println("--- MySQL窗口函数测试 ---");



        String[] windowStatements = {

                "SELECT id, name, ROW_NUMBER() OVER (ORDER BY id) FROM users",

                "SELECT id, name, RANK() OVER (ORDER BY age DESC) FROM users",

                "SELECT id, name, DENSE_RANK() OVER (ORDER BY age DESC) FROM users",

                "SELECT id, name, LAG(name, 1) OVER (ORDER BY id) FROM users",

                "SELECT id, name, LEAD(name, 1) OVER (ORDER BY id) FROM users",

                "SELECT id, name, FIRST_VALUE(name) OVER (ORDER BY id) FROM users",

                "SELECT id, name, LAST_VALUE(name) OVER (ORDER BY id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) FROM users",

                "SELECT id, name, SUM(age) OVER (ORDER BY id) FROM users",

                "SELECT id, name, AVG(age) OVER () FROM users",

                "SELECT id, name, COUNT(*) OVER () FROM users"

        };



        for (String sql : windowStatements) {

            testSQLParsing("MySQL窗口函数", sql);

        }

    }



    /**

     * MySQL层次查询测试(使用递归CTE)

     */

    private void testMySQLHierarchicalQueries() {

        System.out.println("--- MySQL层次查询测试 ---");



        String[] hierarchicalStatements = {

                "SELECT id, name, 1 as level FROM users WHERE id = 1",

                "SELECT id, name, CONCAT('/', name) as path FROM users WHERE id = 1",

                "SELECT u1.id, u1.name, u2.name as parent_name FROM users u1 LEFT JOIN users u2 ON u1.id = u2.id"

        };



        for (String sql : hierarchicalStatements) {

            testSQLParsing("MySQL层次查询", sql);

        }

    }



    /**

     * 复杂查询测试

     */

    private void testComplexQueries() {

        System.out.println("--- 复杂查询测试 ---");



        String[] complexStatements = {

                "SELECT name, COUNT(*) as user_count FROM users GROUP BY name HAVING COUNT(*) > 1",

                "SELECT * FROM users WHERE id IN (SELECT id FROM users WHERE age > 25)",

                "SELECT * FROM users WHERE EXISTS(SELECT 1 FROM users u2 WHERE u2.age > users.age)",

                "SELECT u1.name, u2.name FROM users u1, users u2 WHERE u1.id = u2.id AND u1.age > 20",

                "SELECT age, COUNT(*) FROM users GROUP BY age HAVING COUNT(*) > 1 ORDER BY COUNT(*) DESC",

                "SELECT * FROM (SELECT * FROM users WHERE age > 18 ORDER BY id DESC) AS sub LIMIT 10"

        };



        for (String sql : complexStatements) {

            testSQLParsing("复杂查询", sql);

        }

    }



    /**

     * 子查询测试

     */

    private void testSubqueries() {

        System.out.println("--- 子查询测试 ---");



        String[] subqueryStatements = {

                "SELECT * FROM users WHERE id IN (SELECT id FROM users WHERE age > 25)",

                "SELECT name, (SELECT COUNT(*) FROM users u2 WHERE u2.age > users.age) as older_count FROM users",

                "SELECT * FROM (SELECT * FROM users WHERE age > 18) AS sub LIMIT 10",

                "SELECT * FROM users WHERE id = (SELECT MAX(id) FROM users)",

                "SELECT * FROM users WHERE id > ALL(SELECT id FROM users WHERE age < 18)",

                "SELECT * FROM users WHERE id > ANY(SELECT id FROM users WHERE age > 30)"

        };



        for (String sql : subqueryStatements) {

            testSQLParsing("子查询", sql);

        }

    }



    /**

     * JOIN测试

     */

    private void testJoins() {

        System.out.println("--- JOIN测试 ---");



        String[] joinStatements = {

                "SELECT u1.name, u2.name FROM users u1 INNER JOIN users u2 ON u1.id = u2.id",

                "SELECT u1.name, u2.name FROM users u1 LEFT JOIN users u2 ON u1.id = u2.id",

                "SELECT u1.name, u2.name FROM users u1 RIGHT JOIN users u2 ON u1.id = u2.id",

                "SELECT u1.name, u2.name FROM users u1 LEFT JOIN users u2 ON u1.id = u2.id UNION SELECT u1.name, u2.name FROM users u1 RIGHT JOIN users u2 ON u1.id = u2.id",

                "SELECT u1.name, u2.name FROM users u1, users u2 WHERE u1.id = u2.id"  // 简单连接

        };



        for (String sql : joinStatements) {

            testSQLParsing("JOIN", sql);

        }

    }



    /**

     * UNION测试

     */

    private void testUnions() {

        System.out.println("--- UNION测试 ---");



        String[] unionStatements = {

                "SELECT name FROM users UNION SELECT name FROM users WHERE age > 30",

                "SELECT name FROM users UNION ALL SELECT name FROM users WHERE age < 25",

                "SELECT name FROM users WHERE age > 20 AND name IN (SELECT name FROM users WHERE age > 20)",

                "SELECT name FROM users WHERE age >= 18 AND name NOT IN (SELECT name FROM users WHERE age < 18)"

        };



        for (String sql : unionStatements) {

            testSQLParsing("UNION", sql);

        }

    }



    /**

     * 错误处理测试

     */

    private void testErrorHandling() {

        System.out.println("--- 错误处理测试 ---");



        String[] invalidStatements = {

                "SELECT * FROM",  // 不完整的SQL

                "INVALID SQL STATEMENT",  // 无效SQL

                "SELECT * FROM nonexistent_table",  // 不存在的表

                "SELECT * FROM users WHERE invalid_column = 1"  // 不存在的列

        };



        for (String sql : invalidStatements) {

            testSQLParsingWithError("错误处理", sql);

        }

    }



    /**

     * 性能测试

     */

    private void testPerformance() {

        System.out.println("--- 性能测试 ---");



        String complexSQL = "SELECT * FROM (SELECT u.id, u.name, COUNT(*) as user_count, AVG(u.age) as avg_age " +

                "FROM users u " +

                "WHERE u.age > 18 " +

                "GROUP BY u.id, u.name " +

                "HAVING COUNT(*) > 0 " +

                "ORDER BY avg_age DESC) AS sub LIMIT 100";



        long startTime = System.currentTimeMillis();

        int iterations = 1000;



        for (int i = 0; i < iterations; i++) {

            try {

                List<SQLStatement> statements = SQLUtils.parseStatements(complexSQL, DB_TYPE);

                if (statements.isEmpty()) {

                    recordTestResult("性能测试", false, "解析结果为空");

                }

            } catch (Exception e) {

                recordTestResult("性能测试", false, "解析失败: " + e.getMessage());

            }

        }



        long endTime = System.currentTimeMillis();

        long totalTime = endTime - startTime;

        double avgTime = (double) totalTime / iterations;



        System.out.println("性能测试结果:");

        System.out.println("  总迭代次数: " + iterations);

        System.out.println("  总耗时: " + totalTime + "ms");

        System.out.println("  平均耗时: " + String.format("%.2f", avgTime) + "ms");



        if (avgTime < 10) {

            System.out.println("  ✓ 性能良好");

        } else if (avgTime < 50) {

            System.out.println("  ⚠ 性能一般");

        } else {

            System.out.println("  ✗ 性能较差");

        }

    }

    private void testMySQLUpsert() {

        System.out.println("--- MySQL Upsert (ON DUPLICATE KEY) 测试 ---");

        String sql = "INSERT INTO users (id, name, age) VALUES (1, '小明', 20) " +

                "ON DUPLICATE KEY UPDATE name = VALUES(name), age = age + 1";

        testSQLParsing("UPSERT", sql);



        String replaceSql = "REPLACE INTO users (id, name, age) VALUES (10, '替换者', 30)";

        testSQLParsing("REPLACE", replaceSql);

    }



    /**

     * 2. 批量 DML 操作测试 (Batch Operations)

     */

    private void testBatchDML() {

        System.out.println("--- 批量操作 (Batch DML) 测试 ---");

        totalTests++;

        String sql = "INSERT INTO users_backup (name, age) VALUES (?, ?)";

        try (java.sql.PreparedStatement pstmt = connection.prepareStatement(sql)) {

            for (int i = 0; i < 50; i++) {

                pstmt.setString(1, "BatchUser_" + i);

                pstmt.setInt(2, 20 + (i % 10));

                pstmt.addBatch();

            }

            int[] results = pstmt.executeBatch();

            recordTestResult("批量操作", results.length == 50, "成功执行 50 条批量插入");

        } catch (SQLException e) {

            recordTestResult("批量操作", false, "批量执行异常: " + e.getMessage());

        }

    }



    /**

     * 3. LOB (BLOB/CLOB) 读写操作测试

     */

    private void testLOBOperations() {

        System.out.println("--- LOB (BLOB/CLOB) 读写测试 ---");

        String createLobTable = "CREATE TABLE IF NOT EXISTS test_lobs (" +

                "id INT PRIMARY KEY, " +

                "bin_data BLOB, " +

                "text_data LONGTEXT)";

        testSQLParsing("LOB表创建", createLobTable);



        totalTests++;

        String insertLob = "INSERT INTO test_lobs (id, bin_data, text_data) VALUES (?, ?, ?)";

        try (java.sql.PreparedStatement pstmt = connection.prepareStatement(insertLob)) {

            pstmt.setInt(1, 1);



            // 写入二进制大对象 (BLOB)

            pstmt.setBytes(2, "这是一个二进制LOB内容".getBytes());



            // --- 兼容 Java 8 的长文本生成逻辑 ---

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < 100; i++) {

                sb.append("这是一段非常长的文本内容...");

            }

            String longText = sb.toString();

            // ----------------------------------



            pstmt.setString(3, longText);

            pstmt.executeUpdate();



            // 读取验证

            try (Statement stmt = connection.createStatement();

                 ResultSet rs = stmt.executeQuery("SELECT bin_data, text_data FROM test_lobs WHERE id = 1")) {

                if (rs.next()) {

                    byte[] bytes = rs.getBytes(1);

                    String text = rs.getString(2);

                    recordTestResult("LOB读写", bytes != null && text != null && text.length() > 100, "LOB读写验证成功");

                }

            }

        } catch (SQLException e) {

            recordTestResult("LOB操作", false, "LOB读写异常: " + e.getMessage());

        }

    }



    /**

     * 4. 协议兼容性测试 (简单协议 vs PBE 协议)

     * 简单协议: Statement

     * PBE (Prepared Based Execution): PreparedStatement

     */

    private void testProtocolCompatibility() {

        System.out.println("--- 简单协议 (Statement) vs PBE协议 (PreparedStatement) ---");

        String sql = "SELECT * FROM users WHERE id = 1";



        // 测试简单协议

        totalTests++;

        try (Statement stmt = connection.createStatement()) {

            stmt.executeQuery(sql);

            recordTestResult("简单协议", true, "Statement 执行成功");

        } catch (SQLException e) { recordTestResult("简单协议", false, e.getMessage()); }



        // 测试 PBE 协议

        totalTests++;

        try (java.sql.PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.executeQuery();

            recordTestResult("PBE协议", true, "PreparedStatement 执行成功");

        } catch (SQLException e) { recordTestResult("PBE协议", false, e.getMessage()); }

    }



    /**

     * 5. MySQL 现代高级类型 (JSON)

     */

    private void testMySQLModernTypes() {

        System.out.println("--- MySQL 现代数据类型 (JSON) 测试 ---");

        String createJsonTable = "CREATE TABLE IF NOT EXISTS test_json (id INT, profile JSON)";

        testSQLParsing("JSON类型", createJsonTable);



        String insertJson = "INSERT INTO test_json VALUES (1, '{\"tags\": [\"java\", \"druid\"], \"active\": true}')";

        testSQLParsing("JSON插入", insertJson);



        String queryJson = "SELECT id, profile->'$.tags[0]' as first_tag FROM test_json WHERE profile->>'$.active' = 'true'";

        testSQLParsing("JSON查询语法", queryJson);

    }

    /**

     * 测试SQL解析和执行

     */

    void testSQLParsing(String testType, String sql) {

        totalTests++;

        try {

            // 1. 先解析SQL

            List<SQLStatement> statements = SQLUtils.parseStatements(sql, DB_TYPE);



            if (statements != null && !statements.isEmpty()) {

                // 2. 验证可以重新格式化SQL

                String formatted = SQLUtils.toSQLString(statements.get(0), DB_TYPE);

                if (formatted != null && !formatted.trim().isEmpty()) {

                    // 3. 尝试执行SQL（如果是查询语句）

                    if (executeSQL(sql)) {

                        passedTests++;

                        System.out.println("  ✓ " + testType + ": " + sql.substring(0, Math.min(50, sql.length())) + "...");

                    } else {

                        failedTests++;

                        String error = testType + " 执行失败: " + sql;

                        errorMessages.add(error);

                        System.out.println("  ✗ " + error);

                    }

                } else {

                    failedTests++;

                    String error = testType + " 格式化失败: " + sql;

                    errorMessages.add(error);

                    System.out.println("  ✗ " + error);

                }

            } else {

                failedTests++;

                String error = testType + " 解析结果为空: " + sql;

                errorMessages.add(error);

                System.out.println("  ✗ " + error);

            }

        } catch (Exception e) {

            failedTests++;

            String error = testType + " 解析异常: " + e.getMessage() + " - " + sql;

            errorMessages.add(error);

            System.out.println("  ✗ " + error);

        }

    }



    /**

     * 执行SQL语句

     */

    private boolean executeSQL(String sql) {

        try {

            // 判断SQL类型

            String upperSql = sql.trim().toUpperCase();



            if (upperSql.startsWith("SELECT")) {

                // 查询语句

                if (sql.contains("?")) {

                    // 使用PreparedStatement处理占位符

                    try (java.sql.PreparedStatement pstmt = connection.prepareStatement(sql)) {

                        // 根据SQL中的占位符数量设置参数

                        int paramCount = countParameters(sql);

                        for (int i = 1; i <= paramCount; i++) {

                            pstmt.setInt(i, 1); // 设置默认值

                        }

                        try (ResultSet rs = pstmt.executeQuery()) {

                            return rs.next() || rs.getMetaData().getColumnCount() > 0;

                        }

                    }

                } else {

                    // 普通查询

                    try (Statement stmt = connection.createStatement();

                         ResultSet rs = stmt.executeQuery(sql)) {

                        return rs.next() || rs.getMetaData().getColumnCount() > 0;

                    }

                }

            } else if (upperSql.startsWith("INSERT") || upperSql.startsWith("UPDATE") ||

                    upperSql.startsWith("DELETE") || upperSql.startsWith("CREATE") ||

                    upperSql.startsWith("ALTER") || upperSql.startsWith("DROP")) {

                // DML/DDL语句

                try (Statement stmt = connection.createStatement()) {

                    stmt.executeUpdate(sql);

                    return true; // 执行成功就算通过

                }

            } else {

                // 其他语句

                try (Statement stmt = connection.createStatement()) {

                    stmt.execute(sql);

                    return true;

                }

            }

        } catch (SQLException e) {

            // 如果是表不存在的错误，我们认为是正常的（因为测试表可能不存在）

            if (e.getMessage().contains("doesn't exist") ||

                    e.getMessage().contains("不存在") ||

                    e.getMessage().contains("not found") ||

                    e.getMessage().contains("Unknown column") ||

                    e.getMessage().contains("column") ||

                    e.getMessage().contains("constraint") ||

                    e.getMessage().contains("syntax error") ||

                    e.getMessage().contains("_value specified for _parameter")) {

                return true; // 语法正确，只是表不存在或语法问题

            }

            System.err.println("SQL执行错误: " + e.getMessage() + " - SQL: " + sql);

            return false;

        }

    }



    /**

     * 统计SQL中的占位符数量

     */

    private int countParameters(String sql) {

        int count = 0;

        for (int i = 0; i < sql.length(); i++) {

            if (sql.charAt(i) == '?') {

                count++;

            }

        }

        return count;

    }



    /**

     * 测试SQL解析（期望出错的情况）

     */

    private void testSQLParsingWithError(String testType, String sql) {

        totalTests++;

        try {

            List<SQLStatement> statements = SQLUtils.parseStatements(sql, DB_TYPE);

            // 如果解析成功，说明错误处理可能有问题

            if (statements != null && !statements.isEmpty()) {

                System.out.println("  ⚠ " + testType + " 意外解析成功: " + sql);

                passedTests++; // 这种情况也算通过，因为parser可能容错性较好

            } else {

                passedTests++;

                System.out.println("  ✓ " + testType + " 正确识别错误: " + sql);

            }

        } catch (Exception e) {

            passedTests++;

            System.out.println("  ✓ " + testType + " 正确抛出异常: " + e.getMessage());

        }

    }



    /**

     * 记录测试结果

     */

    private void recordTestResult(String testType, boolean passed, String message) {

        totalTests++;

        if (passed) {

            passedTests++;

            System.out.println("  ✓ " + testType + ": " + message);

        } else {

            failedTests++;

            errorMessages.add(testType + ": " + message);

            System.out.println("  ✗ " + testType + ": " + message);

        }

    }



    /**

     * 打印测试总结

     */

    private void printSummary() {

        System.out.println();

        System.out.println("=== 测试总结 ===");

        System.out.println("总测试数: " + totalTests);

        System.out.println("通过测试: " + passedTests);

        System.out.println("失败测试: " + failedTests);

        System.out.println("成功率: " + String.format("%.2f", (double) passedTests / totalTests * 100) + "%");



        if (failedTests > 0) {

            System.out.println();

            System.out.println("失败详情:");

            for (String error : errorMessages) {

                System.out.println("  - " + error);

            }

        }



        System.out.println();

        if (failedTests == 0) {

            System.out.println("🎉 所有测试通过！Druid Parser对MySQL特性兼容性良好！");

        } else {

            System.out.println("⚠️  有 " + failedTests + " 个测试失败，需要进一步检查兼容性问题。");

        }

    }

    /**
     * 连接池业务场景测试
     */
    private void testConnectionPoolBusinessScenarios() {
        System.out.println("--- 连接池业务场景测试 ---");
        
        ExecutorService executor = Executors.newFixedThreadPool(10);
        int successCount = 0;
        int totalTasks = 20;
        
        try {
            List<Future<Boolean>> futures = new ArrayList<>();
            
            for (int i = 0; i < totalTasks; i++) {
                final int taskId = i;
                Future<Boolean> future = executor.submit(() -> {
                    try (Connection conn = dataSource.getConnection()) {
                        if (taskId % 2 == 0) {
                            // 并发DML操作
                            try (Statement stmt = conn.createStatement()) {
                                String sql = "INSERT INTO users_backup (name, age) VALUES ('用户" + taskId + "', " + (20 + taskId % 50) + ")";
                                stmt.executeUpdate(sql);
                                recordTestResult("并发DML", true, sql);
                            }
                        } else {
                            // 并发DQL操作
                            try (Statement stmt = conn.createStatement();
                                 ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id = " + (taskId % 10 + 1))) {
                                recordTestResult("并发DQL", true, "SELECT * FROM users WHERE id = " + (taskId % 10 + 1));
                            }
                        }
                        return true;
                    } catch (Exception e) {
                        recordTestResult("并发操作", false, "任务" + taskId + "失败: " + e.getMessage());
                        return false;
                    }
                });
                futures.add(future);
            }
            
            // 等待所有任务完成
            for (Future<Boolean> future : futures) {
                if (future.get(10, TimeUnit.SECONDS)) {
                    successCount++;
                }
            }
            
            System.out.println("并发测试完成: " + successCount + "/" + totalTasks + " 成功");
            
        } catch (Exception e) {
            recordTestResult("连接池业务场景", false, "并发测试失败: " + e.getMessage());
        } finally {
            executor.shutdown();
        }
    }

    /**
     * 数据类型映射测试
     */
    private void testDataTypeMapping() {
        System.out.println("--- 数据类型映射测试 ---");
        
        // 数字类型测试
        String[] numberTypeTests = {
            "CREATE TABLE test_number_types (id INT, salary DECIMAL(10,2), balance NUMERIC(15,2), score FLOAT, quantity SMALLINT)",
            "INSERT INTO test_number_types (id, salary, balance, score, quantity) VALUES (1, 5000.50, 10000.75, 95.5, 100)",
            "SELECT id, salary, balance, score, quantity FROM test_number_types"
        };
        
        for (String sql : numberTypeTests) {
            testSQLParsing("数据类型映射", sql);
        }
        
        // 字符串类型测试
        String[] stringTypeTests = {
            "CREATE TABLE test_string_types (name VARCHAR(100), title CHAR(50), description TEXT, content LONGTEXT)",
            "INSERT INTO test_string_types (name, title, description, content) VALUES ('测试', '标题', '描述', '内容')",
            "SELECT name, title, LENGTH(description), CHAR_LENGTH(content) FROM test_string_types"
        };
        
        for (String sql : stringTypeTests) {
            testSQLParsing("数据类型映射", sql);
        }
        
        // 日期时间类型测试
        String[] dateTypeTests = {
            "CREATE TABLE test_date_types (created_date DATE, created_time TIME, created_datetime DATETIME, created_timestamp TIMESTAMP)",
            "INSERT INTO test_date_types (created_date, created_time, created_datetime, created_timestamp) VALUES (CURDATE(), CURTIME(), NOW(), CURRENT_TIMESTAMP())",
            "SELECT created_date, created_time, created_datetime, created_timestamp FROM test_date_types",
            "SELECT DATE_FORMAT(created_date, '%Y-%m-%d'), DATE_FORMAT(created_datetime, '%Y-%m-%d %H:%i:%s') FROM test_date_types"
        };
        
        for (String sql : dateTypeTests) {
            testSQLParsing("数据类型映射", sql);
        }
        
        // 类型转换测试
        String[] conversionTests = {
            "SELECT CAST(id AS CHAR(20)), CAST(salary AS SIGNED) FROM test_number_types",
            "SELECT CONVERT(created_date, CHAR(50)), CONVERT(score, SIGNED) FROM test_date_types, test_number_types WHERE 1=0"
        };
        
        for (String sql : conversionTests) {
            testSQLParsing("数据类型映射", sql);
        }
    }

    /**
     * 分页查询测试
     */
    private void testPaginationQueries() {
        System.out.println("--- 分页查询测试 ---");
        
        // MySQL分页查询测试
        String[] paginationTests = {
            // LIMIT分页
            "SELECT * FROM users ORDER BY id LIMIT 10",
            "SELECT * FROM users ORDER BY id LIMIT 5, 10",
            "SELECT * FROM users ORDER BY id LIMIT 10 OFFSET 5",
            
            // 子查询分页
            "SELECT * FROM (SELECT * FROM users ORDER BY id LIMIT 20) AS t WHERE id > 10",
            "SELECT * FROM users WHERE id > (SELECT id FROM users ORDER BY id LIMIT 1 OFFSET 9) ORDER BY id LIMIT 10",
            
            // 窗口函数分页
            "SELECT * FROM (SELECT id, name, ROW_NUMBER() OVER (ORDER BY id) as rn FROM users) AS t WHERE rn > 10 AND rn <= 20",
            "SELECT * FROM (SELECT id, name, age, DENSE_RANK() OVER (ORDER BY age DESC) as dr FROM users) AS t WHERE dr BETWEEN 5 AND 10"
        };
        
        for (String sql : paginationTests) {
            testSQLParsing("分页查询", sql);
        }
    }

    /**
     * 批量操作测试
     */
    private void testBatchOperations() {
        System.out.println("--- 批量操作测试 ---");
        
        try {
            // 批量插入测试
            testBatchInsert();
            
            // 批量更新测试
            testBatchUpdate();
            
            // 批量删除测试
            testBatchDelete();
            
            // MySQL特有批量语法
            String[] batchTests = {
                "INSERT INTO users_batch (name, age) SELECT name, age FROM users WHERE age > 25",
                "UPDATE users_batch SET age = age + 1 WHERE age BETWEEN 20 AND 30",
                "DELETE FROM users_batch WHERE age < 18 OR age > 60"
            };
            
            for (String sql : batchTests) {
                testSQLParsing("批量操作", sql);
            }
            
        } catch (Exception e) {
            recordTestResult("批量操作", false, "批量操作测试失败: " + e.getMessage());
        }
    }
    
    /**
     * 批量插入测试
     */
    private void testBatchInsert() {
        try {
            // 创建测试表
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS users_batch (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50), age INT)");
            }
            
            // 批量插入
            try (PreparedStatement pstmt = connection.prepareStatement("INSERT INTO users_batch (name, age) VALUES (?, ?)")) {
                for (int i = 1; i <= 100; i++) {
                    pstmt.setString(1, "批量用户" + i);
                    pstmt.setInt(2, 20 + i % 40);
                    pstmt.addBatch();
                }
                int[] results = pstmt.executeBatch();
                recordTestResult("批量插入", results.length == 100, "成功插入" + results.length + "条记录");
            }
            
        } catch (Exception e) {
            recordTestResult("批量插入", false, "批量插入失败: " + e.getMessage());
        }
    }
    
    /**
     * 批量更新测试
     */
    private void testBatchUpdate() {
        try {
            try (PreparedStatement pstmt = connection.prepareStatement("UPDATE users_batch SET age = ? WHERE name = ?")) {
                for (int i = 1; i <= 50; i++) {
                    pstmt.setInt(1, 30 + i);
                    pstmt.setString(2, "批量用户" + i);
                    pstmt.addBatch();
                }
                int[] results = pstmt.executeBatch();
                recordTestResult("批量更新", results.length == 50, "成功更新" + results.length + "条记录");
            }
            
        } catch (Exception e) {
            recordTestResult("批量更新", false, "批量更新失败: " + e.getMessage());
        }
    }
    
    /**
     * 批量删除测试
     */
    private void testBatchDelete() {
        try {
            try (PreparedStatement pstmt = connection.prepareStatement("DELETE FROM users_batch WHERE age > ?")) {
                for (int age = 60; age <= 80; age += 2) {
                    pstmt.setInt(1, age);
                    pstmt.addBatch();
                }
                int[] results = pstmt.executeBatch();
                recordTestResult("批量删除", results.length == 11, "成功删除" + results.length + "条记录");
            }
            
        } catch (Exception e) {
            recordTestResult("批量删除", false, "批量删除失败: " + e.getMessage());
        }
    }

    /**
     * LOB操作测试
     */
    private void testLobOperations() {
        System.out.println("--- LOB操作测试 ---");
        
        try {
            // 创建LOB测试表
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS test_lob (id INT AUTO_INCREMENT PRIMARY KEY, text_content LONGTEXT, binary_content LONGBLOB, created_date DATETIME)");
            }
            
            // CLOB操作测试
            testClobOperations();
            
            // BLOB操作测试
            testBlobOperations();
            
            // LOB查询测试
            String[] lobTests = {
                "INSERT INTO test_lob (text_content, created_date) VALUES ('这是一个长文本内容', NOW())",
                "UPDATE test_lob SET text_content = '更新后的长文本内容' WHERE id = 1",
                "SELECT id, LENGTH(text_content), text_content FROM test_lob",
                "SELECT id, LENGTH(binary_content) FROM test_lob WHERE text_content LIKE '%内容%'"
            };
            
            for (String sql : lobTests) {
                testSQLParsing("LOB操作", sql);
            }
            
        } catch (Exception e) {
            recordTestResult("LOB操作", false, "LOB操作测试失败: " + e.getMessage());
        }
    }
    
    /**
     * CLOB操作测试
     */
    private void testClobOperations() {
        try {
            String longText = "这是一个很长的文本内容，用于测试CLOB字段的处理能力。" +
                             "包含中文字符和特殊符号：@#$%^&*()_+-={}[]|\\:;\"'<>?,./";
            
            try (PreparedStatement pstmt = connection.prepareStatement("INSERT INTO test_lob (text_content) VALUES (?)")) {
                pstmt.setString(1, longText);
                int result = pstmt.executeUpdate();
                recordTestResult("CLOB操作", result > 0, "CLOB数据写入成功，长度: " + longText.length());
            }
            
            // 读取CLOB数据
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT text_content FROM test_lob WHERE id = LAST_INSERT_ID()")) {
                if (rs.next()) {
                    String content = rs.getString(1);
                    recordTestResult("CLOB操作", content != null, "CLOB数据读取成功，长度: " + content.length());
                }
            }
            
        } catch (Exception e) {
            recordTestResult("CLOB操作", false, "CLOB操作失败: " + e.getMessage());
        }
    }
    
    /**
     * BLOB操作测试
     */
    private void testBlobOperations() {
        try {
            String binaryData = "这是二进制数据测试内容";
            byte[] binaryBytes = binaryData.getBytes("UTF-8");
            
            try (PreparedStatement pstmt = connection.prepareStatement("INSERT INTO test_lob (binary_content) VALUES (?)")) {
                pstmt.setBytes(1, binaryBytes);
                int result = pstmt.executeUpdate();
                recordTestResult("BLOB操作", result > 0, "BLOB数据写入成功，大小: " + binaryBytes.length + " bytes");
            }
            
            // 读取BLOB数据
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT binary_content FROM test_lob WHERE id = LAST_INSERT_ID()")) {
                if (rs.next()) {
                    byte[] content = rs.getBytes(1);
                    String contentStr = new String(content, "UTF-8");
                    recordTestResult("BLOB操作", content != null, "BLOB数据读取成功，内容: " + contentStr);
                }
            }
            
        } catch (Exception e) {
            recordTestResult("BLOB操作", false, "BLOB操作失败: " + e.getMessage());
        }
    }

}

