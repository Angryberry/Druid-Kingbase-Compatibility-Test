package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.WallFilter;
import java.util.ArrayList;
import java.util.List;

public class DruidSecurityFactory {

    /**
     * 创建安全增强型数据源
     * 专注 SQL 防火墙审计，移除了 SSL 加密链路相关配置
     */
    public static DruidDataSource createSecurityDataSource() throws Exception {
        DruidDataSource ds = new DruidDataSource();

        // 1. 基础连接信息 (金仓 Kingbase)
        ds.setUrl("jdbc:kingbase8://localhost:54321/test");
        ds.setDriverClassName("com.kingbase8.Driver");
        ds.setUsername("druid");
        ds.setPassword("druid123");

        // 2. 核心：硬核防火墙配置 (WallConfig)
        WallConfig config = new WallConfig();

        // --- 基础注入防御 ---
        config.setConditionAndAlwayTrueAllow(false); // 禁止 '1'='1' 恒真逻辑
        config.setMultiStatementAllow(false);       // 禁止分号多语句执行
        config.setStrictSyntaxCheck(true);          // 开启严格语法检查

        // --- 高危操作拦截 ---
        config.setDeleteWhereNoneCheck(true);       // 禁止无 WHERE 的 DELETE
        config.setUpdateWhereNoneCheck(true);       // 禁止无 WHERE 的 UPDATE

        // --- 【关键修正】函数与元数据探测拦截 ---
        config.setFunctionCheck(true);              // 开启函数调用检查
        config.setSchemaCheck(true);                // 禁止跨 Schema 访问系统表

        // 显式拒绝用于时间盲注和指纹探测的函数
        config.getDenyFunctions().add("pg_sleep");
        config.getDenyFunctions().add("sys_sleep");
        config.getDenyFunctions().add("version");
        config.getDenyFunctions().add("current_user");

        // 3. 过滤器注入 (WallFilter)
        WallFilter filter = new WallFilter();
        filter.setDbType("kingbase");             // 借用成熟的 PG 解析引擎
        filter.setConfig(config);

        List<com.alibaba.druid.filter.Filter> filterList = new ArrayList<>();
        filterList.add(filter);
        ds.setProxyFilters(filterList);

        // 4. 性能与稳定性参数
        ds.setInitialSize(5);
        ds.setMaxActive(20);
        ds.setValidationQuery("SELECT 1");          // 消除 validationQuery 未设置的警告
        ds.setTestWhileIdle(true);

        // 5. 初始化
        ds.init();

        return ds;
    }
}