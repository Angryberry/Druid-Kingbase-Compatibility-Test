package ConnectionErrorRetryAttempts_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class ConnectionErrorRetryAttempts_Test {
    // 设置重试次数为 3 次
    public static final int CONNECTION_ERROR_RETRY_ATTEMPTS = 3;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 1. 设置重试 3 次，每次间隔 1000ms
        dataSource.setConnectionErrorRetryAttempts(3);
        dataSource.setTimeBetweenConnectErrorMillis(1000);

        // 2. 【关键修复】主线程的等待时间必须 > (3 * 1000ms)
        // 建议设为 5000ms，确保能完整覆盖重试逻辑
        dataSource.setMaxWait(5000);

        // 允许初始化失败后继续运行，这样我们才能在 getConnection 阶段看到重试
        dataSource.setBreakAfterAcquireFailure(false);

        return dataSource;
    }
}