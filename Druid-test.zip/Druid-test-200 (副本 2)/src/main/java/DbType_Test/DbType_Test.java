package DbType_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class DbType_Test {
    // 设置数据库类型为 kingbase (或者你当前使用的类型)
    public static final String DB_TYPE = "kingbase";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数 ---
        dataSource.setDbType(DB_TYPE);

        // 开启统计过滤器，用于验证方言识别
        try {
            dataSource.setFilters("stat");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataSource;
    }
}