package Z_Plugins_Test;

import com.alibaba.druid.filter.config.ConfigFilter;
import com.alibaba.druid.pool.DruidDataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigFilter_Test {
    public static void main(String[] args) throws Exception {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource ds = createDataSource(properties);

        try {
            ds.init();
            System.out.println("[ConfigFilter] datasource inited with encrypted password placeholder");
        } finally {
            ds.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource ds = new DruidDataSource();
        ds.getProxyFilters().add(new ConfigFilter());
        ds.setDriverClassName(properties.getProperty("driverClassName"));
        ds.setUrl(properties.getProperty("url"));
        ds.setUsername(properties.getProperty("username"));
        ds.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            ds.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            ds.setValidationQuery("SELECT 1");
        }

        return ds;
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

}


