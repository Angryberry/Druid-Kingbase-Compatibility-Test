package Z_Plugins_Test;

import com.alibaba.druid.pool.xa.DruidXADataSource;
import javax.transaction.xa.XAResource;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class XAUtil_Test {
    public static final String DEFAULT_DB_TYPE = "kingbase";
    
    public static void main(String[] args) throws Exception {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        DruidXADataSource xaDs = new DruidXADataSource();
        xaDs.setDriverClassName(properties.getProperty("driverClassName"));
        xaDs.setUrl(properties.getProperty("url"));
        xaDs.setUsername(properties.getProperty("username"));
        xaDs.setPassword(properties.getProperty("password"));
        xaDs.setDbType("kingbase");
        if ("oracle".equalsIgnoreCase(getModel())) {
            xaDs.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            xaDs.setValidationQuery("SELECT 1");
        }


        String xaClass = properties.getProperty("xaDataSourceClassName");
        if (xaClass != null && !xaClass.isEmpty()) {
            Properties xaProps = new Properties();
            if (properties.getProperty("url") != null) {
                xaProps.setProperty("url", properties.getProperty("url"));
                xaProps.setProperty("URL", properties.getProperty("url"));
            }
            if (properties.getProperty("username") != null) {
                xaProps.setProperty("user", properties.getProperty("username"));
                xaProps.setProperty("username", properties.getProperty("username"));
            }
            if (properties.getProperty("password") != null) {
                xaProps.setProperty("password", properties.getProperty("password"));
            }
        }

        try {
            xaDs.init();
            XAResource xaResource = xaDs.getXAConnection().getXAResource();
            System.out.println("[XAUtil] XAResource acquired: " + (xaResource != null));
        } finally {
            // 确保XA数据源被关闭
            if (xaDs != null) {
                xaDs.close();
            }
        }
    }
    
    public static DruidXADataSource createXADataSource(Properties props) {
        DruidXADataSource xaDs = new DruidXADataSource();
        xaDs.setDriverClassName(props.getProperty("driverClassName"));
        xaDs.setUrl(props.getProperty("url"));
        xaDs.setUsername(props.getProperty("username"));
        xaDs.setPassword(props.getProperty("password"));
        xaDs.setDbType(DEFAULT_DB_TYPE);
        return xaDs;
    }
    private static String getModel() {
        DruidXADataSource dataSource = new DruidXADataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }
}


