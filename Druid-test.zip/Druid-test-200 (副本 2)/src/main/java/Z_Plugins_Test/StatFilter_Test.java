package Z_Plugins_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.filter.stat.StatFilter;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class StatFilter_Test {
    public static final int SLOW_SQL_MILLIS = 100;

    public static void main(String[] args) throws SQLException {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource ds = createDataSource(properties);

        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement("select 1");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                System.out.println("[StatFilter] result: " + rs.getInt(1));
            }
        } finally {
            ds.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(properties.getProperty("driverClassName"));
        ds.setUrl(properties.getProperty("url"));
        ds.setUsername(properties.getProperty("username"));
        ds.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            ds.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            ds.setValidationQuery("SELECT 1");
        }

        StatFilter statFilter = new StatFilter();
        statFilter.setSlowSqlMillis(SLOW_SQL_MILLIS);
        statFilter.setLogSlowSql(true);
        ds.getProxyFilters().add(statFilter);
        return ds;
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }
}


