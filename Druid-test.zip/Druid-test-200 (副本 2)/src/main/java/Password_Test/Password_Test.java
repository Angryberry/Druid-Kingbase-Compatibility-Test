package Password_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class Password_Test {
    public static final String TEST_PASSWORD = "test_password_123";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));

        // 设置测试密码
        dataSource.setPassword(properties.getProperty("password", TEST_PASSWORD));

        // 快速失败配置：防止密码错误时 Druid 一直在那重试
        dataSource.setInitialSize(1);
        dataSource.setBreakAfterAcquireFailure(true);
        dataSource.setConnectionErrorRetryAttempts(0);

        return dataSource;
    }
}