package Filters_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class Filters_Test {
    // 开启统计过滤器
    public static final String FILTERS_CONFIG = "stat";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心参数设置 ---
        try {
            // 设置过滤器，这将触发 Druid 内部拦截器链的构建
            dataSource.setFilters(FILTERS_CONFIG);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataSource;
    }
}