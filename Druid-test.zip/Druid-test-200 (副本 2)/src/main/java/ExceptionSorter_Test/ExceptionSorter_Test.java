package ExceptionSorter_Test;


import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.ExceptionSorter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ExceptionSorter_Test {
    public static final String FATAL_SQL_STATE = "08003";

    public static void main(String[] args) {
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建并配置 Druid 数据源
        DruidDataSource dataSource = createDataSource(properties);

        // 获取连接并执行数据库操作
        try (Connection connection = dataSource.getConnection()) {
            // 执行数据库操作
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 设置验证查询
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle")));
        dataSource.setValidationQuery(properties.getProperty("validationQuery"));

        // 配置 exceptionSorter
        dataSource.setExceptionSorter(new CustomExceptionSorter());
        return dataSource;
    }

    private static void executeDatabaseOperations(Connection connection) {
        // 插入数据
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);

        // 更新数据
        executeUpdate(connection, "UPDATE users SET age = ? WHERE name = ?", 31, "John Doe");

        // 删除数据
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "John Doe");
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 自定义 ExceptionSorter 实现
    static class CustomExceptionSorter implements ExceptionSorter {
        @Override
        public boolean isExceptionFatal(SQLException e) {
            // 在此你可以根据实际情况判断异常是否是致命的
            // 例如，如果检测到特定错误代码，认为它是致命的
            if (FATAL_SQL_STATE.equals(e.getSQLState())) {  // 举例：连接关闭时，认为是致命错误
                return true;
            }
            // 其他异常根据需求判断是否致命
            return false;
        }

        @Override
        public void configFromProperties(Properties properties) {

        }
    }
}
