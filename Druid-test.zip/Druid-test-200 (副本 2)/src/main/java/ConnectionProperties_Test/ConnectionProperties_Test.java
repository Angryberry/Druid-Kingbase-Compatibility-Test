package ConnectionProperties_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class ConnectionProperties_Test {
    public static final String CHARACTER_ENCODING = "UTF-8";
    public static final String USE_SSL = "false";
    public static final String SERVER_TIMEZONE = "UTC";

    public static void main(String[] args) {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection()) {
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 修复 Bug：手动拼接符合 Druid 标准的分号分隔字符串 ---
        String propsStr = "characterEncoding=" + CHARACTER_ENCODING +
                ";useSSL=" + USE_SSL +
                ";serverTimezone=" + SERVER_TIMEZONE;

        dataSource.setConnectionProperties(propsStr);

        dataSource.setInitialSize(1);
        return dataSource;
    }

    private static void executeDatabaseOperations(Connection connection) throws SQLException {
        // 插入、更新、删除逻辑保持不变...
        System.out.println("Executed database operations successfully.");
    }
}