package ConnectProperties_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class ConnectProperties_Test {
    // 定义我们要验证的特殊属性值
    public static final String APP_NAME = "Druid-Behavior-Test-Client";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // 基础配置补全
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心参数设置 ---
        Properties connectProps = new Properties();
        // 设置 ApplicationName。Kingbase/PostgreSQL 驱动会识别这个属性
        connectProps.setProperty("ApplicationName", APP_NAME);
        // 也可以设置超时时间等
        connectProps.setProperty("socketTimeout", "5000");

        dataSource.setConnectProperties(connectProps);

        return dataSource;
    }
}