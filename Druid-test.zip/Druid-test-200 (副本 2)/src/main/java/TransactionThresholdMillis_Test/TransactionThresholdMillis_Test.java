package TransactionThresholdMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;
import java.util.Collections;

public class TransactionThresholdMillis_Test {
    // 设置阈值为 1000ms。超过 1 秒的事务应被记录。
    public static final long TRANSACTION_THRESHOLD_MILLIS = 1000;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心监控参数 ---
        dataSource.setTransactionThresholdMillis(TRANSACTION_THRESHOLD_MILLIS);

        // 必须开启 StatFilter 才能收集统计数据
        try {
            dataSource.setFilters("stat");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataSource;
    }
}