package PasswordCallback_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class PasswordCallback_Test {

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // 1. 基础连接配置
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));

        // 2. 设置一个“假密码”：证明如果不走回调，连接一定会失败
        dataSource.setPassword("WRONG_FAKE_PASSWORD");

        // 3. 配置并注入回调类
        CustomPasswordCallback callback = new CustomPasswordCallback();
        // 将配置文件中的“真密码”传给回调类
        callback.setPasswordToReturn(properties.getProperty("password"));

        dataSource.setPasswordCallback(callback);

        // 4. 辅助配置：快速失败，不重试
        dataSource.setInitialSize(1);
        dataSource.setBreakAfterAcquireFailure(true);
        dataSource.setConnectionErrorRetryAttempts(0);

        return dataSource;
    }

    // 保持 main 方法用于手动测试
    public static void main(String[] args) throws Exception {
        // 这里可以保留你原本的业务逻辑代码
    }
}