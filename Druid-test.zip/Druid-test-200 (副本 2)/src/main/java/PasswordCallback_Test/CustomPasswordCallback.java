package PasswordCallback_Test;

import javax.security.auth.callback.PasswordCallback;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 行为感知回调类：记录 Druid 调用它的次数
 */
public class CustomPasswordCallback extends PasswordCallback {

    private final AtomicInteger invocationCount = new AtomicInteger(0);
    private char[] passwordToReturn;

    public CustomPasswordCallback() {
        super("Password", false);
    }

    // 在测试中预设“解密后”的真实密码，避免使用 Scanner 阻塞
    public void setPasswordToReturn(String password) {
        if (password != null) {
            this.passwordToReturn = password.toCharArray();
        }
    }

    @Override
    public char[] getPassword() {
        // 核心行为：记录调用次数
        invocationCount.incrementAndGet();
        System.out.println(">>> [回调触发] Druid 正在通过 CustomPasswordCallback 获取密码...");
        return passwordToReturn;
    }

    // 暴露给测试类进行断言
    public int getInvocationCount() {
        return invocationCount.get();
    }
}