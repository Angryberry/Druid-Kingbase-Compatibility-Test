package FailFast_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class FailFast_Test {
    // 开启快速失败
    public static final boolean FAIL_FAST_ENABLED = true;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置补全 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心行为参数 ---
        dataSource.setFailFast(FAIL_FAST_ENABLED);

        // 必须设置初始连接数，才会触发 init 阶段的物理连接创建
        dataSource.setInitialSize(1);
        // 为了配合快速失败，通常把重试次数设为 0
        dataSource.setConnectionErrorRetryAttempts(0);

        return dataSource;
    }
}