package ParameterTest.LogAbandoned_Test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LogAbandoned_Test {
    public static final boolean LOG_ABANDONED_ENABLED = true;

    public static void main(String[] args) {
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建并配置 Druid 数据源
        DruidDataSource dataSource = createDataSource(properties);

        // 获取连接并执行数据库操作
        try (Connection connection = dataSource.getConnection()) {
            // 执行数据库操作
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }

        // 设置 logAbandoned 参数
        dataSource.setLogAbandoned(LOG_ABANDONED_ENABLED);  // 启用记录未关闭连接的日志
        return dataSource;
    }

    private static void executeDatabaseOperations(Connection connection) {
        // 插入数据
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);

        // 更新数据
        executeUpdate(connection, "UPDATE users SET age = ? WHERE name = ?", 31, "John Doe");

        // 删除数据
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "John Doe");
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }


    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
