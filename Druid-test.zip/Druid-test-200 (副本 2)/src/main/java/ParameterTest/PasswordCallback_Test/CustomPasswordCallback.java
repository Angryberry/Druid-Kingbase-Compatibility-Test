package ParameterTest.PasswordCallback_Test;

import com.alibaba.druid.pool.DruidDataSource;

import javax.security.auth.callback.PasswordCallback;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class CustomPasswordCallback extends PasswordCallback {

    public CustomPasswordCallback() {
        super("Password", false);  // 设置密码提示信息和是否可见
    }

    @Override
    public void setPassword(char[] password) {
        super.setPassword(password);
    }

    @Override
    public char[] getPassword() {
        // 实现动态密码获取的逻辑
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();

        }


        Scanner scanner = new Scanner(System.in);
        System.out.print("Get the database password: ");
        String password = properties.getProperty("password");
        return password.toCharArray();
    }
}
