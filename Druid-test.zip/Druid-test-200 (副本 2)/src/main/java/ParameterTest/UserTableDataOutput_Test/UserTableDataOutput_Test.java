package ParameterTest.UserTableDataOutput_Test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class UserTableDataOutput_Test {

    public static void main(String[] args) {
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建并配置 Druid 数据源
        DruidDataSource dataSource = createDataSource(properties);

        // 获取连接并查询user表数据
        try (Connection connection = dataSource.getConnection()) {
            // 查询并输出user表数据
            queryAndOutputUserData(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 确保数据源被关闭
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 设置验证查询
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle")));
        dataSource.setValidationQuery(properties.getProperty("validationQuery"));

        return dataSource;
    }

    private static void queryAndOutputUserData(Connection connection) {
        String sql = "SELECT * FROM users ORDER BY id";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            System.out.println("=== User表数据 ===");
            System.out.println("ID\t姓名\t\t年龄\t创建时间");
            System.out.println("----------------------------------------");
            
            int count = 0;
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String createTime = rs.getString("create_time");
                
                System.out.printf("%d\t%s\t\t%d\t%s%n", 
                    id, 
                    name != null ? name : "NULL", 
                    age, 
                    createTime != null ? createTime : "NULL");
                count++;
            }
            
            System.out.println("----------------------------------------");
            System.out.println("总共查询到 " + count + " 条记录");
            
        } catch (SQLException e) {
            System.err.println("查询user表数据时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
