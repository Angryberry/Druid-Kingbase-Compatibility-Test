package ParameterTest.Plugins_Test;

import com.alibaba.druid.wall.WallCheckResult;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.spi.KingbaseWallProvider;

public class WallFilter_Test {
    public static final String DB_TYPE = "kingbase";
    
    public static void main(String[] args) {

        String safeSql = "select id, name from users where id = 1";
        String injectionSql = "select * from users where name = 'a' or '1'='1'";

        WallConfig config = new WallConfig();
        KingbaseWallProvider provider = createWallProvider(config);

        WallCheckResult safeResult = provider.check(safeSql);
        WallCheckResult injectionResult = provider.check(injectionSql);

        boolean safe = safeResult.getViolations().isEmpty();
        boolean unsafe = injectionResult.getViolations().isEmpty();

        System.out.println("[WallFilter] safe sql valid: " + safe + " -> " + safeSql);
        System.out.println("[WallFilter] injection sql valid: " + unsafe + " -> " + injectionSql);
    }
    
    public static KingbaseWallProvider createWallProvider(WallConfig config) {
        return new KingbaseWallProvider(config);
    }
}


