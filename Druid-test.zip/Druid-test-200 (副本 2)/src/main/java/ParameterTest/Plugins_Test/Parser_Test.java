package ParameterTest.Plugins_Test;

import com.alibaba.druid.sql.SQLUtils;
import com.alibaba.druid.sql.ast.SQLStatement;
import java.util.List;

public class Parser_Test {
    public static final String DB_TYPE = "kingbase";
    public static void main(String[] args) {
        String dbType = DB_TYPE;
        String sql = "select id, name from users where id = ? and name like ? order by id desc";

        List<SQLStatement> list = SQLUtils.parseStatements(sql, dbType);
        for (SQLStatement stmt : list) {
            String formatted = SQLUtils.toSQLString(stmt, dbType);
            System.out.println("[Parser] formatted sql: \n" + formatted);
        }
    }
}


