package ParameterTest.Plugins_Test;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.filter.logging.Log4jFilter;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Log4jFilter_Test {
    public static final boolean LOG_EXECUTABLE_SQL = true;

    public static void main(String[] args) throws SQLException {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource ds = createDataSource(properties);

        try (Connection conn = ds.getConnection(); Statement st = conn.createStatement()) {
            st.execute("select 1");
            System.out.println("[Log4jFilter] executed select 1");
        } finally {
            ds.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(properties.getProperty("driverClassName"));
        ds.setUrl(properties.getProperty("url"));
        ds.setUsername(properties.getProperty("username"));
        ds.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            ds.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            ds.setValidationQuery("SELECT 1");
        }

        Log4jFilter log4jFilter = new Log4jFilter();
        log4jFilter.setStatementExecutableSqlLogEnable(LOG_EXECUTABLE_SQL);
        ds.getProxyFilters().add(log4jFilter);
        return ds;
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

}


