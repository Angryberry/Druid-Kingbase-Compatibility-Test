package ParameterTest.SharePreparedStatements_Test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class SharePreparedStatements_Test {
    public static final boolean SHARE_PREPARED_STATEMENTS = true;

    public static void main(String[] args) {
        // 加载配置文件
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建并配置 Druid 数据源
        DruidDataSource dataSource = createDataSource(properties);

        // 获取连接并执行数据库操作
        try (Connection connection = dataSource.getConnection()) {
            // 执行数据库操作
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 确保数据源被关闭
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 设置验证查询
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle")));
        dataSource.setValidationQuery(properties.getProperty("validationQuery"));

        // 设置共享预编译语句（连接池是否共享预编译语句）
        dataSource.setSharePreparedStatements(SHARE_PREPARED_STATEMENTS);  // 设置为 true，启用共享
        return dataSource;
    }

    private static void executeDatabaseOperations(Connection connection) {
        // 插入数据
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);

        // 更新数据
        executeUpdate(connection, "UPDATE users SET age = ? WHERE name = ?", 31, "John Doe");

        // 删除数据
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "John Doe");
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
