package Url_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class Url_Test {
    // 默认测试 URL
    public static final String TEST_URL = "jdbc:kingbase8://localhost:54321/test";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // 核心参数设置
        dataSource.setDriverClassName(properties.getProperty("driverClassName", "com.kingbase8.Driver"));
        dataSource.setUrl(properties.getProperty("url", TEST_URL));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 行为验证辅助配置 ---
        // 初始只尝试建立 1 个连接
        dataSource.setInitialSize(1);
        // 如果 URL 错误，不要无限重试，直接报错
        dataSource.setBreakAfterAcquireFailure(true);
        dataSource.setConnectionErrorRetryAttempts(0);
        // 设置获取连接的最长等待时间（5秒）
        dataSource.setMaxWait(5000);

        return dataSource;
    }

    public static void main(String[] args) {
        // 这里可以保留你原来的业务逻辑执行
    }
}