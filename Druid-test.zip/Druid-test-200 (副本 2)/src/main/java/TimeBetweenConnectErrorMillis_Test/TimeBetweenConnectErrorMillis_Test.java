package TimeBetweenConnectErrorMillis_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class TimeBetweenConnectErrorMillis_Test {
    // 设置连接失败后，等待 2000ms 再进行下一次尝试
    public static final long TIME_BETWEEN_CONNECT_ERROR_MILLIS = 2000;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 基础配置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 核心修复配置 ---
        dataSource.setTimeBetweenConnectErrorMillis(TIME_BETWEEN_CONNECT_ERROR_MILLIS);

        // 1. 初始化不创建连接，避开同步阶段的异常抛出
        dataSource.setInitialSize(0);

        // 2. 关键：连接失败后不中断，允许进入重试逻辑
        dataSource.setBreakAfterAcquireFailure(false);

        // 3. 设置允许重试
        dataSource.setConnectionErrorRetryAttempts(1);

        return dataSource;
    }
}