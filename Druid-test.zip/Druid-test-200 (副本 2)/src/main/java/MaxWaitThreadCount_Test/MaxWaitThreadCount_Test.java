package MaxWaitThreadCount_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class MaxWaitThreadCount_Test {
    // 【改进 1】将上限设为 2。这样只需要 3 个并发线程（1个占位，2个排队）就能让第 4 个瞬间报错。
    public static final int MAX_WAIT_THREAD_COUNT = 2;

    public static void main(String[] args) {
        // ... 加载逻辑保持不变 ...
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // 基础配置
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 【改进 2】消除警告：设置验证查询。防止日志弹出 "testWhileIdle is true, validationQuery not set"
        dataSource.setValidationQuery("SELECT 1");
        dataSource.setTestWhileIdle(true);

        // 核心测试参数
        // 限制最大活跃连接为 1，确保后续线程必须进入等待队列
        dataSource.setMaxActive(1);
        // 设置最大等待线程数
        dataSource.setMaxWaitThreadCount(MAX_WAIT_THREAD_COUNT);
        // 设置较长的超时时间。如果参数生效，报错是瞬间的；如果不生效，你会卡在这里 10 秒。
        dataSource.setMaxWait(10000);

        return dataSource;
    }
}