package NumTestsPerEvictionRun_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.lang.reflect.Field;
import java.util.Properties;

public class NumTestsPerEvictionRun_Test {
    public static final int NUM_TESTS_PER_EVICTION_RUN = 3;

    public static DruidDataSource createDataSource(Properties properties) throws Exception {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 扫描频率：500ms
        dataSource.setTimeBetweenEvictionRunsMillis(500);

        // 保活阈值：600ms（连接空闲超过此值触发保活探测）
        setField(dataSource, "keepAliveBetweenTimeMillis", 600L);

        // 驱逐阈值：必须远大于保活阈值，否则连接被驱逐而不走保活路径
        setField(dataSource, "minEvictableIdleTimeMillis", 60_000L);

        // 步长：每次扫描最多检查 3 个连接
        dataSource.setNumTestsPerEvictionRun(NUM_TESTS_PER_EVICTION_RUN);

        dataSource.setKeepAlive(true);
        dataSource.setTestWhileIdle(true);
        dataSource.setValidationQuery("SELECT 1");
        dataSource.setInitialSize(5);

        return dataSource;
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Class<?> c = obj.getClass();
        while (c != null) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                f.set(obj, value);
                return;
            } catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            }
        }
        throw new NoSuchFieldException("Field not found: " + name);
    }
}