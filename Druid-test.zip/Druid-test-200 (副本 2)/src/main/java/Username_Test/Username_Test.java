package Username_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class Username_Test {

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        // --- 核心身份配置 ---
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 行为验证辅助配置 ---
        // 设为 1，确保 init 或 getConnection 时立即触发一次物理连接尝试
        dataSource.setInitialSize(1);
        // 关键：如果用户名错误导致连接失败，立刻报错，不要重试
        dataSource.setBreakAfterAcquireFailure(true);
        dataSource.setConnectionErrorRetryAttempts(0);
        // 设置获取连接的最大等待时长
        dataSource.setMaxWait(3000);

        return dataSource;
    }

    public static void main(String[] args) {
        // 执行业务逻辑...
    }
}