package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.*;
import java.util.*;

/**
 * 自动化连接复用验证场景测试
 * 自动运行所有场景并生成简报
 */
public class ConnectionReuseDruidTest {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8091;
    private static Properties baseProperties;

    // 用于自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;

        TestScenario(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    public static void main(String[] args) {
        // 关闭钩子
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            shutdown();
        }, "ShutdownHook"));

        try {
            showWelcome();

            // 1. 修复路径问题：使用 ClassLoader 加载配置
            loadBaseProperties();

            // 2. 启动监控
            startMonitorServer();

            // 3. 初始化场景
            initAllScenarios();

            // 4. 自动化执行：遍历并运行
            System.out.println("🚀 开始自动化回归测试...\n");
            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(Integer.parseInt(id));
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 打印最终报告
            printFinalReport();

            // 6. 留出时间给监控页面抓取数据
            System.out.println("\n⌛ 测试完成。监控页面将保持 10 秒供查阅，之后自动关闭...");
            Thread.sleep(10000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化流程中断:");
            e.printStackTrace();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        // 关键点：改用 getResourceAsStream 避开 src/main/resources 物理路径陷阱
        try (InputStream is = ConnectionReuseDruidTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) {
                throw new java.io.FileNotFoundException("Classpath 中未找到 druid.properties，请确保文件位于 resources 目录下且已编译。");
            }
            baseProperties.load(is);
            System.out.println("✅ 配置加载成功\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        scenarios.put("1", createScenario("连接状态复用一致性", "验证 AutoCommit 状态重置"));
        scenarios.put("2", createScenario("连接关闭资源清理", "验证 Statement 随连接自动关闭"));
        scenarios.put("3", createScenario("复用连接执行新事务", "验证事务独立性"));
        scenarios.put("4", createScenario("并发连接复用安全性", "验证多线程不交叉污染"));
        scenarios.put("5", createScenario("异常连接剔除与重建", "验证物理断开后的自动恢复"));
    }

    private static TestScenario createScenario(String name, String description) throws SQLException {
        TestScenario s = new TestScenario(name, description);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));

        ds.setInitialSize(1);
        ds.setMinIdle(1);
        ds.setMaxActive(10);
        ds.setTestOnBorrow(true);
        ds.setValidationQuery("SELECT 1");

        // 开启监控
        ds.setFilters("stat");
        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(int num) {
        TestScenario s = scenarios.get(String.valueOf(num));
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 正在运行场景 " + num + ": " + s.name);

        try {
            switch (num) {
                case 1: testStateReset(s.dataSource); break;
                case 2: testResourceCleanup(s.dataSource); break;
                case 3: testReuseNewTransaction(s.dataSource); break;
                case 4: testConcurrentReuse(s.dataSource); break;
                case 5: testInvalidConnectionRebuild(s.dataSource); break;
            }
            System.out.println("🟢 场景 " + num + " 测试通过");
            return true;
        } catch (Exception e) {
            System.err.println("🔴 场景 " + num + " 异常: " + e.getMessage());
            return false;
        }
    }

    // --- 测试逻辑（保持原样，仅确保不阻塞） ---

    private static void testStateReset(DruidDataSource ds) throws SQLException {
        try (DruidPooledConnection conn1 = ds.getConnection()) {
            conn1.setAutoCommit(false);
        } // 归还连接
        try (DruidPooledConnection conn2 = ds.getConnection()) {
            if (!conn2.getAutoCommit()) throw new RuntimeException("AutoCommit 未重置！");
        }
    }

    private static void testResourceCleanup(DruidDataSource ds) throws SQLException {
        DruidPooledConnection conn = ds.getConnection();
        Statement st = conn.createStatement();
        conn.close(); // 归还
        // Druid 会在 close 时自动关闭 st，此处只需确保不报错
    }

    private static void testReuseNewTransaction(DruidDataSource ds) throws SQLException {
        try (DruidPooledConnection conn = ds.getConnection()) {
            conn.setAutoCommit(false);
            conn.createStatement().execute("SELECT 1");
            conn.commit();
        }
    }

    private static void testConcurrentReuse(DruidDataSource ds) throws InterruptedException {
        int threadCount = 5;
        Thread[] threads = new Thread[threadCount];
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new Thread(() -> {
                try (DruidPooledConnection c = ds.getConnection()) {
                    Thread.sleep(100);
                    c.createStatement().execute("SELECT 1");
                } catch (Exception ignored) {}
            });
            threads[i].start();
        }
        for (Thread t : threads) t.join();
    }

    private static void testInvalidConnectionRebuild(DruidDataSource ds) throws SQLException {
        DruidPooledConnection conn = ds.getConnection();
        Connection physical = conn.getConnection();
        physical.close(); // 暴力破坏物理连接
        conn.close(); // 归还坏连接

        // 再次获取，Druid 应该因为 testOnBorrow 发现坏连接并剔除，重新创建一个
        try (DruidPooledConnection newConn = ds.getConnection()) {
            newConn.createStatement().execute("SELECT 1");
        }
    }

    // --- 工具方法 ---

    private static void printFinalReport() {
        System.out.println("📊 自动化测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  失败数:   " + (totalScenarios - passedScenarios));
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid 自动化连接复用回归测试工具");
        System.out.println("========================================\n");
    }

    private static void startMonitorServer() {
        try {
            monitorServer = new Server(monitorPort);
            ServletContextHandler ctx = new ServletContextHandler();
            ctx.setContextPath("/");
            monitorServer.setHandler(ctx);
            ServletHolder holder = new ServletHolder(new StatViewServlet());
            ctx.addServlet(holder, "/druid/*");
            monitorServer.start();
            System.out.println("🚀 监控已启动: http://localhost:8091/druid/\n");
        } catch (Exception e) {
            System.err.println("⚠️ 监控启动失败，但不影响测试继续运行。");
        }
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理资源...");
        scenarios.values().forEach(s -> {
            if (s.dataSource != null) s.dataSource.close();
        });
        try {
            if (monitorServer != null) monitorServer.stop();
        } catch (Exception ignored) {}
        System.out.println("✅ 测试退出。");
    }
}