package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream; // 使用 InputStream 解决路径问题
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * 自动化：连接池物理关闭空闲连接时JDBC资源清理验证
 */
public class JdbcResourceCleanupDruidTest {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8091;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;

        TestScenario(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    public static void main(String[] args) {
        try {
            showWelcome();

            // 1. 修复路径问题：使用 ClassLoader 加载配置
            loadBaseProperties();

            // 2. 启动监控服务器
            startMonitorServer();

            // 3. 初始化场景
            initAllScenarios();

            // 4. 自动化执行：循环运行所有场景
            System.out.println("🚀 开始自动化回归测试 (JDBC 资源清理)...\n");
            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(Integer.parseInt(id));
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 打印报告
            printFinalReport();

            // 6. 留出几秒看监控
            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("❌ 自动化执行中断: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 注意：这里删除了 System.exit(0)，确保 JUnit 调用后能正常返回
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        // 关键：改用 getResourceAsStream 解决物理路径找不到的问题
        try (InputStream is = JdbcResourceCleanupDruidTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载成功\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        // 场景1：资源未关闭 -> 等待回收 -> 验证物理关闭时的自愈清理
        scenarios.put("1", createJdbcResourceScenario("资源未关闭-物理回收", "验证连接物理关闭时自动清理 ResultSet", false, 5000, 2000, false));
        // 场景2：资源已显式关闭 -> 等待回收 -> 基准对照
        scenarios.put("2", createJdbcResourceScenario("资源已关闭-物理回收", "验证显式关闭后的回收动作", true, 5000, 2000, false));
        // 场景3：资源未关闭 -> 不回收 -> 干扰排除
        scenarios.put("3", createJdbcResourceScenario("资源未关闭-不回收", "验证不物理关闭时资源将持续泄漏", false, 60000, 2000, true));
    }

    private static TestScenario createJdbcResourceScenario(String name, String description, boolean closeResource,
                                                           int minEvictableIdleTimeMillis, int timeBetweenEvictionRunsMillis,
                                                           boolean skipEviction) throws SQLException {
        TestScenario s = new TestScenario(name, description);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));

        ds.setInitialSize(1);
        ds.setMaxActive(5);
        ds.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        ds.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        ds.setTestWhileIdle(true);
        ds.setFilters("stat");
        ds.setName(name);

        // 自定义属性：是否显式关闭资源
        ds.getConnectProperties().put("closeResource", String.valueOf(closeResource));
        ds.getConnectProperties().put("skipEviction", String.valueOf(skipEviction));

        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(int num) {
        TestScenario s = scenarios.get(String.valueOf(num));
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 正在运行场景 " + num + ": " + s.name);

        try {
            DruidDataSource ds = s.dataSource;
            DruidPooledConnection conn = ds.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT 1");

            boolean shouldClose = Boolean.parseBoolean((String) ds.getConnectProperties().get("closeResource"));
            if (shouldClose) {
                rs.close();
                stmt.close();
                System.out.println("  [动作] 显式关闭了 JDBC 资源");
            } else {
                System.out.println("  [动作] 故意不关闭 JDBC 资源");
            }
            conn.close(); // 归还到池中

            boolean skip = Boolean.parseBoolean((String) ds.getConnectProperties().get("skipEviction"));
            if (!skip) {
                long waitTime = ds.getMinEvictableIdleTimeMillis() + 3000;
                System.out.println("  [等待] 等待连接空闲回收 (" + waitTime + "ms)...");
                Thread.sleep(waitTime);
            } else {
                System.out.println("  [跳过] 本场景不触发空闲回收");
            }

            System.out.println("🟢 场景 " + num + " 执行完毕");
            return true;
        } catch (Exception e) {
            System.err.println("🔴 场景 " + num + " 异常: " + e.getMessage());
            return false;
        }
    }

    private static void printFinalReport() {
        System.out.println("📊 JDBC 资源清理测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void startMonitorServer() {
        try {
            monitorServer = new Server(monitorPort);
            ServletContextHandler context = new ServletContextHandler();
            context.setContextPath("/");
            monitorServer.setHandler(context);
            context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
            monitorServer.start();
            System.out.println("🚀 监控已启动: http://localhost:8091/druid/\n");
        } catch (Exception e) {
            System.err.println("⚠️ 监控启动失败: " + e.getMessage());
        }
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理测试资源...");
        scenarios.values().forEach(s -> {
            if (s.dataSource != null) s.dataSource.close();
        });
        try {
            if (monitorServer != null) monitorServer.stop();
        } catch (Exception ignored) {}
        System.out.println("✅ 测试资源已释放。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid JDBC 资源清理自动化回归工具");
        System.out.println("========================================\n");
    }
}