package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * 自动化：Druid SQL解析、防注入(Wall)与合并统计(Merge)回归测试
 */
public class SQLParserDruidTest {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8091;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;
        String testSQL;
        boolean expectFail;      // 是否预期报错（如注入拦截）
        String errorKeyword;    // 预期报错中应包含的关键词

        TestScenario(String name, String description, String sql, boolean fail, String keyword) {
            this.name = name;
            this.description = description;
            this.testSQL = sql;
            this.expectFail = fail;
            this.errorKeyword = keyword;
        }
    }

    public static void main(String[] args) {
        try {
            showWelcome();
            loadBaseProperties();
            startMonitorServer();
            initAllScenarios();

            System.out.println("🚀 开始自动化 SQL 解析专项回归测试...\n");

            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(id);
                totalScenarios++;
                if (success) passedScenarios++;
            }

            printFinalReport();

            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化流程中断: " + e.getMessage());
        } finally {
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件...");
        baseProperties = new Properties();
        try (InputStream is = SQLParserDruidTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载成功\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        // 场景1：基础解析
        scenarios.put("1", createScenario("基础解析", "验证正常SELECT解析", "SELECT id, name FROM USERS LIMIT 1", false, null, false, false));
        // 场景2：WallFilter正常
        scenarios.put("2", createScenario("Wall防火墙-放行", "验证合法查询通过", "SELECT * FROM USERS WHERE id = 1", false, null, true, false));
        // 场景3：WallFilter拦截注入 (预期报错)
        scenarios.put("3", createScenario("Wall防火墙-拦截", "验证SQL注入被拦截", "SELECT * FROM USERS WHERE name='a' OR '1'='1'", true, "sql injection", true, false));
        // 场景4：MergeSql统计
        scenarios.put("4", createScenario("SQL合并统计", "验证聚合SQL解析", "SELECT name, COUNT(*) FROM USERS GROUP BY name", false, null, false, true));
        // 场景5：语法错误 (预期报错)
        scenarios.put("5", createScenario("语法错误校验", "验证解析器识别错误SQL", "SELECT name FROM USERS GROUP name", true, "syntax error", false, true));
        // 场景6：Kingbase特有函数
        scenarios.put("6", createScenario("国产库语法适配", "验证pg_sleep等函数解析", "SELECT pg_sleep(0.1)", false, null, false, false));
    }

    private static TestScenario createScenario(String name, String desc, String sql, boolean fail, String kw, boolean wall, boolean merge) throws SQLException {
        TestScenario s = new TestScenario(name, desc, sql, fail, kw);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));
        ds.setInitialSize(1);
        ds.setMaxActive(2);

        // 过滤器配置
        StringBuilder filters = new StringBuilder("stat");
        if (wall) filters.append(",wall");
        ds.setFilters(filters.toString());

        StatFilter stat = new StatFilter();
        stat.setMergeSql(merge);
        ds.getProxyFilters().add(stat);

        ds.setName(name);
        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(String id) {
        TestScenario s = scenarios.get(id);
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 运行场景 " + id + ": " + s.name);

        try (DruidPooledConnection conn = s.dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute(s.testSQL);

            if (s.expectFail) {
                System.err.println("  🔴 错误：该SQL预期应被拦截，但实际执行成功了！");
                return false;
            }
            System.out.println("  [验证] SQL 执行成功，解析正常。");
            return true;

        } catch (SQLException e) {
            if (s.expectFail && (s.errorKeyword == null || e.getMessage().toLowerCase().contains(s.errorKeyword))) {
                System.out.println("  [验证] ✅ 成功捕捉到预期错误: " + e.getMessage());
                return true;
            } else {
                System.err.println("  🔴 非预期异常: " + e.getMessage());
                return false;
            }
        } finally {
            s.dataSource.close(); // 立即关闭以停止后台统计线程
        }
    }

    private static void printFinalReport() {
        System.out.println("📊 SQL 解析专项测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void startMonitorServer() throws Exception {
        monitorServer = new Server(monitorPort);
        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        monitorServer.setHandler(context);
        context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
        monitorServer.start();
        System.out.println("🚀 监控已启动: http://localhost:8091/druid/\n");
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理资源...");
        scenarios.values().forEach(s -> { if (s.dataSource != null) s.dataSource.close(); });
        try { if (monitorServer != null) monitorServer.stop(); } catch (Exception ignored) {}
        System.out.println("✅ 测试环境已重置。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid SQL 解析与安全自动化测试工具");
        System.out.println("========================================\n");
    }
}