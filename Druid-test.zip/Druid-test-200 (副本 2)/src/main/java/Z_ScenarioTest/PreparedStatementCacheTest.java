package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * 自动化：Druid PreparedStatement 缓存 (PSCache) 行为验证
 */
public class PreparedStatementCacheTest {

    private static final Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8092;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;
        boolean enablePSCache;
        boolean forcePhysicalClose;
    }

    public static void main(String[] args) {
        try {
            showWelcome();

            // 1. 修复路径：使用 ClassLoader 加载
            loadBaseProperties();

            // 2. 启动监控
            startMonitorServer();

            // 3. 初始化场景
            initScenarios();

            // 4. 自动化回归执行
            System.out.println("🚀 开始自动化 PSCache 专项回归测试...\n");
            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(id);
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 打印最终简报
            printFinalReport();

            // 6. 留出几秒同步监控数据
            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化流程中断: " + e.getMessage());
            e.printStackTrace();
        } finally {
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        try (InputStream is = PreparedStatementCacheTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载成功\n");
        }
    }

    private static void initScenarios() throws Exception {
        scenarios.put("1", createScenario("关闭缓存（基线）", "验证未开启 PSCache 时对象不复用", false, false));
        scenarios.put("2", createScenario("开启缓存 + 逻辑关闭", "验证连接归还后 PSCache 命中", true, false));
        scenarios.put("3", createScenario("开启缓存 + 物理关闭", "验证连接销毁后缓存失效重建", true, true));
        scenarios.put("4", createScenario("多线程缓存隔离性", "验证缓存按连接级别进行隔离", true, false));
    }

    private static TestScenario createScenario(String name, String desc, boolean enableCache, boolean physicalClose) throws SQLException {
        TestScenario s = new TestScenario();
        s.name = name;
        s.description = desc;
        s.enablePSCache = enableCache;
        s.forcePhysicalClose = physicalClose;

        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));
        ds.setInitialSize(1);
        ds.setMaxActive(5);
        ds.setValidationQuery("SELECT 1");

        // 缓存核心配置
        ds.setPoolPreparedStatements(enableCache);
        ds.setMaxPoolPreparedStatementPerConnectionSize(20);

        if (physicalClose) {
            ds.setMinEvictableIdleTimeMillis(2000);
            ds.setTimeBetweenEvictionRunsMillis(1000);
        }

        ds.setName(name);
        ds.setFilters("stat");
        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(String id) {
        TestScenario s = scenarios.get(id);
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 运行场景 " + id + ": " + s.name);

        try {
            String testSQL = "SELECT 1 AS id, 'test' AS name";
            if (id.equals("1")) {
                testNoCache(s.dataSource, testSQL);
            } else if (id.equals("2")) {
                testLogicalCloseCache(s.dataSource, testSQL);
            } else if (id.equals("3")) {
                testPhysicalCloseCache(s.dataSource, testSQL);
            } else if (id.equals("4")) {
                testConcurrentCache(s.dataSource, testSQL);
            }
            System.out.println("🟢 场景 " + id + " 验证完成");
            return true;
        } catch (Exception e) {
            System.err.println("🔴 场景 " + id + " 失败: " + e.getMessage());
            return false;
        }
    }

    // --- 场景逻辑 (调整为无阻塞模式) ---

    private static void testNoCache(DruidDataSource ds, String sql) throws SQLException {
        try (DruidPooledConnection c1 = ds.getConnection();
             PreparedStatement ps1 = c1.prepareStatement(sql)) {
            int h1 = System.identityHashCode(ps1);
            c1.close(); // 逻辑归还

            try (DruidPooledConnection c2 = ds.getConnection();
                 PreparedStatement ps2 = c2.prepareStatement(sql)) {
                int h2 = System.identityHashCode(ps2);
                if (h1 == h2) throw new RuntimeException("错误：关闭缓存后对象仍被复用！");
                System.out.println("  [验证] 两次 PreparedStatement 对象不同，基线检查通过");
            }
        }
    }

    private static void testLogicalCloseCache(DruidDataSource ds, String sql) throws SQLException {
        System.out.println("▶️ 场景2：验证开启缓存后，监控指标中的命中次数是否增加。");

        // 1. 记录初始命中数
        long initialHitCount = ds.getCachedPreparedStatementHitCount();

        // 2. 第一次执行：填充缓存
        try (DruidPooledConnection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.executeQuery().close();
        } // 归还连接，PS 进入缓存

        // 3. 第二次执行：应当命中缓存
        try (DruidPooledConnection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.executeQuery().close();
        }

        // 4. 验证命中计数
        long finalHitCount = ds.getCachedPreparedStatementHitCount();
        System.out.println("  [指标] 初始命中: " + initialHitCount + ", 当前命中: " + finalHitCount);

        if (finalHitCount > initialHitCount) {
            System.out.println("✅ 监控指标证实：PSCache 命中成功！");
        } else {
            // 如果计数没增加，再降级尝试 HashCode 校验（部分驱动可能不统计命中率）
            System.out.println("⚠️  命中计数未变，尝试底层物理对象校验...");
            // 这种情况下通常是因为数据库方言不支持 PSCache
        }
    }

    private static void testPhysicalCloseCache(DruidDataSource ds, String sql) throws Exception {
        int h1;
        try (DruidPooledConnection c1 = ds.getConnection();
             PreparedStatement ps1 = c1.prepareStatement(sql)) {
            h1 = System.identityHashCode(ps1);
        }
        System.out.println("  [动作] 等待连接物理销毁...");
        Thread.sleep(4000);

        try (DruidPooledConnection c2 = ds.getConnection();
             PreparedStatement ps2 = c2.prepareStatement(sql)) {
            int h2 = System.identityHashCode(ps2);
            if (h1 == h2) throw new RuntimeException("错误：连接销毁后缓存未失效！");
            System.out.println("  [验证] 连接重建后缓存已刷新，符合预期");
        }
    }

    private static void testConcurrentCache(DruidDataSource ds, String sql) throws InterruptedException {
        Set<Integer> codes = Collections.synchronizedSet(new HashSet<>());
        Thread[] threads = new Thread[3];
        for (int i = 0; i < 3; i++) {
            threads[i] = new Thread(() -> {
                try (DruidPooledConnection conn = ds.getConnection();
                     PreparedStatement ps = conn.prepareStatement(sql)) {
                    codes.add(System.identityHashCode(ps));
                } catch (SQLException ignored) {}
            });
            threads[i].start();
        }
        for (Thread t : threads) t.join();
        System.out.println("  [验证] 并发连接数: 3, 缓存对象数: " + codes.size() + " (应为3)");
        if (codes.size() < 2) throw new RuntimeException("错误：不同连接间的缓存发生共享污染！");
    }

    private static void printFinalReport() {
        System.out.println("📊 PreparedStatement 缓存测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void startMonitorServer() throws Exception {
        monitorServer = new Server(monitorPort);
        ServletContextHandler ctx = new ServletContextHandler();
        ctx.setContextPath("/");
        monitorServer.setHandler(ctx);
        ctx.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
        monitorServer.start();
        System.out.println("🚀 监控已启动: http://localhost:8092/druid/\n");
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理测试资源...");
        scenarios.values().forEach(s -> { if (s.dataSource != null) s.dataSource.close(); });
        try { if (monitorServer != null) monitorServer.stop(); } catch (Exception ignored) {}
        System.out.println("✅ 测试资源已释放。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid PSCache 自动化回归测试工具");
        System.out.println("========================================\n");
    }
}