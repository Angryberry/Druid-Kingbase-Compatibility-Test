package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * 自动化：Druid removeAbandoned 遗弃连接回收机制验证
 */
public class RemoveAbandonedDruidTest {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8090;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;

        TestScenario(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    public static void main(String[] args) {
        try {
            showWelcome();

            // 1. 修复路径：使用 ClassLoader 加载配置
            loadBaseProperties();

            // 2. 启动监控服务器
            startMonitorServer();

            // 3. 初始化场景
            initAllScenarios();

            // 4. 自动化回归执行
            System.out.println("🚀 开始自动化 removeAbandoned 专项回归测试...\n");
            System.out.println("⚠️  提示：回收验证依赖时间窗口，测试大约需要 1 分钟，请耐心等待。\n");

            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(Integer.parseInt(id));
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 打印最终简报
            printFinalReport();

            // 6. 留出几秒同步监控数据
            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化流程中断: " + e.getMessage());
            e.printStackTrace();
        } finally {
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        try (InputStream is = RemoveAbandonedDruidTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载完成\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        scenarios.put("1", createRemoveAbandonedScenario("回收启用-超时未还", "验证借出连接超时后被强制回收", true, 5000, true, false, false));
        scenarios.put("2", createRemoveAbandonedScenario("回收禁用-超时未还", "验证禁用时，超时连接不被回收", false, 5000, true, false, false));
        scenarios.put("3", createRemoveAbandonedScenario("池内空闲-不触发回收", "验证池内连接不被误回收", true, 5000, true, false, true));
        scenarios.put("4", createRemoveAbandonedScenario("执行长SQL-不回收", "验证执行中的SQL不被回收", true, 5000, true, true, false));
        scenarios.put("5", createRemoveAbandonedScenario("超时阈值调整", "验证 2秒 短阈值回收", true, 2000, true, false, false));
        scenarios.put("6", createRemoveAbandonedScenario("日志禁用验证", "验证 logAbandoned=false 时的行为", true, 5000, false, false, false));
    }

    private static TestScenario createRemoveAbandonedScenario(
            String name, String description, boolean removeAbandoned, int timeout,
            boolean logAbandoned, boolean executeLongSql, boolean poolIdle) throws SQLException {

        TestScenario scenario = new TestScenario(name, description);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));

        ds.setInitialSize(1);
        ds.setMaxActive(5);

        // 核心配置
        ds.setRemoveAbandoned(removeAbandoned);
        ds.setRemoveAbandonedTimeoutMillis(timeout);
        ds.setLogAbandoned(logAbandoned);

        // 加快检测频率以缩短自动化测试时间
        ds.setTimeBetweenEvictionRunsMillis(1000);

        ds.setName(name);
        ds.setFilters("stat");
        scenario.dataSource = ds;
        return scenario;
    }

    private static boolean executeScenario(int sceneNum) {
        TestScenario scenario = scenarios.get(String.valueOf(sceneNum));
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 正在运行场景 " + sceneNum + ": " + scenario.name);

        try {
            DruidDataSource ds = scenario.dataSource;
            if (sceneNum == 3) { // 池内空闲场景
                try (DruidPooledConnection conn = ds.getConnection()) {}
                System.out.println("  [动作] 连接已归还至池内空闲");
            } else if (sceneNum == 4) { // 执行长SQL场景
                DruidPooledConnection conn = ds.getConnection();
                System.out.println("  [动作] 正在执行耗时 SQL...");
                // 模拟业务执行，不关闭连接
            } else {
                DruidPooledConnection conn = ds.getConnection();
                System.out.println("  [动作] 连接已借出，故意不关闭（模拟泄漏）");
            }

            // 等待回收触发
            long waitTime = ds.getRemoveAbandonedTimeoutMillis() + 3000;
            System.out.println("  [等待] 等待检测周期 (" + waitTime + "ms)...");

            for (int i = (int)(waitTime/1000); i > 0; i--) {
                System.out.print("\r    倒计时: " + i + " 秒  ");
                Thread.sleep(1000);
            }
            System.out.println("\n  [检查] 当前活跃连接数: " + ds.getActiveCount());

            // 简单的逻辑校验
            if (sceneNum == 1 && ds.getActiveCount() != 0) throw new RuntimeException("连接未被回收！");
            if (sceneNum == 2 && ds.getActiveCount() == 0) throw new RuntimeException("回收禁用却发生了回收！");

            System.out.println("🟢 场景 " + sceneNum + " 执行完成");
            return true;
        } catch (Exception e) {
            System.err.println("🔴 场景 " + sceneNum + " 异常: " + e.getMessage());
            return false;
        }
    }

    private static void printFinalReport() {
        System.out.println("📊 removeAbandoned 回收机制测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void startMonitorServer() throws Exception {
        monitorServer = new Server(monitorPort);
        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        monitorServer.setHandler(context);
        context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
        monitorServer.start();
        System.out.println("🚀 监控已启动: http://localhost:8090/druid/\n");
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理测试资源...");
        scenarios.values().forEach(s -> { if (s.dataSource != null) s.dataSource.close(); });
        try { if (monitorServer != null) monitorServer.stop(); } catch (Exception ignored) {}
        System.out.println("✅ 测试资源已释放。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid removeAbandoned 自动化回归工具");
        System.out.println("========================================\n");
    }
}