package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * 自动化：Keepalive 保活查询验证回归测试
 */
public class KeepaliveValidation {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8088;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;

        TestScenario(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    public static void main(String[] args) {
        try {
            showWelcome();

            // 1. 修复路径：使用 ClassLoader 加载配置
            loadBaseProperties();

            // 2. 启动监控服务器
            startMonitorServer();

            // 3. 初始化场景
            initAllScenarios();

            // 4. 自动化执行
            System.out.println("🚀 开始自动化 Keepalive 专项回归测试...\n");
            System.out.println("⚠️  注意：部分保活场景需要等待时间窗口，请耐心等待。\n");

            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(Integer.parseInt(id));
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 最终简报
            printFinalReport();

            // 6. 留出几秒同步监控数据
            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化中断: " + e.getMessage());
        } finally {
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        try (InputStream is = KeepaliveValidation.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载完成\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        scenarios.put("1", createScenario("testOnBorrow", "借出时验证", true, false, false, false, 60000));
        scenarios.put("2", createScenario("testOnReturn", "归还时验证", false, true, false, false, 60000));
        scenarios.put("3", createScenario("testWhileIdle", "空闲检测验证", false, false, true, false, 60000));
        scenarios.put("4", createScenario("keepAlive专项", "主动保活验证", false, false, false, true, 5000)); // 缩短间隔方便自动化测试
    }

    private static TestScenario createScenario(String name, String description, boolean testOnBorrow, boolean testOnReturn,
                                               boolean testWhileIdle, boolean keepAlive, long keepAliveBetweenTimeMillis) throws SQLException {
        TestScenario s = new TestScenario(name, description);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));

        ds.setInitialSize(1);
        ds.setMaxActive(5);
        ds.setValidationQuery("SELECT 1");
        ds.setTestOnBorrow(testOnBorrow);
        ds.setTestOnReturn(testOnReturn);
        ds.setTestWhileIdle(testWhileIdle);
        ds.setKeepAlive(keepAlive);
        ds.setKeepAliveBetweenTimeMillis(keepAliveBetweenTimeMillis);

        // 缩短检测间隔，加速自动化测试
        ds.setTimeBetweenEvictionRunsMillis(2000);

        ds.setFilters("stat");
        ds.setName(name);
        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(int num) {
        TestScenario s = scenarios.get(String.valueOf(num));
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 正在运行场景 " + num + ": " + s.name);

        try {
            DruidDataSource ds = s.dataSource;
            if (num == 1) { // Borrow
                try (DruidPooledConnection conn = ds.getConnection()) {
                    System.out.println("  [动作] 借出并归还连接，触发 testOnBorrow");
                }
            } else if (num == 2) { // Return
                try (DruidPooledConnection conn = ds.getConnection()) {
                    System.out.println("  [动作] 借出并手动 close，触发 testOnReturn");
                }
            } else if (num == 3) { // WhileIdle
                try (DruidPooledConnection conn = ds.getConnection()) {} // 预热
                System.out.println("  [等待] 等待空闲检测触发 (6秒)...");
                Thread.sleep(6000);
            } else if (num == 4) { // KeepAlive
                try (DruidPooledConnection conn = ds.getConnection()) {} // 预热
                System.out.println("  [等待] 等待 KeepAlive 保活触发 (8秒)...");
                Thread.sleep(8000);
            }

            System.out.println("🟢 场景 " + num + " 执行完毕");
            return true;
        } catch (Exception e) {
            System.err.println("🔴 场景 " + num + " 异常: " + e.getMessage());
            return false;
        }
    }

    private static void printFinalReport() {

        System.out.println("📊 Keepalive 专项测试简报");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");

    }

    private static void startMonitorServer() {
        try {
            monitorServer = new Server(monitorPort);
            ServletContextHandler context = new ServletContextHandler();
            context.setContextPath("/");
            monitorServer.setHandler(context);
            context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
            monitorServer.start();
            System.out.println("🚀 监控已启动: http://localhost:8088/druid/\n");
        } catch (Exception e) {
            System.err.println("⚠️ 监控启动失败: " + e.getMessage());
        }
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理 Keepalive 测试资源...");
        scenarios.values().forEach(s -> {
            if (s.dataSource != null) s.dataSource.close();
        });
        try {
            if (monitorServer != null) monitorServer.stop();
        } catch (Exception ignored) {}
        System.out.println("✅ 测试资源已释放。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid Keepalive 自动化保活测试工具");
        System.out.println("========================================\n");
    }
}