package Z_ScenarioTest;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.*;

/**
 * 自动化：Druid Socket-Timeout 与 Keepalive 联动验证回归测试
 */
public class SocketTimeoutDruidTest {

    private static Map<String, TestScenario> scenarios = new LinkedHashMap<>();
    private static Server monitorServer;
    private static int monitorPort = 8088;
    private static Properties baseProperties;

    // 自动化统计
    private static int totalScenarios = 0;
    private static int passedScenarios = 0;

    static class TestScenario {
        String name;
        String description;
        DruidDataSource dataSource;

        TestScenario(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    public static void main(String[] args) {
        try {
            showWelcome();

            // 1. 修复路径：使用 ClassLoader 加载配置
            loadBaseProperties();

            // 2. 启动监控服务器
            startMonitorServer();

            // 3. 初始化场景 (聚焦 4 个核心 SocketTimeout 场景)
            initAllScenarios();

            // 4. 自动化回归执行
            System.out.println("🚀 开始自动化 Socket-Timeout 专项回归测试...\n");
            System.out.println("⚠️  提示：测试涉及网络超时模拟，预计耗时 30-40 秒。\n");

            for (String id : scenarios.keySet()) {
                boolean success = executeScenario(Integer.parseInt(id));
                totalScenarios++;
                if (success) passedScenarios++;
            }

            // 5. 打印最终简报
            printFinalReport();

            // 6. 留出时间给监控页面抓取最后的数据
            System.out.println("\n⌛ 测试完成。监控页面保持 5 秒后自动关闭...");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("\n❌ 自动化流程中断: " + e.getMessage());
        } finally {
            shutdown();
        }
    }

    private static void loadBaseProperties() throws Exception {
        System.out.println("📁 正在加载配置文件 (druid.properties)...");
        baseProperties = new Properties();
        try (InputStream is = SocketTimeoutDruidTest.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is == null) throw new java.io.FileNotFoundException("Classpath 未找到 druid.properties");
            baseProperties.load(is);
            System.out.println("✅ 配置加载完成\n");
        }
    }

    private static void initAllScenarios() throws Exception {
        // 场景1：保活正常 (SocketTimeout 不触发)
        scenarios.put("1", createScenario("保活正常", "验证快速响应下不触发超时", "SELECT 1", 5000));
        // 场景2：核心验证 - 保活超时 (SocketTimeout 5s, 延迟 6s)
        scenarios.put("2", createScenario("保活超时触发", "验证 5s 超时后剔除连接", "SELECT pg_sleep(6)", 5000));
        // 场景3：排除干扰 - 关闭超时 (设置 1小时)
        scenarios.put("3", createScenario("超时配置关闭", "验证关闭超时后连接被保留", "SELECT pg_sleep(6)", 3600000));
        // 场景4：区分失败 - SQL 语法错误 (非超时)
        scenarios.put("4", createScenario("保活 SQL 直接报错", "验证非超时异常的逻辑", "SELECT 1/0", 5000));
    }

    private static TestScenario createScenario(String name, String desc, String validationQuery, int socketTimeout) throws SQLException {
        TestScenario s = new TestScenario(name, desc);
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(baseProperties.getProperty("driverClassName"));
        ds.setUrl(baseProperties.getProperty("url"));
        ds.setUsername(baseProperties.getProperty("username"));
        ds.setPassword(baseProperties.getProperty("password"));

        ds.setInitialSize(1);
        ds.setMinIdle(1);
        ds.setMaxActive(5);

        // 核心：保活与超时配置
        ds.setKeepAlive(true);
        ds.setValidationQuery(validationQuery);
        ds.setSocketTimeout(socketTimeout);

        // 极速检测：缩短间隔以适配自动化测试
        ds.setKeepAliveBetweenTimeMillis(2000); // 2秒触发一次保活
        ds.setTimeBetweenEvictionRunsMillis(1000); // 1秒检测一次

        ds.setName(name);
        ds.setFilters("stat");
        s.dataSource = ds;
        return s;
    }

    private static boolean executeScenario(int num) {
        TestScenario s = scenarios.get(String.valueOf(num));
        System.out.println("------------------------------------------------------------");
        System.out.println("▶️ 正在运行场景 " + num + ": " + s.name);

        try {
            DruidDataSource ds = s.dataSource;

            // 逻辑判定：使用一个变量记录结果，方便在 finally 里统一关闭
            boolean result = false;

            try (DruidPooledConnection conn = ds.getConnection()) {
                if (num == 2 || num == 4) {
                    System.err.println("  [警告] 预期应抛出异常但未发生！");
                    result = false;
                } else {
                    System.out.println("  [动作] 连接正常建立并归还。");
                    result = true;
                }
            } catch (SQLException e) {
                String errorMsg = e.getMessage();
                Throwable cause = e.getCause();

                if (num == 2) {
                    boolean isTimeout = errorMsg.contains("I/O error") ||
                            errorMsg.contains("timed out") ||
                            (cause != null && cause.getMessage().contains("timed out"));

                    if (isTimeout) {
                        System.out.println("  [判定] ✅ 成功捕捉到预期的 SocketTimeout！");
                        result = true;
                    }
                } else if (num == 4 && errorMsg.contains("division by zero")) {
                    System.out.println("  [判定] ✅ 成功捕捉到预期的 SQL 执行错误！");
                    result = true;
                } else {
                    throw e;
                }
            }

            if (num == 3) {
                System.out.println("  [检查] 销毁连接数: " + ds.getDestroyCount());
                result = ds.getDestroyCount() == 0;
            }

            if (result) {
                System.out.println("🟢 场景 " + num + " 验证通过");
            }
            return result;

        } catch (Exception e) {
            System.err.println("🔴 场景 " + num + " 非预期异常: " + e.getMessage());
            return false;
        } finally {
            // --- 核心修复：执行完立即物理关闭当前场景的数据源 ---
            // 这会销毁该数据源关联的所有后台线程（CreateThread / DestroyThread）
            if (s != null && s.dataSource != null) {
                s.dataSource.close();
                System.out.println("  [清理] 已物理关闭场景 " + num + " 的数据源，停止后台线程。");
            }
        }
    }

    private static void printFinalReport() {
        System.out.println("📊 Socket-Timeout 专项回归报告");
        System.out.println("  总场景数: " + totalScenarios);
        System.out.println("  通过数:   " + passedScenarios);
        System.out.println("  成功率:   " + (passedScenarios * 100 / totalScenarios) + "%");
    }

    private static void startMonitorServer() throws Exception {
        monitorServer = new Server(monitorPort);
        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        monitorServer.setHandler(context);
        context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");
        monitorServer.start();
        System.out.println("🚀 监控已启动: http://localhost:8088/druid/\n");
    }

    private static void shutdown() {
        System.out.println("\n🛑 正在清理资源...");
        scenarios.values().forEach(s -> { if (s.dataSource != null) s.dataSource.close(); });
        try { if (monitorServer != null) monitorServer.stop(); } catch (Exception ignored) {}
        System.out.println("✅ 测试环境已重置。");
    }

    private static void showWelcome() {
        System.out.println("========================================");
        System.out.println("   Druid Socket-Timeout 自动化测试工具");
        System.out.println("========================================\n");
    }
}