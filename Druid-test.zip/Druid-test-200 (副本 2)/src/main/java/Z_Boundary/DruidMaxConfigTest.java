package Z_Boundary;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.io.IOException;
import java.util.Properties;
import java.io.InputStream;

/**
 * Druid连接池参数边界值测试 - 最大值
 * 测试Druid连接池各种配置参数的最大值边界
 */
public class DruidMaxConfigTest {

    /**
     * 从配置文件读取数据库连接信息
     */
    private Properties loadDatabaseConfig() {
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (is != null) {
                props.load(is);
                System.out.println("成功读取druid.properties配置文件");
            } else {
                System.err.println("未找到druid.properties配置文件，使用默认配置");
                // 使用默认Kingbase配置
                props.setProperty("url", "jdbc:kingbase8://localhost:54321/test");
                props.setProperty("username", "druid");
                props.setProperty("password", "druid123");
                props.setProperty("driverClassName", "com.kingbase8.Driver");
            }
        } catch (IOException e) {
            System.err.println("读取配置文件失败，使用默认配置: " + e.getMessage());
            // 使用默认Kingbase配置
            props.setProperty("url", "jdbc:kingbase8://localhost:54321/test");
            props.setProperty("username", "druid");
            props.setProperty("password", "druid123");
            props.setProperty("driverClassName", "com.kingbase8.Driver");
        }
        return props;
    }

    /**
     * 配置数据源基本参数
     */
    private void configureDataSource(DruidDataSource dataSource) {
        Properties props = loadDatabaseConfig();
        String url = props.getProperty("url");
        String username = props.getProperty("username");
        String password = props.getProperty("password");
        String driverClassName = props.getProperty("driverClassName");
        
        System.out.println("读取到的配置信息:");
        System.out.println("  URL: " + url);
        System.out.println("  Username: " + username);
        System.out.println("  Driver: " + driverClassName);
        
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setDriverClassName(driverClassName);
    }

    public static void main(String[] args) {
        DruidMaxConfigTest test = new DruidMaxConfigTest();
        try {
            test.runAllMaxConfigTests();
            System.out.println("=== 所有最大配置参数测试完成 ===");
        } catch (Exception e) {
            System.err.println("测试执行失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 运行所有最大配置参数测试
     */
    public void runAllMaxConfigTests() {
        System.out.println("=== 开始Druid最大配置参数测试 ===");
        
        testMaxPoolSize();
        testMaxWaitTime();
        testMaxValidationQuery();
        testMaxConnectionLifecycle();
        testMaxNetworkConfig();
        testMaxMonitoringConfig();
        testMaxPerformanceConfig();
        testMaxSecurityConfig();
        testMaxConcurrentConfig();
        
        System.out.println("=== Druid最大配置参数测试结束 ===");
    }

    /**
     * 测试最大连接池大小
     */
    private void testMaxPoolSize() {
        System.out.println("--- 测试最大连接池大小 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 测试最大连接池大小 (设置一个很大的值)
            dataSource.setInitialSize(100);      // 初始连接数
            dataSource.setMaxActive(1000);        // 最大连接数
            dataSource.setMinIdle(100);           // 最小空闲连接数
            dataSource.setMaxIdle(500);           // 最大空闲连接数
            
            // 尝试获取连接
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功，不执行SQL
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大连接池大小测试成功，maxActive: " + dataSource.getMaxActive());
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大连接池大小测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大等待时间
     */
    private void testMaxWaitTime() {
        System.out.println("--- 测试最大等待时间 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置最大等待时间参数
            dataSource.setMaxWait(300000);        // 5分钟最大等待时间
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大等待时间测试成功，maxWait: " + dataSource.getMaxWait());
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大等待时间测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大验证查询参数
     */
    private void testMaxValidationQuery() {
        System.out.println("--- 测试最大验证查询参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置验证查询参数
            dataSource.setTestWhileIdle(true);        // 空闲时验证
            dataSource.setTestOnBorrow(true);         // 借用时验证
            dataSource.setTestOnReturn(false);        // 归还时不验证(提高性能)
            dataSource.setValidationQueryTimeout(30);   // 验证查询超时30秒
            dataSource.setValidationQuery("SELECT 1"); // 验证查询SQL
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大验证查询参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大验证查询参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大连接生命周期参数
     */
    private void testMaxConnectionLifecycle() {
        System.out.println("--- 测试最大连接生命周期参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置连接生命周期参数 (最大值)
            dataSource.setMaxWait(30000);                           // 30秒最大等待
            dataSource.setTimeBetweenConnectErrorMillis(300000);       // 5分钟连接错误重试间隔
            dataSource.setConnectTimeout(60000);                     // 60秒连接超时
            dataSource.setSocketTimeout(60000);                       // 60秒socket超时
            
            // 设置连接保持活跃参数
            dataSource.setKeepAlive(true);                            // 保持连接活跃
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大连接生命周期参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大连接生命周期参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大网络配置参数
     */
    private void testMaxNetworkConfig() {
        System.out.println("--- 测试最大网络配置参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置网络参数
            dataSource.setConnectTimeout(60000);              // 60秒连接超时
            dataSource.setSocketTimeout(60000);                // 60秒socket超时
            dataSource.setUseUnfairLock(true);                 // 使用非公平锁提高性能
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大网络配置参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大网络配置参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大监控配置参数
     */
    private void testMaxMonitoringConfig() {
        System.out.println("--- 测试最大监控配置参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 启用所有监控功能
            dataSource.setRemoveAbandoned(true);               // 移除泄露连接
            dataSource.setRemoveAbandonedTimeout(1800);         // 30分钟移除超时
            dataSource.setLogAbandoned(true);                   // 记录泄露连接日志
            
            // 启用统计功能
            dataSource.setUseGlobalDataSourceStat(true);       // 全局统计
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大监控配置参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大监控配置参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大性能配置参数
     */
    private void testMaxPerformanceConfig() {
        System.out.println("--- 测试最大性能配置参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置性能优化参数
            dataSource.setPoolPreparedStatements(true);         // 缓存PreparedStatement
            dataSource.setMaxPoolPreparedStatementPerConnectionSize(1000); // 每个连接最大缓存1000个PreparedStatement
            
            // 设置连接池优化参数
            dataSource.setUseUnfairLock(true);                   // 使用非公平锁
            dataSource.setMaxWait(30000);                        // 30秒最大等待
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大性能配置参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大性能配置参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大安全配置参数
     */
    private void testMaxSecurityConfig() {
        System.out.println("--- 测试最大安全配置参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置安全参数
            dataSource.setFilters("stat,wall");          // 启用监控、防火墙过滤器
            dataSource.setConnectionProperties("druid.stat.mergeSql=true;druid.stat.slowSqlMillis=1000"); // 统计配置
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大安全配置参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大安全配置参数测试失败: " + e.getMessage());
        }
    }

    /**
     * 测试最大并发配置参数
     */
    private void testMaxConcurrentConfig() {
        System.out.println("--- 测试最大并发配置参数 ---");
        
        try {
            DruidDataSource dataSource = new DruidDataSource();
            
            // 配置基本连接参数
            configureDataSource(dataSource);
            
            // 设置并发参数
            dataSource.setMaxActive(500);                       // 最大连接数
            dataSource.setMaxWait(60000);                        // 60秒最大等待
            dataSource.setUseUnfairLock(true);                   // 使用非公平锁提高并发性能
            
            try (Connection conn = dataSource.getConnection()) {
                // 简化测试：只测试连接是否成功
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✓ 最大并发配置参数测试成功");
                } else {
                    throw new Exception("连接创建失败");
                }
            }
            
            dataSource.close();
            
        } catch (Exception e) {
            System.err.println("最大并发配置参数测试失败: " + e.getMessage());
        }
    }
}
