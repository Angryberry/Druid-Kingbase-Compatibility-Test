package com.example.druid.util;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

/**
 * Druid 数据源工具类
 * 提供统一的配置方法，防止连接死循环
 */
public class DruidDataSourceUtil {
    
    /**
     * 创建配置了超时参数的 DruidDataSource
     * @param properties 配置属性
     * @return 配置好的 DruidDataSource
     */
    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        
        // 基本配置
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        
        // 验证查询配置
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle", "true")));
        dataSource.setValidationQuery(properties.getProperty("validationQuery", "SELECT 1"));
        
        // 连接超时配置，防止死循环
        dataSource.setMaxWait(5000); // 5秒超时
        dataSource.setConnectionErrorRetryAttempts(1); // 只重试1次
        dataSource.setBreakAfterAcquireFailure(true); // 失败后停止
        
        return dataSource;
    }
    
    /**
     * 创建配置了超时参数的 DruidDataSource（带自定义用户名）
     * @param properties 配置属性
     * @param customUsername 自定义用户名
     * @return 配置好的 DruidDataSource
     */
    public static DruidDataSource createDataSourceWithCustomUsername(Properties properties, String customUsername) {
        DruidDataSource dataSource = createDataSource(properties);
        dataSource.setUsername(customUsername);
        return dataSource;
    }
    
    /**
     * 创建配置了超时参数的 DruidDataSource（带自定义用户名和密码）
     * @param properties 配置属性
     * @param customUsername 自定义用户名
     * @param customPassword 自定义密码
     * @return 配置好的 DruidDataSource
     */
    public static DruidDataSource createDataSourceWithCustomCredentials(Properties properties, String customUsername, String customPassword) {
        DruidDataSource dataSource = createDataSource(properties);
        dataSource.setUsername(customUsername);
        dataSource.setPassword(customPassword);
        return dataSource;
    }
}
