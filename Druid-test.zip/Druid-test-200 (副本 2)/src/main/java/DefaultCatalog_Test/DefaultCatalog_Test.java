package DefaultCatalog_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class DefaultCatalog_Test {

    // 修正点：根据你的测试结果，这里应该改为 "test"
    public static final String EXPECTED_CATALOG = "test";

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();

        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 设置默认 Catalog
        dataSource.setDefaultCatalog(EXPECTED_CATALOG);

        dataSource.setInitialSize(1);
        return dataSource;
    }
}