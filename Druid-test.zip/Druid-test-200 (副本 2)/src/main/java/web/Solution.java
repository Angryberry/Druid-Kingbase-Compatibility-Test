package web;

import java.util.*;
import java.io.*;

public class Solution {
    static class Edge {
        int to, weight;
        Edge(int to, int weight) {
            this.to = to;
            this.weight = weight;
        }
    }

    static class Node implements Comparable<Node> {
        int id;
        long dist;

        Node(int id, long dist) {
            this.id = id;
            this.dist = dist;
        }

        @Override
        public int compareTo(Node other) {
            return Long.compare(this.dist, other.dist);
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // 读取输入
        String[] line1 = br.readLine().split(" ");
        int n = Integer.parseInt(line1[0]);
        int m = Integer.parseInt(line1[1]);
        int K = Integer.parseInt(line1[2]);

        // 读取红点
        String[] line2 = br.readLine().split(" ");
        Set<Integer> redNodes = new HashSet<>();
        for (int i = 0; i < m; i++) {
            redNodes.add(Integer.parseInt(line2[i]));
        }

        // 构建邻接表
        List<List<Edge>> graph = new ArrayList<>();
        for (int i = 0; i <= n; i++) {
            graph.add(new ArrayList<>());
        }

        for (int i = 0; i < n - 1; i++) {
            String[] edge = br.readLine().split(" ");
            int u = Integer.parseInt(edge[0]);
            int v = Integer.parseInt(edge[1]);
            int w = Integer.parseInt(edge[2]);

            graph.get(u).add(new Edge(v, w));
            graph.get(v).add(new Edge(u, w));
        }

        // 对每个节点计算到所有红点的距离
        long[][] distances = new long[n + 1][m];
        int redIndex = 0;

        for (int red : redNodes) {
            // 从每个红点开始做Dijkstra
            long[] dist = dijkstra(graph, red, n);
            for (int i = 1; i <= n; i++) {
                distances[i][redIndex] = dist[i];
            }
            redIndex++;
        }

        // 计算每个节点的F(v)
        long[] result = new long[n + 1];
        for (int v = 1; v <= n; v++) {
            // 对该节点到所有红点的距离排序
            Arrays.sort(distances[v]);

            // 取前K个距离的和
            for (int i = 0; i < K; i++) {
                result[v] += distances[v][i];
            }
        }

        // 输出结果
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= n; i++) {
            sb.append(result[i]);
            if (i < n) sb.append(" ");
        }
        System.out.println(sb.toString());
    }

    // Dijkstra算法计算单源最短路径
    static long[] dijkstra(List<List<Edge>> graph, int start, int n) {
        long[] dist = new long[n + 1];
        Arrays.fill(dist, Long.MAX_VALUE);
        dist[start] = 0;

        PriorityQueue<Node> pq = new PriorityQueue<>();
        pq.offer(new Node(start, 0));

        boolean[] visited = new boolean[n + 1];

        while (!pq.isEmpty()) {
            Node current = pq.poll();
            int u = current.id;

            if (visited[u]) continue;
            visited[u] = true;

            for (Edge edge : graph.get(u)) {
                int v = edge.to;
                long weight = edge.weight;

                if (!visited[v] && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.offer(new Node(v, dist[v]));
                }
            }
        }

        return dist;
    }
}