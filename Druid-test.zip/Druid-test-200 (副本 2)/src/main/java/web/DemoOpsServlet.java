package web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(urlPatterns = "/demo/run")
public class DemoOpsServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        DataSource ds = DruidInitListener.get(getServletContext());
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement("select 1");
             ResultSet rs = ps.executeQuery()) {
            resp.setContentType("text/plain;charset=UTF-8");
            resp.getWriter().println("ok");
        } catch (Exception e) {
            e.printStackTrace(resp.getWriter());
        }
    }
}
