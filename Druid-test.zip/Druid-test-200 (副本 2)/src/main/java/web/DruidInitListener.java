package web;

import com.alibaba.druid.pool.DruidDataSource;
import javax.servlet.annotation.WebListener;
import javax.servlet.*;
import javax.sql.DataSource;
import java.io.InputStream;
import java.util.Properties;

@WebListener
public class DruidInitListener implements ServletContextListener {
    private DruidDataSource ds;

    @Override public void contextInitialized(ServletContextEvent sce) {
        try (InputStream in = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("druid.properties")) {
            Properties p = new Properties(); p.load(in);

            ds = new DruidDataSource();
            ds.setName("kingbase-ds"); // 监控台显示的名字
            ds.setDriverClassName(p.getProperty("driverClassName"));
            ds.setUrl(p.getProperty("url"));
            ds.setUsername(p.getProperty("username"));
            ds.setPassword(p.getProperty("password"));
            ds.setInitialSize(Integer.parseInt(p.getProperty("initialSize","2")));
            ds.setMaxActive(Integer.parseInt(p.getProperty("maxActive","10")));
            ds.setMinIdle(Integer.parseInt(p.getProperty("minIdle","1")));
            ds.setValidationQuery(p.getProperty("validationQuery","select 1"));
            ds.setTestWhileIdle(true);

            // 开启 SQL 统计（关键）
            ds.setFilters("stat");
            ds.init();

            // 放到应用上下文
            sce.getServletContext().setAttribute("druidDataSource", ds);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    @Override public void contextDestroyed(ServletContextEvent sce) {
        if (ds != null) ds.close();
    }

    public static DataSource get(ServletContext ctx) {
        return (DataSource) ctx.getAttribute("druidDataSource");
    }
}
