package web;

import java.util.*;

public class MinimumInsertions {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();  // 数组的长度
        int[] a = new int[n];       // 数组元素
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }

        Set<Integer> seen = new HashSet<>(); // 用于存储已经出现的元素
        int maxValue = 0;  // 当前前缀的最大值
        List<Integer> result = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            seen.add(a[i]);    // 添加当前元素到集合
            maxValue = Math.max(maxValue, a[i]); // 更新当前最大值

            // 计算缺失的元素数量
            int missing = maxValue - seen.size();
            result.add(missing);
        }

        // 输出结果
        for (int res : result) {
            System.out.print(res + " ");
        }
    }
}
