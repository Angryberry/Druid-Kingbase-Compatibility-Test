package web;

import java.util.Scanner;

public class TrainCategory {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int T = scanner.nextInt(); // 读取数据组数
        StringBuilder result = new StringBuilder();

        while (T-- > 0) {
            int v = scanner.nextInt(); // 读取列车时速

            boolean foundCategory = false; // 标记是否找到符合的类别

            // 根据时速v判断列车属于哪个类别
            if (v >= 250 && v <= 350) {
                result.append("G ");
                foundCategory = true;
            }
            if (v >= 160 && v <= 250) {
                result.append("D ");
                foundCategory = true;
            }
            if (v >= 200 && v <= 300) {
                result.append("C ");
                foundCategory = true;
            }

            // 如果没有命中任何类别，输出"other"
            if (!foundCategory) {
                result.append("other");
            } else {
                result.setLength(result.length() - 1); // 去掉最后一个多余的空格
            }

            result.append("\n");
        }

        System.out.print(result.toString());
        scanner.close();
    }
}
