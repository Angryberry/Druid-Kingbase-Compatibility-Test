package AsyncCloseConnectionEnable_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.util.Properties;

public class AsyncCloseConnectionEnable_Test {
    public static final boolean ASYNC_CLOSE_ENABLE = true;

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 核心参数
        dataSource.setAsyncCloseConnectionEnable(ASYNC_CLOSE_ENABLE);

        dataSource.setMaxActive(2);
        dataSource.setInitialSize(1);

        return dataSource;
    }
}