package test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class DruidDemo {

    public static void main(String[] args) {
        Properties properties = new Properties();

        // 加载配置文件
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建 Druid 数据源并加载配置
        DruidDataSource dataSource = new DruidDataSource();

        // 配置 Druid 数据源
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }


        // 获取连接并测试
        try (Connection connection = dataSource.getConnection()) {
            // 1. 插入数据
            String insertSql = "INSERT INTO users (name, age) VALUES (?, ?)";
            try (PreparedStatement insertStmt = connection.prepareStatement(insertSql)) {
                insertStmt.setString(1, "John Doe");
                insertStmt.setInt(2, 30);
                insertStmt.executeUpdate();
                System.out.println("Inserted new user: John Doe, Age 30");
            }

            // 2. 更新数据
            String updateSql = "UPDATE users SET age = ? WHERE name = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                updateStmt.setInt(1, 31); // 更新年龄
                updateStmt.setString(2, "John Doe");
                updateStmt.executeUpdate();
                System.out.println("Updated user: John Doe, Age 31");
            }

            // 3. 删除数据
            String deleteSql = "DELETE FROM users WHERE name = ?";
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteSql)) {
                deleteStmt.setString(1, "John Doe");
                deleteStmt.executeUpdate();
                System.out.println("Deleted user: John Doe");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

}
