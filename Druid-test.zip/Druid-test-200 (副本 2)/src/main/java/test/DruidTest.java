package test;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class DruidTest {
    public static void main(String[] args) {
        Properties properties = new Properties();

        // 加载配置文件
        try (FileInputStream fis = new FileInputStream("src/main/resources/druid.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 创建 Druid 数据源并加载配置
        DruidDataSource dataSource = new DruidDataSource();

        // 配置 Druid 数据源
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        if ("oracle".equalsIgnoreCase(getModel())) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }


        // 设置连接池参数
        dataSource.setInitialSize(Integer.parseInt(properties.getProperty("initialSize")));
        dataSource.setMaxActive(Integer.parseInt(properties.getProperty("maxActive")));
        dataSource.setMinIdle(Integer.parseInt(properties.getProperty("minIdle")));

        // 设置验证查询
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle")));
        dataSource.setValidationQuery(properties.getProperty("validationQuery"));

        // 获取连接并测试
        try (Connection connection = dataSource.getConnection()) {
            System.out.println("Connection successful!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static String getModel() {
        DruidDataSource dataSource = new DruidDataSource();
        String url = dataSource.getUrl();
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

}
