#!/bin/bash

# 检查和管理 Kingbase 数据库连接的辅助脚本

DB_HOST="localhost"
DB_PORT="54321"
DB_NAME="test"
DB_USER="system"
DB_PASSWORD="root"

echo "=========================================="
echo "  Kingbase 数据库连接检查工具"
echo "=========================================="
echo ""

# 检查数据库连接状态
check_connections() {
    echo "📊 检查当前数据库连接状态..."
    echo ""
    
    # 使用 psql 或 ksql 连接数据库查询连接数
    # 注意：根据你的 Kingbase 版本，可能需要使用 ksql 或 psql 命令
    
    SQL_QUERY="
SELECT 
    count(*) as total_connections,
    count(*) FILTER (WHERE state = 'active') as active_connections,
    count(*) FILTER (WHERE state = 'idle') as idle_connections,
    count(*) FILTER (WHERE state = 'idle in transaction') as idle_in_transaction,
    count(*) FILTER (WHERE state = 'idle in transaction (aborted)') as aborted_connections
FROM pg_stat_activity
WHERE datname = '${DB_NAME}';
"
    
    echo "执行查询:"
    echo "$SQL_QUERY"
    echo ""
    
    # 如果有 PGPASSWORD 环境变量设置，可以直接执行
    # 否则需要手动输入密码
    PGPASSWORD="${DB_PASSWORD}" psql -h "${DB_HOST}" -p "${DB_PORT}" -U "${DB_USER}" -d "${DB_NAME}" -c "${SQL_QUERY}" 2>/dev/null
    
    if [ $? -ne 0 ]; then
        echo "⚠️  无法连接数据库，请检查:"
        echo "   - 数据库是否运行"
        echo "   - 连接信息是否正确: ${DB_HOST}:${DB_PORT}/${DB_NAME}"
        echo "   - 用户权限是否足够"
        echo ""
        echo "手动连接命令:"
        echo "  psql -h ${DB_HOST} -p ${DB_PORT} -U ${DB_USER} -d ${DB_NAME}"
        echo ""
        echo "然后执行以下 SQL:"
        echo "$SQL_QUERY"
    fi
}

# 查看详细连接信息
show_connections() {
    echo "📋 查看详细连接信息..."
    echo ""
    
    SQL_QUERY="
SELECT 
    pid,
    usename,
    application_name,
    client_addr,
    state,
    query_start,
    state_change,
    LEFT(query, 50) as current_query
FROM pg_stat_activity
WHERE datname = '${DB_NAME}'
ORDER BY state, query_start;
"
    
    PGPASSWORD="${DB_PASSWORD}" psql -h "${DB_HOST}" -p "${DB_PORT}" -U "${DB_USER}" -d "${DB_NAME}" -c "${SQL_QUERY}" 2>/dev/null
    
    if [ $? -ne 0 ]; then
        echo "⚠️  无法执行查询，请手动连接数据库执行:"
        echo "$SQL_QUERY"
    fi
}

# 清理空闲连接
cleanup_idle_connections() {
    echo "🧹 清理空闲连接（idle 状态）..."
    echo ""
    echo "⚠️  警告: 这将终止所有空闲连接！"
    echo ""
    read -p "确认继续? (y/N): " confirm
    
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo "已取消"
        return
    fi
    
    SQL_QUERY="
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE datname = '${DB_NAME}'
  AND pid <> pg_backend_pid()
  AND state = 'idle'
  AND state_change < now() - interval '5 minutes';
"
    
    echo "执行清理..."
    PGPASSWORD="${DB_PASSWORD}" psql -h "${DB_HOST}" -p "${DB_PORT}" -U "${DB_USER}" -d "${DB_NAME}" -c "${SQL_QUERY}" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo "✅ 清理完成"
    else
        echo "⚠️  清理失败，请手动执行:"
        echo "$SQL_QUERY"
    fi
}

# 查看 max_connections 配置
show_max_connections() {
    echo "⚙️  查看最大连接数配置..."
    echo ""
    
    PGPASSWORD="${DB_PASSWORD}" psql -h "${DB_HOST}" -p "${DB_PORT}" -U "${DB_USER}" -d "${DB_NAME}" -c "SHOW max_connections;" 2>/dev/null
    
    if [ $? -ne 0 ]; then
        echo "⚠️  无法查询，请手动执行: SHOW max_connections;"
    fi
}

# 主菜单
show_menu() {
    echo ""
    echo "请选择操作:"
    echo "  [1] 检查连接状态"
    echo "  [2] 查看详细连接信息"
    echo "  [3] 查看最大连接数配置"
    echo "  [4] 清理空闲连接（谨慎使用）"
    echo "  [0] 退出"
    echo ""
}

# 主循环
while true; do
    show_menu
    read -p "👉 输入选项: " choice
    
    case $choice in
        1)
            check_connections
            ;;
        2)
            show_connections
            ;;
        3)
            show_max_connections
            ;;
        4)
            cleanup_idle_connections
            ;;
        0)
            echo "退出"
            exit 0
            ;;
        *)
            echo "❌ 无效选项"
            ;;
    esac
done

