-- 创建 users 表的 SQL 语句
-- 适用于 KingBase8 数据库

-- 如果表已存在则删除
DROP TABLE IF EXISTS users;

-- 创建 users 表
CREATE TABLE users (
    id SERIAL PRIMARY KEY,           -- 自增主键
    name VARCHAR(50) NOT NULL,      -- 用户名，非空
    age INTEGER                     -- 年龄，可为空
);

-- 插入一些测试数据
INSERT INTO users (name, age) VALUES 
    ('张三', 25),
    ('李四', 30),
    ('王五', 28),
    ('赵六', 35),
    ('测试用户', 22);

-- 查询验证数据
SELECT * FROM users;
