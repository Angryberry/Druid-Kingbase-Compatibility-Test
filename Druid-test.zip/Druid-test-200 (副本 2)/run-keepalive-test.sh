#!/bin/bash

echo "=========================================="
echo "  Druid Keepalive 保活查询验证测试"
echo "=========================================="
echo ""
echo "本测试用于验证 SELECT 1 保活查询的执行情况"
echo ""
echo "测试内容:"
echo "  1. keepAlive 开启时的保活查询"
echo "  2. testOnBorrow/testOnReturn/testWhileIdle 的验证查询"
echo "  3. 业务SQL执行时的保活行为"
echo ""
echo "提示: 程序启动后访问监控页面查看 SQL 统计"
echo "      重点关注 'SELECT 1' 的执行次数和时间"
echo ""
echo "正在启动..."
echo ""

cd "$(dirname "$0")"
mvn compile exec:java -Dexec.mainClass="ScenarioTest.KeepaliveValidation"

