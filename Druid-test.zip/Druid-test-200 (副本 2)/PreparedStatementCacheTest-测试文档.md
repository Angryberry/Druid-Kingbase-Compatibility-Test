# Druid PreparedStatement 缓存测试文档

## 一、测试概述

### 1.1 测试目的
本测试用于验证 Druid 连接池中 PreparedStatement（PS）缓存机制的正确性，包括：
- PreparedStatement 对象的缓存与复用
- 逻辑关闭 vs 物理关闭对缓存的影响
- 多线程环境下缓存的隔离性
- 缓存失效与重建机制

### 1.2 测试范围
- PreparedStatement 缓存开关的控制
- 连接归还时缓存的保存机制
- 连接物理关闭时缓存的失效机制
- 并发场景下缓存的线程安全性

### 1.3 测试环境
- **数据库**: Kingbase ES V8
- **监控端口**: 8092（区别于其他测试的8091）
- **配置文件**: `src/main/resources/druid.properties`

---

## 二、测试场景详细说明

### 场景1：关闭缓存（基线）

**测试SQL**:
```sql
SELECT 1 AS id, 'test' AS name
```

**测试目的**:
- 验证未开启缓存时，每次 `prepareStatement` 都创建新的 PreparedStatement 对象
- 作为基线对照，验证缓存功能的必要性

**执行流程**:
1. 获取连接 conn1，创建 PreparedStatement ps1
2. 关闭 ps1 和 conn1
3. 获取连接 conn2，创建 PreparedStatement ps2
4. 比较 ps1 和 ps2 的 hashCode

**预期结果**:
- ps1 和 ps2 是不同的对象（hashCode 不同）
- 每次调用 `prepareStatement` 都会创建新对象
- 说明未使用缓存，每次都是全新创建

**验证方法**:
1. 查看控制台输出的 hashCode 值
2. 确认两次 hashCode 不同
3. 监控页面查看 PreparedStatement 相关统计

**配置参数**:
- `poolPreparedStatements = false`（缓存关闭）
- `maxPoolPreparedStatementPerConnectionSize = 20`（但缓存未启用）

**核心验证点**:
- ✅ 未开启缓存时，每次创建新对象
- ✅ 连接池不会复用 PreparedStatement
- ✅ 作为基线，证明缓存功能的价值

---

### 场景2：开启缓存 + 逻辑关闭

**测试SQL**:
```sql
SELECT 1 AS id, 'test' AS name
```

**测试目的**:
- 验证开启缓存后，连接归还时 PreparedStatement 对象被缓存
- 验证逻辑关闭（`ps.close()`）时，对象进入缓存而非销毁
- 验证下次获取相同 SQL 时，能复用缓存的 PreparedStatement

**执行流程**:
1. 获取连接 conn1，创建 PreparedStatement ps1，记录 hashCode1
2. 关闭 ps1（逻辑关闭，应进入缓存）
3. 关闭 conn1（连接归还到连接池）
4. 获取连接 conn2（可能是同一个物理连接）
5. 创建 PreparedStatement ps2（相同SQL），记录 hashCode2
6. 比较 hashCode1 和 hashCode2

**预期结果**:
- hashCode1 == hashCode2（同一个对象）
- 说明 PreparedStatement 被成功缓存和复用
- 监控页面显示缓存命中情况

**验证方法**:
1. 查看控制台输出的 hashCode 值
2. 确认两次 hashCode 相同
3. 查看控制台提示："缓存命中！两次获取的是同一个对象"
4. 监控页面查看 PreparedStatement 缓存统计

**配置参数**:
- `poolPreparedStatements = true`（缓存开启）
- `maxPoolPreparedStatementPerConnectionSize = 20`（每个连接最多缓存20个）
- `minEvictableIdleTimeMillis` 未设置（连接不会物理关闭）

**核心验证点**:
- ✅ 缓存机制正常工作
- ✅ 逻辑关闭时对象被缓存
- ✅ 连接归还后对象可被复用
- ✅ 减少 PreparedStatement 的重复编译，提升性能

**性能影响**:
- 避免重复编译 SQL，减少数据库开销
- 提升相同 SQL 的执行效率

---

### 场景3：开启缓存 + 物理关闭

**测试SQL**:
```sql
SELECT 1 AS id, 'test' AS name
```

**测试目的**:
- 验证连接物理关闭后，PreparedStatement 缓存失效
- 验证空闲连接被销毁时，缓存会随之清除
- 验证新连接会重新创建 PreparedStatement

**执行流程**:
1. 获取连接 conn1，创建 PreparedStatement ps1，记录 hashCode1
2. 关闭 ps1 和 conn1（连接归还到连接池）
3. **等待 4 秒**（确保连接空闲超时，被物理关闭）
   - `minEvictableIdleTimeMillis = 3000`（3秒后空闲连接可被销毁）
   - `timeBetweenEvictionRunsMillis = 2000`（每2秒检查一次）
4. 获取连接 conn2（新建的连接，因为旧的已被销毁）
5. 创建 PreparedStatement ps2（相同SQL），记录 hashCode2
6. 比较 hashCode1 和 hashCode2

**预期结果**:
- hashCode1 != hashCode2（不同的对象）
- 说明原连接被物理关闭，缓存失效
- 新连接需要重新编译 SQL，创建新的 PreparedStatement

**验证方法**:
1. 观察控制台倒计时提示
2. 查看两次输出的 hashCode 值
3. 确认 hashCode 不同
4. 查看提示："连接被物理关闭，缓存失效并重新创建"
5. 监控页面查看连接销毁和重建统计

**配置参数**:
- `poolPreparedStatements = true`（缓存开启）
- `minEvictableIdleTimeMillis = 3000`（3秒空闲超时）
- `timeBetweenEvictionRunsMillis = 2000`（每2秒检查）
- `keepAlive = false`（不启用保活）

**核心验证点**:
- ✅ 物理关闭时缓存正确失效
- ✅ 空闲连接管理机制正常
- ✅ 缓存与连接生命周期绑定
- ✅ 新连接重建时能正确创建新的 PreparedStatement

**注意事项**:
- 此场景需要等待约 4 秒，请耐心等待
- 确保连接池配置的 `maxActive=2`，避免创建过多连接

---

### 场景4：多线程缓存共享性

**测试SQL**:
```sql
SELECT 1 AS id, 'test' AS name
```

**测试目的**:
- 验证多线程并发访问时，缓存的隔离性
- 验证不同连接拥有各自独立的缓存
- 验证缓存不会跨连接共享，确保线程安全

**执行流程**:
1. 创建 5 个并发线程
2. 每个线程：
   - 获取一个连接（可能是不同的连接）
   - 执行相同的 SQL，创建 PreparedStatement
   - 记录 PreparedStatement 的 hashCode
3. 等待所有线程完成
4. 统计所有 hashCode 的唯一数量

**预期结果**:
- 如果每个线程获得不同的连接，则 PreparedStatement 对象数 = 线程数（5个）
- 如果部分线程复用同一连接，则对象数 < 线程数
- 缓存按连接隔离，不同连接的缓存互不影响
- 验证缓存的线程安全性

**验证方法**:
1. 查看控制台输出的每个线程的 hashCode
2. 查看唯一对象数统计
3. 分析 hashCode 的分布情况
4. 确认提示："缓存按连接隔离，不同连接有各自的缓存"

**配置参数**:
- `poolPreparedStatements = true`（缓存开启）
- `maxActive = 2`（最多2个连接）
- `initialSize = 1`（初始1个连接）

**核心验证点**:
- ✅ 缓存按连接隔离（不是全局共享）
- ✅ 不同连接有各自的缓存空间
- ✅ 多线程环境下缓存机制线程安全
- ✅ 相同 SQL 在不同连接中可能创建不同的 PreparedStatement 对象

**并发行为分析**:
- 如果 `maxActive=2`，最多同时有 2 个连接
- 5 个线程会竞争这 2 个连接
- 获得同一连接的线程，如果 SQL 相同，可能复用缓存的 PreparedStatement
- 获得不同连接的线程，会创建各自连接上的 PreparedStatement

---

## 三、测试执行步骤

### 3.1 前置准备

1. **确保数据库运行**
   ```bash
   # 检查 Kingbase 数据库是否运行
   # 确保连接信息正确（查看 druid.properties）
   ```

2. **检查端口占用**
   ```bash
   # 确认端口 8092 未被占用（这是本测试的监控端口）
   netstat -an | grep 8092
   ```

3. **了解缓存机制**
   - 理解 PreparedStatement 缓存的工作原理
   - 理解逻辑关闭 vs 物理关闭的区别
   - 了解连接池的连接生命周期管理

### 3.2 执行测试

#### 方式一：使用 Shell 脚本（推荐）

```bash
# 赋予执行权限
chmod +x prepared_statement_cache_druid_test.sh

# 运行测试
./prepared_statement_cache_druid_test.sh
```

#### 方式二：直接使用 Maven

```bash
cd /path/to/project
mvn compile exec:java -Dexec.mainClass="Z_ScenarioTest.PreparedStatementCacheTest"
```

#### 方式三：使用 IDE

1. 打开 `PreparedStatementCacheTest.java`
2. 右键选择 `Run 'PreparedStatementCacheTest.main()'`

### 3.3 测试流程

1. **启动程序**
   - 程序会自动加载配置
   - 启动监控服务器（端口 **8092**）
   - 初始化所有测试场景

2. **选择测试场景**
   - 查看场景列表（显示每个场景的缓存状态）
   - 输入场景编号 [1-4] 执行对应测试
   - 输入 0 退出程序

3. **观察测试结果**
   - **场景1**: 查看两次 hashCode 是否不同
   - **场景2**: 查看两次 hashCode 是否相同（缓存命中）
   - **场景3**: 等待约 4 秒后，查看 hashCode 是否不同（缓存失效）
   - **场景4**: 查看所有线程的 hashCode，统计唯一对象数

4. **查看监控页面**
   - 访问：`http://localhost:8092/druid/`
   - 用户名: `admin`，密码: `admin`
   - 查看 SQL 统计页面：`http://localhost:8092/druid/sql.html`
   - 查看数据源页面：`http://localhost:8092/druid/datasource.html`

5. **验证结果**
   - 对照预期结果验证实际输出
   - 检查 hashCode 的匹配情况
   - 分析监控数据

---

## 四、监控页面使用指南

### 4.1 访问监控页面

1. **打开浏览器**
   ```
   http://localhost:8092/druid/
   ```

2. **登录**
   - 用户名: `admin`
   - 密码: `admin`

### 4.2 关键监控页面

#### SQL 统计页面
- **URL**: `http://localhost:8092/druid/sql.html`
- **功能**: 
  - 查看 PreparedStatement 的执行统计
  - 查看 merge-sql 聚合结果（如果启用）
  - 查看 SQL 执行时间、次数等

#### 数据源页面
- **URL**: `http://localhost:8092/druid/datasource.html`
- **功能**:
  - 查看连接池状态
  - 查看活跃连接数
  - 查看 PreparedStatement 缓存数量
  - 查看连接池配置参数

### 4.3 关键指标说明

- **PreparedStatement 数量**: 当前缓存的 PreparedStatement 数量
- **执行次数**: SQL 执行的累计次数
- **缓存命中率**: 复用缓存的次数 / 总执行次数
- **连接数**: 当前活跃和空闲的连接数

---

## 五、预期结果验证

### 5.1 场景1验证清单
- [ ] 控制台显示两次 hashCode 不同
- [ ] 提示："若两次对象不同，说明未使用缓存"
- [ ] PreparedStatement 每次都重新创建
- [ ] 监控页面显示 PreparedStatement 统计

### 5.2 场景2验证清单
- [ ] 控制台显示两次 hashCode **相同**
- [ ] 提示："缓存命中！两次获取的是同一个对象"
- [ ] PreparedStatement 被成功缓存和复用
- [ ] 监控页面显示缓存相关的统计信息

### 5.3 场景3验证清单
- [ ] 程序等待约 4 秒（显示倒计时）
- [ ] 控制台显示两次 hashCode **不同**
- [ ] 提示："连接被物理关闭，缓存失效并重新创建"
- [ ] 连接池自动创建新连接
- [ ] 新连接重新编译 SQL 并创建 PreparedStatement

### 5.4 场景4验证清单
- [ ] 控制台显示 5 个线程的 hashCode
- [ ] 显示唯一对象数统计
- [ ] 提示："缓存按连接隔离，不同连接有各自的缓存"
- [ ] 唯一对象数 ≤ 5（因为连接池最多2个连接）
- [ ] 监控页面显示并发执行统计

---

## 六、关键技术点说明

### 6.1 PreparedStatement 缓存原理

**缓存机制**:
- 每个连接维护一个 PreparedStatement 缓存
- 以 SQL 字符串为 key，PreparedStatement 对象为 value
- 逻辑关闭时，对象不销毁，保留在缓存中
- 物理关闭时，连接和缓存一起销毁

**缓存参数**:
- `poolPreparedStatements`: 是否启用缓存
- `maxPoolPreparedStatementPerConnectionSize`: 每个连接最多缓存的数量（默认-1，表示不限制，但建议设置合理值）

### 6.2 逻辑关闭 vs 物理关闭

**逻辑关闭**:
- 调用 `PreparedStatement.close()` 时
- 对象不销毁，进入连接级别的缓存
- 连接归还到连接池时，缓存仍然保留
- 适用于连接复用场景

**物理关闭**:
- 连接空闲超时被销毁时
- 连接级别的缓存随之销毁
- 所有缓存的 PreparedStatement 对象都失效
- 适用于连接生命周期管理

### 6.3 缓存隔离性

**按连接隔离**:
- 每个连接有独立的缓存空间
- 不同连接的缓存互不影响
- 相同 SQL 在不同连接中可能创建不同的 PreparedStatement
- 确保线程安全和隔离性

**并发场景**:
- 多个线程可能获得同一个连接
- 相同连接上的相同 SQL 会复用缓存的 PreparedStatement
- 不同连接上的相同 SQL 会创建各自的 PreparedStatement

### 6.4 性能影响

**缓存的好处**:
- 减少 SQL 编译开销
- 提升相同 SQL 的执行效率
- 减少数据库服务器负载

**缓存的开销**:
- 占用内存（每个 PreparedStatement 对象）
- 需要管理缓存的生命周期
- 设置合理的缓存大小很重要

---

## 七、常见问题排查

### 7.1 场景2缓存未命中

**问题**: 场景2中两次获取的 PreparedStatement hashCode 不同

**可能原因**:
1. 连接池创建了新连接（非复用原连接）
2. 缓存配置未生效
3. SQL 字符串不完全相同（包括空格、大小写等）

**排查步骤**:
1. 确认 `poolPreparedStatements = true` 已设置
2. 检查 SQL 字符串是否完全一致
3. 查看连接池是否复用了连接
4. 增加 `initialSize` 和 `maxActive` 确保连接复用

### 7.2 场景3连接未物理关闭

**问题**: 场景3等待后 hashCode 仍然相同

**可能原因**:
1. 等待时间不够（需要至少 4 秒）
2. 连接未达到空闲超时时间
3. 连接池配置不允许物理关闭

**排查步骤**:
1. 确认等待时间 ≥ `minEvictableIdleTimeMillis + 1000`
2. 检查 `minEvictableIdleTimeMillis` 配置是否正确
3. 确认 `keepAlive = false`
4. 查看连接池日志，确认连接是否被销毁

### 7.3 场景4唯一对象数异常

**问题**: 场景4的唯一对象数与预期不符

**可能原因**:
1. 连接数配置导致部分线程共享连接
2. 线程执行时机不同导致结果差异
3. hashCode 碰撞（极小概率）

**排查步骤**:
1. 查看每个线程获得的连接信息
2. 分析连接池 `maxActive` 配置的影响
3. 多次运行测试，观察结果稳定性
4. 检查是否所有线程执行的是相同 SQL

### 7.4 监控页面无法访问

**问题**: `http://localhost:8092/druid/` 无法打开

**排查步骤**:
1. 确认监控服务器是否启动（查看控制台日志）
2. 检查端口 8092 是否被占用
3. 确认防火墙允许访问该端口
4. 查看 Jetty 服务器启动日志
5. 注意：本测试使用 8092 端口，与其他测试的 8091 不同

### 7.5 SQL 执行报错

**问题**: SQL 执行时出现异常

**排查步骤**:
1. 查看完整的错误堆栈信息
2. 检查 SQL 语法是否正确
3. 确认数据库连接是否正常
4. 验证数据库用户权限
5. 检查数据库日志

---

## 八、测试数据准备（可选）

本测试使用的 SQL 不需要实际数据表：

```sql
SELECT 1 AS id, 'test' AS name
```

这是一个简单的查询，不依赖任何表结构，可以直接执行。

**注意**: 如果测试中使用实际的表，需要确保表存在且有数据。

---

## 九、测试报告模板

### 9.1 测试环境信息

```
测试日期: [日期]
测试人员: [姓名]
数据库版本: [Kingbase版本]
Druid版本: [Druid版本]
操作系统: [OS版本]
Java版本: [Java版本]
```

### 9.2 测试结果记录

| 场景编号 | 场景名称 | hashCode比较 | 预期结果 | 是否通过 | 备注 |
|---------|---------|-------------|---------|---------|------|
| 1 | 关闭缓存 | 不同 | 不同 | 通过/失败 | - |
| 2 | 开启缓存+逻辑关闭 | 相同 | 相同 | 通过/失败 | 缓存命中 |
| 3 | 开启缓存+物理关闭 | 不同 | 不同 | 通过/失败 | 缓存失效 |
| 4 | 多线程缓存隔离 | N个唯一对象 | ≤5 | 通过/失败 | 连接数影响结果 |

### 9.3 详细测试数据

#### 场景2详细数据
```
第1次 hashCode: [值]
第2次 hashCode: [值]
是否相同: 是/否
缓存状态: 命中/未命中
```

#### 场景3详细数据
```
第1次 hashCode: [值]
等待时间: [秒]
第2次 hashCode: [值]
是否相同: 否（预期）
缓存状态: 失效重建
```

#### 场景4详细数据
```
线程数: 5
连接池最大连接数: 2
总 PreparedStatement 数: [值]
唯一对象数: [值]
分析: [连接复用情况说明]
```

### 9.4 问题记录

| 问题编号 | 问题描述 | 严重程度 | 状态 | 解决方案 |
|---------|---------|---------|------|---------|
| - | - | - | - | - |

---

## 十、性能测试建议

### 10.1 缓存性能对比

可以对比场景1和场景2的性能差异：

**测试方法**:
1. 执行场景1，记录执行时间
2. 执行场景2，记录执行时间
3. 对比两次执行时间差异

**预期结果**:
- 场景2（启用缓存）应该比场景1更快
- 重复执行相同 SQL 时，缓存带来的性能提升更明显

### 10.2 缓存大小调优

**测试建议**:
- 修改 `maxPoolPreparedStatementPerConnectionSize` 的值
- 测试不同缓存大小对性能的影响
- 找到性能与内存使用的平衡点

**参考值**:
- 小应用: 10-20
- 中应用: 20-50
- 大应用: 50-100

---

## 十一、附录

### 11.1 相关文件

- **测试类**: `src/main/java/Z_ScenarioTest/PreparedStatementCacheTest.java`
- **Shell脚本**: `prepared_statement_cache_druid_test.sh`
- **配置文件**: `src/main/resources/druid.properties`
- **本文档**: `PreparedStatementCacheTest-测试文档.md`

### 11.2 参考文档

- [Druid 官方文档](https://github.com/alibaba/druid/wiki)
- [PreparedStatement 缓存配置](https://github.com/alibaba/druid/wiki/配置_StatFilter)
- [连接池配置说明](https://github.com/alibaba/druid/wiki/配置_DruidDataSource)

### 11.3 关键配置参数

```properties
# PreparedStatement 缓存配置
poolPreparedStatements=true                          # 启用缓存
maxPoolPreparedStatementPerConnectionSize=20        # 每个连接最大缓存数

# 连接池配置（场景3相关）
minEvictableIdleTimeMillis=3000                      # 空闲连接可被销毁的时间
timeBetweenEvictionRunsMillis=2000                  # 检查空闲连接的频率
keepAlive=false                                      # 不启用保活
```

### 11.4 hashCode 说明

**什么是 hashCode**:
- Java 对象的唯一标识符（用于快速比较对象）
- 相同对象有相同的 hashCode
- 不同对象的 hashCode 可能相同（哈希碰撞），但概率很低

**在本测试中的作用**:
- 通过比较 hashCode 判断是否为同一个对象
- hashCode 相同 → 同一个 PreparedStatement 对象（缓存命中）
- hashCode 不同 → 不同的 PreparedStatement 对象（未缓存或缓存失效）

---

**文档版本**: v1.0  
**最后更新**: 2025-01-01  
**维护人员**: 测试团队

