#!/bin/bash

echo "=========================================="
echo "  Druid 连接复用验证场景测试"
echo "=========================================="
echo ""
echo "本测试用于验证连接池在回收与复用连接时的行为"
echo ""
echo "测试内容:"
echo "  1. 连接状态复用一致性（验证AutoCommit与事务状态是否被正确重置）"
echo "  2. 连接关闭资源清理（验证Statement、ResultSet等资源是否关闭）"
echo "  3. 复用连接执行新事务（验证复用连接能否正常开启新事务）"
echo "  4. 并发连接复用安全性（多线程并发访问时，确保连接对象不交叉污染）"
echo "  5. 异常连接剔除与重建（模拟数据库断开后，连接池能自动剔除无效连接并新建连接）"
echo ""
echo "提示: 程序启动后访问监控页面查看结果"
echo "      重点关注连接复用后的状态重置、资源清理和连接池的自动恢复能力"
echo ""
echo "正在启动..."
echo ""

cd "$(dirname "$0")"
mvn compile exec:java -Dexec.mainClass="ScenarioTest.ConnectionReuseDruidTest"

