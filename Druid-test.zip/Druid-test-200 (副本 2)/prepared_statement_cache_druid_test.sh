#!/bin/bash

echo "=========================================="
echo "  Druid PreparedStatement 缓存测试"
echo "=========================================="
echo ""
echo "本测试用于验证 Druid PreparedStatement 缓存机制的正确性"
echo ""
echo "测试内容:"
echo "  1. 关闭缓存（基线）（每次prepareStatement都重新创建对象）"
echo "  2. 开启缓存 + 逻辑关闭（连接归还后复用缓存的PreparedStatement对象）"
echo "  3. 开启缓存 + 物理关闭（连接空闲超时被销毁后，缓存失效重新编译SQL）"
echo "  4. 多线程缓存共享性（不同线程执行相同SQL，看缓存是否共享/隔离）"
echo ""
echo "提示: 程序启动后访问监控页面查看缓存统计"
echo "      重点关注PreparedStatement对象的复用情况、缓存命中率和连接隔离性"
echo ""
echo "正在启动..."
echo ""

cd "$(dirname "$0")"
mvn compile exec:java -Dexec.mainClass="ScenarioTest.PreparedStatementCacheTest"

