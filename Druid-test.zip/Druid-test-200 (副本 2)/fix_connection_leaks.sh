#!/bin/bash

# 查找所有没有关闭数据源的测试类
find src/main/java -name "*_Test.java" -exec grep -L "dataSource.close()" {} \; | while read file; do
    echo "修复文件: $file"
    
    # 检查是否已经有finally块
    if grep -q "} finally {" "$file"; then
        echo "  文件 $file 已经有finally块，跳过"
        continue
    fi
    
    # 检查是否有try-with-resources但没有finally块
    if grep -q "try (Connection connection = dataSource.getConnection())" "$file"; then
        echo "  修复 $file 的连接泄漏问题"
        
        # 备份原文件
        cp "$file" "$file.backup"
        
        # 使用sed添加finally块
        sed -i '/} catch (SQLException e) {/,/}/a\
        } finally {\
            // 确保数据源被关闭\
            dataSource.close();\
        }' "$file"
        
        echo "  已修复 $file"
    fi
done

echo "连接泄漏修复完成！"

