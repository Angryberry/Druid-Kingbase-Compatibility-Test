package Z_Parser;
import com.alibaba.druid.stat.JdbcSqlStatValue;
import com.alibaba.druid.stat.JdbcDataSourceStat;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.stat.JdbcSqlStatValue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

public class MergeSql_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }
        dataSource = MergeSql_Test.createDataSource(props);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    /**
     * 场景验证：验证 Kingbase 解析器是否能正确将两条不同参数的 SQL 合并为同一个模板
     */
    @Test
    public void shouldMergeSimilarSqlUsingKingbaseParser() throws SQLException {
        System.out.println(">>> 开始验证 Kingbase SQL 合并 (Merge-SQL) 行为...");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 1. 执行第一条 SQL (ID 为 101)
            stmt.executeQuery("SELECT name FROM users WHERE id = 101");

            // 2. 执行第二条 SQL (ID 为 102)
            stmt.executeQuery("SELECT name FROM users WHERE id = 102");
        }

        // --- 核心断言：直接去翻底层的 Map 账本 ---

        // 1. 获取 SQL 统计的原始 Map (Key 是 SQL 模板，Value 是统计对象)
        // 这种写法在 99% 的 Druid 版本里都通用
        java.util.Map<String, ?> sqlStatMap = dataSource.getDataSourceStat().getSqlStatMap();

        System.out.println(">>> 监控记录中的 SQL 模板总数: " + (sqlStatMap == null ? 0 : sqlStatMap.size()));

        boolean foundMergedSql = false;
        if (sqlStatMap != null) {
            // 遍历 Map 的所有 Key (Key 就是被 Parse 后的 SQL 模板)
            for (String sql : sqlStatMap.keySet()) {
                System.out.println(">>> 监控捕捉到的 SQL 模板: " + sql);

                // 🎯 核心验证点：检查两条 SQL 是不是合并成了带问号的这一条
                if (sql != null && sql.contains("id = ?")) {
                    foundMergedSql = true;
                    System.out.println(">>> ✅ 合并成功！Kingbase 解析器已生效。");
                }
            }
        }

        // 2. 如果合并成功，Map 里的条数应该是 1 (即便执行了两次不同的 id)
        // 如果是 2，说明没合并，解析器可能没干活
        assertTrue("🔴 失败：SQL 未能合并，Map 长度不对或未找到模板", foundMergedSql && sqlStatMap.size() == 1);
    }

    /**
     * 场景验证：测试不同类型的 SQL 是否能正确合并
     */
    @Test
    public void shouldMergeDifferentTypesOfSql() throws SQLException {
        System.out.println(">>> 开始验证不同类型 SQL 的合并行为...");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // INSERT 语句合并测试
            stmt.executeUpdate("INSERT INTO users (name, age) VALUES ('Alice', 25)");
            stmt.executeUpdate("INSERT INTO users (name, age) VALUES ('Bob', 30)");

            // UPDATE 语句合并测试
            stmt.executeUpdate("UPDATE users SET age = 26 WHERE name = 'Alice'");
            stmt.executeUpdate("UPDATE users SET age = 31 WHERE name = 'Bob'");

            // DELETE 语句合并测试
            stmt.executeUpdate("DELETE FROM users WHERE age > 60");
            stmt.executeUpdate("DELETE FROM users WHERE age > 70");
        }

        java.util.Map<String, ?> sqlStatMap = dataSource.getDataSourceStat().getSqlStatMap();
        
        System.out.println(">>> 监控记录中的 SQL 模板总数: " + (sqlStatMap == null ? 0 : sqlStatMap.size()));

        if (sqlStatMap != null) {
            for (String sql : sqlStatMap.keySet()) {
                System.out.println(">>> 监控捕捉到的 SQL 模板: " + sql);
            }
        }

        // 应该有 3 个模板（INSERT, UPDATE, DELETE）
        assertEquals("🔴 失败：应该有 3 个 SQL 模板", 3, sqlStatMap.size());
    }

    /**
     * 场景验证：测试不相似的 SQL 不会被错误合并
     */
    @Test
    public void shouldNotMergeDissimilarSql() throws SQLException {
        System.out.println(">>> 开始验证不相似 SQL 不被错误合并...");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 执行两条结构不同的 SQL（都使用 users 表但查询结构不同）
            stmt.executeQuery("SELECT name FROM users WHERE id = 101");
            stmt.executeQuery("SELECT COUNT(*) FROM users WHERE age > 25");
        }

        java.util.Map<String, ?> sqlStatMap = dataSource.getDataSourceStat().getSqlStatMap();
        
        System.out.println(">>> 监控记录中的 SQL 模板总数: " + (sqlStatMap == null ? 0 : sqlStatMap.size()));

        if (sqlStatMap != null) {
            for (String sql : sqlStatMap.keySet()) {
                System.out.println(">>> 监控捕捉到的 SQL 模板: " + sql);
            }
        }

        // 应该有 2 个模板，因为 SQL 结构不同
        assertEquals("🔴 失败：应该有 2 个 SQL 模板", 2, sqlStatMap.size());
    }
}