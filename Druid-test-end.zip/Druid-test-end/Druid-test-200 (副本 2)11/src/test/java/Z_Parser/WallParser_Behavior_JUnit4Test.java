package Z_Parser;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.*;

public class WallParser_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }
        // 调用工厂方法
        dataSource = WallParser_Test.createDataSource(props);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    /**
     * 行为验证：验证 WallFilter + Kingbase 解析器能否成功拦截 SQL 注入
     */
    @Test
    public void shouldBlockSqlInjectionWhenWallEnabled() throws SQLException {
        System.out.println(">>> 开始验证 Kingbase 防火墙解析拦截行为...");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 1. 构造一个恶意的注入语句（经典 OR 1=1）
            String maliciousSql = "SELECT * FROM users WHERE id = 1 OR 1=1";

            try {
                System.out.println(">>> 尝试执行注入 SQL: " + maliciousSql);
                stmt.executeQuery(maliciousSql);

                // 如果跑到这一行，说明拦截失败了
                fail("🔴 错误：WallFilter 未能拦截针对 Kingbase 的注入攻击！");
            } catch (SQLException e) {
                // 2. 捕获异常，验证是否是由于防火墙拦截引起的
                String errorMessage = e.getMessage().toLowerCase();
                System.out.println(">>> 成功捕获异常: " + e.getMessage());

                // 断言：异常信息中应包含 wall 或 violation（违反规则）关键字
                boolean isBlockedByWall = errorMessage.contains("wall") ||
                        errorMessage.contains("violation") ||
                        errorMessage.contains("拦截");

                assertTrue("拦截异常信息不匹配，实际信息: " + e.getMessage(), isBlockedByWall);
            }
        }
        System.out.println("✅ [验证通过]：Kingbase 解析器成功配合 WallFilter 拦截了注入。");
    }

    /**
     * 行为验证：确保合法的 Kingbase 语法不被误杀
     */
    @Test
    public void shouldAllowNormalKingbaseSql() throws SQLException {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 执行一个普通的 Kingbase 查询
            boolean result = stmt.execute("SELECT 1");
            assertTrue("合法的 SELECT 1 应该被允许执行", result);
        }
    }
}
