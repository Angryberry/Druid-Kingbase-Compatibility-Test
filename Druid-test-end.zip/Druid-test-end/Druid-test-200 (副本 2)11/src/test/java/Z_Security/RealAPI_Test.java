package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executors;

import static org.junit.Assert.*;

/**
 * 真实的RESTful API集成测试
 * 通过Maven一键测试，自动启动和停止API服务器
 */
public class RealAPI_Test {

    private static final String BASE_URL = "http://localhost:8081/api";
    private HttpServer apiServer;
    private DruidDataSource dataSource;
    
    @Before
    public void setUp() throws Exception {
        System.out.println("🌐 启动API集成测试环境...");
        
        // 初始化数据库连接
        initDataSource();
        prepareDatabase();
        
        // 启动内嵌API服务器
        startAPIServer();
        
        // 等待服务器启动
        Thread.sleep(500);
        
        System.out.println("✅ API服务器启动完成，端口: 8081");
    }
    
    @After
    public void tearDown() {
        System.out.println("🧹 清理API测试环境...");
        
        if (apiServer != null) {
            apiServer.stop(0);
        }
        if (dataSource != null) {
            dataSource.close();
        }
        
        System.out.println("✅ 资源清理完成");
    }
    
    // ========== API服务器初始化 ==========
    
    private void initDataSource() throws Exception {
        Properties props = new Properties();
        props.setProperty("db.url", "jdbc:kingbase8://127.0.0.1:54321/test");
        props.setProperty("db.driverClassName", "com.kingbase8.Driver");
        props.setProperty("db.username", "druid");
        props.setProperty("db.password", "druid123");
        
        dataSource = new DruidDataSource();
        dataSource.setUrl(props.getProperty("db.url"));
        dataSource.setDriverClassName(props.getProperty("db.driverClassName"));
        dataSource.setUsername(props.getProperty("db.username"));
        dataSource.setPassword(props.getProperty("db.password"));
        dataSource.setValidationQuery("SELECT 1");
        dataSource.setTestWhileIdle(true);
        dataSource.init();
    }
    
    private void prepareDatabase() throws SQLException {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // 创建表
            stmt.execute("DROP TABLE IF EXISTS users");
            stmt.execute("CREATE TABLE users (" +
                        "id SERIAL PRIMARY KEY, " +
                        "name VARCHAR(50) NOT NULL, " +
                        "age INTEGER, " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            
            // 插入测试数据
            stmt.execute("INSERT INTO users (name, age) VALUES " +
                        "('Alice', 25), " +
                        "('Bob', 30), " +
                        "('Charlie', 35)");
        }
    }
    
    private void startAPIServer() throws IOException {
        // 创建HTTP服务器
        apiServer = HttpServer.create(new InetSocketAddress(8081), 0);
        apiServer.setExecutor(Executors.newCachedThreadPool());
        
        // 注册API端点
        apiServer.createContext("/api/users", new UsersHandler());
        apiServer.createContext("/api/users/", new UserHandler());
        
        apiServer.start();
    }
    
    // ========== API处理器 ==========
    
    /**
     * 用户列表处理器 - GET /api/users, POST /api/users
     */
    private class UsersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                // 处理CORS预检请求
                if ("OPTIONS".equals(exchange.getRequestMethod())) {
                    sendResponse(exchange, 200, "application/json", "");
                    return;
                }
                
                if ("GET".equals(exchange.getRequestMethod())) {
                    String response = getAllUsers();
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("POST".equals(exchange.getRequestMethod())) {
                    String requestBody = readRequestBody(exchange);
                    String response = createUser(requestBody);
                    sendResponse(exchange, 201, "application/json", response);
                } else {
                    sendResponse(exchange, 405, "application/json", 
                        "{\"error\":\"Method not allowed\"}");
                }
            } catch (Exception e) {
                System.err.println("UsersHandler error: " + e.getMessage());
                e.printStackTrace();
                sendResponse(exchange, 500, "application/json", 
                    "{\"error\":\"Internal server error: " + e.getMessage() + "\"}");
            }
        }
    }
    
    /**
     * 单个用户处理器 - GET/PUT/DELETE /api/users/{id}
     */
    private class UserHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                // 处理CORS预检请求
                if ("OPTIONS".equals(exchange.getRequestMethod())) {
                    sendResponse(exchange, 200, "application/json", "");
                    return;
                }
                
                String path = exchange.getRequestURI().getPath();
                String userId = path.substring(path.lastIndexOf('/') + 1);
                
                if ("GET".equals(exchange.getRequestMethod())) {
                    String response = getUser(userId);
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("PUT".equals(exchange.getRequestMethod())) {
                    String requestBody = readRequestBody(exchange);
                    String response = updateUser(userId, requestBody);
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("DELETE".equals(exchange.getRequestMethod())) {
                    String response = deleteUser(userId);
                    sendResponse(exchange, 204, "application/json", response);
                } else {
                    sendResponse(exchange, 405, "application/json", 
                        "{\"error\":\"Method not allowed\"}");
                }
            } catch (Exception e) {
                System.err.println("UserHandler error: " + e.getMessage());
                e.printStackTrace();
                sendResponse(exchange, 500, "application/json", 
                    "{\"error\":\"Internal server error: " + e.getMessage() + "\"}");
            }
        }
    }
    
    // ========== API业务方法 ==========
    
    private String getAllUsers() throws SQLException {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, name, age FROM users ORDER BY id")) {
            
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            
            while (rs.next()) {
                if (!first) json.append(",");
                json.append(String.format(
                    "{\"id\":%d,\"name\":\"%s\",\"age\":%d}",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age")
                ));
                first = false;
            }
            
            json.append("]");
            return json.toString();
        }
    }
    
    private String createUser(String requestBody) throws SQLException {
        String name = extractJsonValue(requestBody, "name");
        int age = Integer.parseInt(extractJsonValue(requestBody, "age"));
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO users (name, age) VALUES (?, ?) RETURNING id")) {
            
            stmt.setString(1, name);
            stmt.setInt(2, age);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int newId = rs.getInt(1);
                    return String.format(
                        "{\"id\":%d,\"name\":\"%s\",\"age\":%d,\"message\":\"User created\"}",
                        newId, name, age
                    );
                }
            }
        }
        
        return "{\"error\":\"Failed to create user\"}";
    }
    
    private String getUser(String userId) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT id, name, age FROM users WHERE id = ?")) {
            
            stmt.setInt(1, Integer.parseInt(userId));
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return String.format(
                        "{\"id\":%d,\"name\":\"%s\",\"age\":%d}",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age")
                    );
                } else {
                    return "{\"error\":\"User not found\"}";
                }
            }
        }
    }
    
    private String updateUser(String userId, String requestBody) throws SQLException {
        String name = extractJsonValue(requestBody, "name");
        int age = Integer.parseInt(extractJsonValue(requestBody, "age"));
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "UPDATE users SET name = ?, age = ? WHERE id = ?")) {
            
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setInt(3, Integer.parseInt(userId));
            
            int affected = stmt.executeUpdate();
            if (affected > 0) {
                return String.format(
                    "{\"id\":%s,\"name\":\"%s\",\"age\":%d,\"message\":\"User updated\"}",
                    userId, name, age
                );
            } else {
                return "{\"error\":\"User not found\"}";
            }
        }
    }
    
    private String deleteUser(String userId) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "DELETE FROM users WHERE id = ?")) {
            
            stmt.setInt(1, Integer.parseInt(userId));
            int affected = stmt.executeUpdate();
            
            if (affected > 0) {
                return ""; // DELETE 204 No Content
            } else {
                return "{\"error\":\"User not found\"}";
            }
        }
    }
    
    // ========== 辅助方法 ==========
    
    private String readRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getRequestBody()))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            return body.toString();
        }
    }
    
    private String extractJsonValue(String json, String key) {
        try {
            String pattern = "\"" + key + "\":\"";
            int start = json.indexOf(pattern);
            if (start == -1) {
                // 尝试数字格式
                pattern = "\"" + key + "\":";
                start = json.indexOf(pattern);
                if (start == -1) return "";
                start += pattern.length();
                
                // 找到数字的结束位置
                int end = start;
                while (end < json.length() && 
                       (Character.isDigit(json.charAt(end)) || json.charAt(end) == '-')) {
                    end++;
                }
                return json.substring(start, end);
            }
            
            start += pattern.length();
            int end = json.indexOf("\"", start);
            if (end == -1) return "";
            
            return json.substring(start, end);
        } catch (Exception e) {
            return "";
        }
    }
    
    private void sendResponse(HttpExchange exchange, int statusCode, 
                              String contentType, String response) throws IOException {
        
        // 设置响应头
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        // 发送响应
        byte[] responseBytes = response.getBytes("UTF-8");
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }
    
    /**
     * 场景 1：GET /api/users - 获取用户列表
     */
    @Test
    public void testGetUsersList() throws Exception {
        System.out.println("🚩 [测试] GET /api/users - 获取用户列表...");
        
        HttpResponse response = sendHttpRequest("GET", BASE_URL + "/users", null, null);
        
        // 验证状态码
        assertEquals("应该返回200", 200, response.statusCode);
        
        // 验证响应体
        assertNotNull("响应体不应为空", response.body);
        assertTrue("应该是有效的JSON数组", response.body.startsWith("[") && response.body.endsWith("]"));
        assertTrue("应该包含用户数据", response.body.contains("Alice") || response.body.contains("Bob"));
        
        System.out.println("✅ GET用户列表测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   响应长度: " + response.body.length() + " 字符");
        System.out.println("   响应内容: " + response.body.substring(0, Math.min(100, response.body.length())) + "...");
        
        // 打印所有响应头用于调试
        System.out.println("   响应头: " + response.headers);
    }
    
    /**
     * 场景 2：POST /api/users - 创建新用户
     */
    @Test
    public void testCreateUser() throws Exception {
        System.out.println("🚩 [测试] POST /api/users - 创建新用户...");
        
        String requestBody = "{\"name\":\"David\",\"age\":28}";
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        
        HttpResponse response = sendHttpRequest("POST", BASE_URL + "/users", requestBody, headers);
        
        // 验证状态码
        assertEquals("创建应该返回201", 201, response.statusCode);
        
        // 验证响应体
        assertNotNull("响应体不应为空", response.body);
        assertTrue("应该包含新用户ID", response.body.contains("\"id\""));
        assertTrue("应该包含用户名", response.body.contains("David"));
        assertTrue("应该包含年龄", response.body.contains("\"age\":28"));
        assertTrue("应该包含成功消息", response.body.contains("User created"));
        
        System.out.println("✅ 创建用户测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   新用户信息: " + response.body);
    }
    
    /**
     * 场景 3：GET /api/users/{id} - 获取特定用户
     */
    @Test
    public void testGetUserById() throws Exception {
        System.out.println("🚩 [测试] GET /api/users/{id} - 获取特定用户...");
        
        HttpResponse response = sendHttpRequest("GET", BASE_URL + "/users/1", null, null);
        
        // 验证状态码
        assertEquals("应该返回200", 200, response.statusCode);
        
        // 验证响应体
        assertNotNull("响应体不应为空", response.body);
        assertTrue("应该包含用户ID", response.body.contains("\"id\":1"));
        assertTrue("应该包含用户名", response.body.contains("\"name\""));
        assertTrue("应该包含年龄", response.body.contains("\"age\""));
        
        System.out.println("✅ 获取特定用户测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   用户信息: " + response.body);
    }
    
    /**
     * 场景 4：PUT /api/users/{id} - 更新用户
     */
    @Test
    public void testUpdateUser() throws Exception {
        System.out.println("🚩 [测试] PUT /api/users/{id} - 更新用户...");
        
        String requestBody = "{\"name\":\"Alice Updated\",\"age\":26}";
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        
        HttpResponse response = sendHttpRequest("PUT", BASE_URL + "/users/1", requestBody, headers);
        
        // 验证状态码
        assertEquals("更新应该返回200", 200, response.statusCode);
        
        // 验证响应体
        assertNotNull("响应体不应为空", response.body);
        assertTrue("应该包含更新后的用户名", response.body.contains("Alice Updated"));
        assertTrue("应该包含更新后的年龄", response.body.contains("\"age\":26"));
        assertTrue("应该包含成功消息", response.body.contains("User updated"));
        
        System.out.println("✅ 更新用户测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   更新结果: " + response.body);
    }
    
    /**
     * 场景 5：DELETE /api/users/{id} - 删除用户
     */
    @Test
    public void testDeleteUser() throws Exception {
        System.out.println("🚩 [测试] DELETE /api/users/{id} - 删除用户...");
        
        HttpResponse response = sendHttpRequest("DELETE", BASE_URL + "/users/3", null, null);
        
        // 验证状态码
        assertEquals("删除应该返回204", 204, response.statusCode);
        
        // 验证响应体（DELETE通常返回空）
        assertTrue("DELETE响应体应该为空", response.body == null || response.body.isEmpty());
        
        // 验证用户确实被删除
        HttpResponse verifyResponse = sendHttpRequest("GET", BASE_URL + "/users/3", null, null);
        assertEquals("用户应该不存在", 200, verifyResponse.statusCode);
        assertTrue("应该返回用户不存在错误", verifyResponse.body.contains("User not found"));
        
        System.out.println("✅ 删除用户测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   删除验证: " + verifyResponse.body);
    }
    
    /**
     * 场景 6：错误处理 - 获取不存在的用户
     */
    @Test
    public void testGetNonExistentUser() throws Exception {
        System.out.println("🚩 [测试] 错误处理 - 获取不存在的用户...");
        
        HttpResponse response = sendHttpRequest("GET", BASE_URL + "/users/999", null, null);
        
        // 验证状态码
        assertEquals("应该返回200", 200, response.statusCode);
        
        // 验证错误响应
        assertNotNull("响应体不应为空", response.body);
        assertTrue("应该包含错误信息", response.body.contains("User not found"));
        
        System.out.println("✅ 错误处理测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   错误信息: " + response.body);
    }
    
    /**
     * 场景 7：参数验证 - 创建无效用户
     */
    @Test
    public void testCreateInvalidUser() throws Exception {
        System.out.println("🚩 [测试] 参数验证 - 创建无效用户...");
        
        // 测试空名称
        String invalidBody = "{\"name\":\"\",\"age\":25}";
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        
        HttpResponse response = sendHttpRequest("POST", BASE_URL + "/users", invalidBody, headers);
        
        // 验证应该返回错误
        assertTrue("应该返回错误状态", response.statusCode >= 400 || response.statusCode == 500);
        
        System.out.println("✅ 参数验证测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   错误响应: " + response.body);
    }
    
    /**
     * 场景 8：性能测试 - 多次请求
     */
    @Test
    public void testPerformance() throws Exception {
        System.out.println("🚩 [测试] 性能测试 - 多次请求...");
        
        long totalTime = 0;
        int iterations = 10;
        
        for (int i = 0; i < iterations; i++) {
            long startTime = System.currentTimeMillis();
            HttpResponse response = sendHttpRequest("GET", BASE_URL + "/users", null, null);
            long endTime = System.currentTimeMillis();
            
            assertEquals("每次请求都应该成功", 200, response.statusCode);
            totalTime += (endTime - startTime);
        }
        
        long averageTime = totalTime / iterations;
        
        // 验证平均响应时间不超过1秒
        assertTrue("平均响应时间应该小于1000ms", averageTime < 1000);
        
        System.out.println("✅ 性能测试通过");
        System.out.println("   平均响应时间: " + averageTime + "ms");
        System.out.println("   总请求数: " + iterations);
    }
    
    /**
     * 场景 9：CORS测试 - 跨域请求
     */
    @Test
    public void testCORS() throws Exception {
        System.out.println("🚩 [测试] CORS - 跨域请求...");
        
        HttpResponse response = sendHttpRequest("GET", BASE_URL + "/users", null, null);
        
        // 验证基本响应正常
        assertEquals("请求应该成功", 200, response.statusCode);
        assertNotNull("响应体应该存在", response.body);
        
        // 打印CORS相关信息
        System.out.println("✅ CORS测试通过");
        System.out.println("   状态码: " + response.statusCode);
        System.out.println("   所有响应头: " + response.headers);
        
        // 检查是否有CORS相关的头（可选）
        boolean hasCORS = response.headers.containsKey("Access-Control-Allow-Origin") ||
                         response.headers.containsKey("access-control-allow-origin");
        
        if (hasCORS) {
            System.out.println("   ✓ 检测到CORS头");
        } else {
            System.out.println("   ⚠️  未检测到CORS头（可能不支持跨域）");
        }
    }
    
    // ========== HTTP请求辅助方法 ==========
    
    private HttpResponse sendHttpRequest(String method, String urlString, String body, Map<String, String> headers) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        
        // 设置请求头
        if (headers != null) {
            for (Map.Entry<String, String> header : headers.entrySet()) {
                connection.setRequestProperty(header.getKey(), header.getValue());
            }
        }
        
        // 设置请求体
        if (body != null && !body.isEmpty() && !("GET".equals(method) || "DELETE".equals(method))) {
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = connection.getOutputStream()) {
                os.write(body.getBytes("UTF-8"));
            }
        }
        
        // 获取响应
        int statusCode = connection.getResponseCode();
        StringBuilder responseBody = new StringBuilder();
        
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                responseBody.append(line);
            }
        }
        
        // 获取响应头
        Map<String, String> responseHeaders = new HashMap<>();
        for (Map.Entry<String, java.util.List<String>> header : connection.getHeaderFields().entrySet()) {
            if (header.getKey() != null && !header.getValue().isEmpty()) {
                responseHeaders.put(header.getKey(), header.getValue().get(0));
            }
        }
        
        return new HttpResponse(statusCode, responseBody.toString(), responseHeaders);
    }
    
    /**
     * HTTP响应封装类
     */
    private static class HttpResponse {
        int statusCode;
        String body;
        Map<String, String> headers;
        
        HttpResponse(int statusCode, String body, Map<String, String> headers) {
            this.statusCode = statusCode;
            this.body = body;
            this.headers = headers;
        }
    }
}
