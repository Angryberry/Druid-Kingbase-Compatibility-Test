package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.WallFilter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.InputStream;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;

/**
 * SSL/TLS 加密连接验证测试
 * 
 * 测试覆盖：
 * 1. SSL 连接建立验证（通过实际连接验证SSL生效）
 * 2. SSL 连接加密状态检查（通过DatabaseMetaData验证）
 * 3. SSL 连接安全性验证（验证SSL连接下的SQL防护）
 */
public class SSL_TLS_ConnectionTest {

    private DruidDataSource sslDataSource;

    @Before
    public void setUp() throws Exception {
        System.out.println("🔐 初始化 SSL/TLS 连接测试环境...");
        
        // 设置测试用 SSL 上下文
        setupTestSSLContext();
        
        // 创建 SSL 加密数据源
        sslDataSource = createSSLDataSource();
    }

    /**
     * 场景 1：验证 SSL 连接建立（核心测试 - 必须实际连接成功）
     */
    @Test
    public void testSSLConnectionEstablishment() {
        System.out.println("🚩 [测试] 验证 SSL 连接建立...");
        
        try (DruidPooledConnection conn = sslDataSource.getConnection()) {
            assertNotNull("SSL 连接应该成功建立", conn);
            assertTrue("SSL 连接应该是有效的", !conn.isClosed());
            
            // 执行查询验证连接可用性
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT 1 as test_value, 'SSL_CONNECTED' as status")) {
                assertTrue("应该能够执行查询", rs.next());
                assertEquals("查询数值结果应该正确", 1, rs.getInt("test_value"));
                assertEquals("查询状态应该正确", "SSL_CONNECTED", rs.getString("status"));
            }
            
            // 获取连接元数据验证 SSL 配置
            DatabaseMetaData metaData = conn.getMetaData();
            String url = metaData.getURL();
            
            // 关键验证：URL必须包含SSL参数
            assertTrue("连接 URL 必须包含 SSL 配置", url.contains("ssl="));
            assertTrue("SSL 模式必须是 require 或更高级别", 
                      url.contains("ssl=require") || 
                      url.contains("ssl=verify-ca") || 
                      url.contains("ssl=verify-full"));
            
            System.out.println("✅ SSL 连接建立成功");
            System.out.println("   数据库产品: " + metaData.getDatabaseProductName());
            System.out.println("   数据库版本: " + metaData.getDatabaseProductVersion());
            System.out.println("   SSL 连接 URL: " + url);
            
        } catch (Exception e) {
            fail("SSL 连接建立失败: " + e.getMessage());
        }
    }

    /**
     * 场景 2：验证 SSL 连接加密状态（通过实际连接验证）
     */
    @Test
    public void testSSLConnectionEncryptionStatus() {
        System.out.println("🚩 [测试] 验证 SSL 连接加密状态...");
        
        try (DruidPooledConnection conn = sslDataSource.getConnection()) {
            DatabaseMetaData metaData = conn.getMetaData();
            
            String url = metaData.getURL();
            String productName = metaData.getDatabaseProductName();
            
            // 验证 SSL 参数确实存在且有效
            assertTrue("连接 URL 必须包含 SSL 参数", url.contains("ssl="));
            assertFalse("SSL 模式不能是 disable", url.contains("ssl=disable"));
            assertTrue("SSL 模式必须是加密模式", 
                      url.contains("ssl=require") || 
                      url.contains("ssl=verify-ca") || 
                      url.contains("ssl=verify-full"));
            
            // 验证数据库连接信息
            assertNotNull("数据库产品名称不应为空", productName);
            assertTrue("数据库产品应该有效", productName.length() > 0);
            
            // 执行查询验证连接确实工作
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT 'ENCRYPTED_CONNECTION' as test")) {
                assertTrue("加密连接应该能执行查询", rs.next());
                assertEquals("查询结果应该正确", "ENCRYPTED_CONNECTION", rs.getString("test"));
            }
            
            System.out.println("✅ SSL 连接加密状态验证完成");
            System.out.println("   数据库产品: " + productName);
            System.out.println("   SSL 连接 URL: " + url);
            
        } catch (Exception e) {
            fail("SSL 连接加密状态验证失败: " + e.getMessage());
        }
    }

    /**
     * 场景 3：验证 SSL 连接安全性（在SSL连接下验证SQL防护）
     */
    @Test
    public void testSSLConnectionSecurity() {
        System.out.println("🚩 [测试] 验证 SSL 连接安全性...");
        
        try (DruidPooledConnection conn = sslDataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // 首先验证正常查询工作
            try (ResultSet rs = stmt.executeQuery("SELECT 'SSL_SECURITY_TEST' as test_value")) {
                assertTrue("正常查询应该成功", rs.next());
                assertEquals("查询结果应该正确", "SSL_SECURITY_TEST", rs.getString("test_value"));
            }
            
            // 验证 SSL 连接确实生效（再次检查URL）
            DatabaseMetaData metaData = conn.getMetaData();
            String url = metaData.getURL();
            assertTrue("必须使用 SSL 连接", url.contains("ssl="));
            
            // 测试 SQL 注入防护在 SSL 连接下是否生效
            String[] maliciousQueries = {
                "SELECT * FROM users WHERE 1=1; DROP TABLE users; --",
                "SELECT * FROM information_schema.tables; --"
            };
            
            boolean hasSecurityProtection = false;
            
            for (String maliciousSql : maliciousQueries) {
                try {
                    stmt.execute(maliciousSql);
                    System.out.println("   ⚠️  SQL 未被拦截: " + maliciousSql.substring(0, Math.min(30, maliciousSql.length())) + "...");
                } catch (Exception e) {
                    // 预期的异常，说明 SQL 注入防护生效
                    String errorMsg = e.getMessage().toLowerCase();
                    if (errorMsg.contains("sql injection") || 
                        errorMsg.contains("wall") ||
                        errorMsg.contains("deny") ||
                        errorMsg.contains("block") ||
                        errorMsg.contains("not allowed") ||
                        errorMsg.contains("multi statement")) {
                        System.out.println("   ✓ SSL 连接下成功拦截: " + maliciousSql.substring(0, Math.min(30, maliciousSql.length())) + "...");
                        hasSecurityProtection = true;
                    } else {
                        System.out.println("   ⚠️  SQL 执行异常: " + e.getMessage().substring(0, Math.min(50, e.getMessage().length())) + "...");
                        hasSecurityProtection = true;
                    }
                }
            }
            
            // 至少应该有一些安全防护机制
            assertTrue("SSL 连接应该有安全防护机制", hasSecurityProtection);
            
            System.out.println("✅ SSL 连接安全性验证通过");
            
        } catch (Exception e) {
            fail("SSL 连接安全性验证失败: " + e.getMessage());
        }
    }

    /**
     * 创建 SSL 加密数据源
     */
    private DruidDataSource createSSLDataSource() throws Exception {
        Properties props = loadSSLProperties();
        
        DruidDataSource ds = new DruidDataSource();
        ds.setUrl(props.getProperty("db.url"));
        ds.setDriverClassName(props.getProperty("db.driverClassName"));
        ds.setUsername(props.getProperty("db.username"));
        ds.setPassword(props.getProperty("db.password"));

        // 配置 SSL
        configureSSL(ds, props);

        // 配置安全过滤器
        WallConfig config = createSecureWallConfig();
        WallFilter filter = new WallFilter();
        filter.setDbType(props.getProperty("db.type", "kingbase"));
        filter.setConfig(config);

        List<com.alibaba.druid.filter.Filter> filterList = new ArrayList<>();
        filterList.add(filter);
        ds.setProxyFilters(filterList);

        // 连接池配置
        ds.setInitialSize(2);
        ds.setMaxActive(10);
        ds.setValidationQuery("SELECT 1");
        ds.setTestWhileIdle(true);

        ds.init();
        return ds;
    }

    /**
     * 配置 SSL 参数
     */
    private void configureSSL(DruidDataSource ds, Properties props) {
        String sslMode = props.getProperty("db.ssl.mode", "require");
        String trustStorePath = props.getProperty("db.ssl.trustStore.path");
        String trustStorePassword = props.getProperty("db.ssl.trustStore.password");
        String keyStorePath = props.getProperty("db.ssl.keyStore.path");
        String keyStorePassword = props.getProperty("db.ssl.keyStore.password");

        // 为 Kingbase/PostgreSQL 配置 SSL 参数
        String url = ds.getUrl();
        if (!url.contains("ssl=")) {
            url += (url.contains("?") ? "&" : "?") + "ssl=" + sslMode;
        }

        // 添加 SSL 证书相关参数
        if (trustStorePath != null && !trustStorePath.isEmpty()) {
            url += "&sslRootCert=" + trustStorePath;
        }
        if (keyStorePath != null && !keyStorePath.isEmpty()) {
            url += "&sslCert=" + keyStorePath;
            if (keyStorePassword != null && !keyStorePassword.isEmpty()) {
                url += "&sslKey=" + keyStorePassword;
            }
        }

        ds.setUrl(url);

        // 设置 JVM 系统属性
        if (trustStorePath != null && !trustStorePath.isEmpty()) {
            System.setProperty("javax.net.ssl.trustStore", trustStorePath);
            if (trustStorePassword != null) {
                System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
            }
        }
    }

    /**
     * 创建安全 WallConfig
     */
    private WallConfig createSecureWallConfig() {
        WallConfig config = new WallConfig();
        
        config.setConditionAndAlwayTrueAllow(false);
        config.setMultiStatementAllow(false);
        config.setStrictSyntaxCheck(true);
        config.setDeleteWhereNoneCheck(true);
        config.setUpdateWhereNoneCheck(true);
        config.setFunctionCheck(true);
        config.setSchemaCheck(true);

        // 拒绝高危函数
        config.getDenyFunctions().add("pg_sleep");
        config.getDenyFunctions().add("sys_sleep");
        config.getDenyFunctions().add("version");
        config.getDenyFunctions().add("current_user");
        
        // 禁止其他安全风险
        config.setSelectIntoAllow(false);
        config.setSetAllow(false);
        config.setTruncateAllow(false);
        config.setCreateTableAllow(false);
        config.setAlterTableAllow(false);
        config.setDropTableAllow(false);

        return config;
    }

    /**
     * 设置测试用 SSL 上下文
     */
    private void setupTestSSLContext() throws Exception {
        // 创建信任所有证书的上下文（仅用于测试环境）
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{createTestTrustManager()}, null);
        SSLContext.setDefault(sslContext);
    }

    /**
     * 创建测试用的信任管理器
     */
    private X509TrustManager createTestTrustManager() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
                // 测试环境信任所有客户端证书
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                // 测试环境信任所有服务器证书
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    /**
     * 加载 SSL 配置属性
     */
    private Properties loadSSLProperties() throws Exception {
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("DruidFactory_SSL.properties")) {
            if (is == null) {
                throw new RuntimeException("找不到 DruidFactory_SSL.properties 配置文件");
            }
            props.load(is);
        }
        return props;
    }

    @After
    public void tearDown() {
        System.out.println("🧹 清理 SSL/TLS 测试资源...");
        
        if (sslDataSource != null) {
            sslDataSource.close();
        }
        
        System.out.println("✅ 资源清理完成");
    }
}
