package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executors;

/**
 * 真实的REST API测试服务器
 * 提供简单的用户管理API接口
 */
public class RealAPITestServer {
    
    private HttpServer server;
    private DruidDataSource dataSource;
    private int port = 8080;
    
    public static void main(String[] args) throws Exception {
        RealAPITestServer apiServer = new RealAPITestServer();
        apiServer.start();
        System.out.println("🌐 API服务器已启动，访问 http://localhost:" + apiServer.port);
        System.out.println("按 Ctrl+C 停止服务器");
        
        // 保持服务器运行
        Thread.sleep(Long.MAX_VALUE);
    }
    
    public void start() throws Exception {
        // 初始化数据库连接
        initDataSource();
        prepareDatabase();
        
        // 创建HTTP服务器
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newCachedThreadPool());
        
        // 注册API端点
        server.createContext("/api/users", new UsersHandler());
        server.createContext("/api/users/", new UserHandler());
        
        server.start();
    }
    
    public void stop() {
        if (server != null) {
            server.stop(0);
        }
        if (dataSource != null) {
            dataSource.close();
        }
    }
    
    /**
     * 用户列表处理器 - GET /api/users
     */
    private class UsersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                if ("GET".equals(exchange.getRequestMethod())) {
                    // 查询所有用户
                    String response = getAllUsers();
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("POST".equals(exchange.getRequestMethod())) {
                    // 创建新用户
                    String requestBody = readRequestBody(exchange);
                    String response = createUser(requestBody);
                    sendResponse(exchange, 201, "application/json", response);
                } else {
                    sendResponse(exchange, 405, "application/json", 
                        "{\"error\":\"Method not allowed\"}");
                }
            } catch (Exception e) {
                sendResponse(exchange, 500, "application/json", 
                    "{\"error\":\"Internal server error: " + e.getMessage() + "\"}");
            }
        }
    }
    
    /**
     * 单个用户处理器 - GET/PUT/DELETE /api/users/{id}
     */
    private class UserHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                String path = exchange.getRequestURI().getPath();
                String userId = path.substring(path.lastIndexOf('/') + 1);
                
                if ("GET".equals(exchange.getRequestMethod())) {
                    String response = getUser(userId);
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("PUT".equals(exchange.getRequestMethod())) {
                    String requestBody = readRequestBody(exchange);
                    String response = updateUser(userId, requestBody);
                    sendResponse(exchange, 200, "application/json", response);
                } else if ("DELETE".equals(exchange.getRequestMethod())) {
                    String response = deleteUser(userId);
                    sendResponse(exchange, 204, "application/json", response);
                } else {
                    sendResponse(exchange, 405, "application/json", 
                        "{\"error\":\"Method not allowed\"}");
                }
            } catch (Exception e) {
                sendResponse(exchange, 500, "application/json", 
                    "{\"error\":\"Internal server error: " + e.getMessage() + "\"}");
            }
        }
    }
    
    // ========== API业务方法 ==========
    
    private String getAllUsers() throws SQLException {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, name, age FROM users ORDER BY id")) {
            
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            
            while (rs.next()) {
                if (!first) json.append(",");
                json.append(String.format(
                    "{\"id\":%d,\"name\":\"%s\",\"age\":%d}",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age")
                ));
                first = false;
            }
            
            json.append("]");
            return json.toString();
        }
    }
    
    private String createUser(String requestBody) throws SQLException {
        // 简单解析JSON请求体
        String name = extractJsonValue(requestBody, "name");
        int age = Integer.parseInt(extractJsonValue(requestBody, "age"));
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO users (name, age) VALUES (?, ?) RETURNING id")) {
            
            stmt.setString(1, name);
            stmt.setInt(2, age);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int newId = rs.getInt(1);
                    return String.format(
                        "{\"id\":%d,\"name\":\"%s\",\"age\":%d,\"message\":\"User created\"}",
                        newId, name, age
                    );
                }
            }
        }
        
        return "{\"error\":\"Failed to create user\"}";
    }
    
    private String getUser(String userId) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT id, name, age FROM users WHERE id = ?")) {
            
            stmt.setInt(1, Integer.parseInt(userId));
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return String.format(
                        "{\"id\":%d,\"name\":\"%s\",\"age\":%d}",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age")
                    );
                } else {
                    return "{\"error\":\"User not found\"}";
                }
            }
        }
    }
    
    private String updateUser(String userId, String requestBody) throws SQLException {
        String name = extractJsonValue(requestBody, "name");
        int age = Integer.parseInt(extractJsonValue(requestBody, "age"));
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "UPDATE users SET name = ?, age = ? WHERE id = ?")) {
            
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setInt(3, Integer.parseInt(userId));
            
            int affected = stmt.executeUpdate();
            if (affected > 0) {
                return String.format(
                    "{\"id\":%s,\"name\":\"%s\",\"age\":%d,\"message\":\"User updated\"}",
                    userId, name, age
                );
            } else {
                return "{\"error\":\"User not found\"}";
            }
        }
    }
    
    private String deleteUser(String userId) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "DELETE FROM users WHERE id = ?")) {
            
            stmt.setInt(1, Integer.parseInt(userId));
            int affected = stmt.executeUpdate();
            
            if (affected > 0) {
                return ""; // DELETE 204 No Content
            } else {
                return "{\"error\":\"User not found\"}";
            }
        }
    }
    
    // ========== 辅助方法 ==========
    
    private void initDataSource() throws Exception {
        Properties props = new Properties();
        props.setProperty("db.url", "jdbc:kingbase8://127.0.0.1:54321/test");
        props.setProperty("db.driverClassName", "com.kingbase8.Driver");
        props.setProperty("db.username", "druid");
        props.setProperty("db.password", "druid123");
        
        dataSource = new DruidDataSource();
        dataSource.setUrl(props.getProperty("db.url"));
        dataSource.setDriverClassName(props.getProperty("db.driverClassName"));
        dataSource.setUsername(props.getProperty("db.username"));
        dataSource.setPassword(props.getProperty("db.password"));
        dataSource.setValidationQuery("SELECT 1");
        dataSource.setTestWhileIdle(true);
        dataSource.init();
    }
    
    private void prepareDatabase() throws SQLException {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // 创建表
            stmt.execute("DROP TABLE IF EXISTS users");
            stmt.execute("CREATE TABLE users (" +
                        "id SERIAL PRIMARY KEY, " +
                        "name VARCHAR(50) NOT NULL, " +
                        "age INTEGER, " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            
            // 插入测试数据
            stmt.execute("INSERT INTO users (name, age) VALUES " +
                        "('Alice', 25), " +
                        "('Bob', 30), " +
                        "('Charlie', 35)");
        }
    }
    
    private String readRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getRequestBody()))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            return body.toString();
        }
    }
    
    private String extractJsonValue(String json, String key) {
        String pattern = "\"" + key + "\":\"";
        int start = json.indexOf(pattern);
        if (start == -1) return "";
        
        start += pattern.length();
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }
    
    private void sendResponse(HttpExchange exchange, int statusCode, 
                              String contentType, String response) throws IOException {
        
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(statusCode, response.getBytes().length);
        
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(response.getBytes());
        }
    }
}
