package QueryTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.*;

public class QueryTimeout_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    // 设定查询超时阈值：2 秒
    private static final int TEST_QUERY_TIMEOUT_SEC = 2;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }

        // 1. 修正：直接调用当前包下的工厂方法
        dataSource = QueryTimeout_Test.createDataSource(props);

        // 设置默认的查询超时时间
        dataSource.setQueryTimeout(TEST_QUERY_TIMEOUT_SEC);

        dataSource.setInitialSize(1);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    @Test
    public void shouldInterruptSlowQueryWhenExceedingTimeout() throws SQLException {
        System.out.println(">>> 开始验证 QueryTimeout 行为...");
        System.out.println(">>> 设定查询超时: " + TEST_QUERY_TIMEOUT_SEC + " 秒");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 执行耗时 5 秒的查询
            String slowSql = "SELECT pg_sleep(5)";

            long startTime = System.currentTimeMillis();
            try {
                System.out.println(">>> 正在执行耗时 SQL: " + slowSql + " ...");
                stmt.executeQuery(slowSql);

                fail("错误：SQL 执行超过了超时时间却没有报错！");
            } catch (SQLException e) {
                long duration = System.currentTimeMillis() - startTime;
                double durationSec = duration / 1000.0;

                System.out.println(">>> 捕获到异常，耗时: " + String.format("%.2f", durationSec) + " 秒");
                System.out.println(">>> 异常信息: " + e.getMessage());

                // --- 核心断言修正 ---

                // 1. 验证时间：耗时应该在 2s 附近
                assertTrue("超时生效太慢或未生效，耗时: " + durationSec, durationSec < 4.0);
                assertTrue("报错太快，可能不是超时引起: " + durationSec, durationSec >= 1.5);

                // 2. 修正：适配 Kingbase 中文环境，增加 "取消" 关键词判断
                String msg = e.getMessage().toLowerCase();
                assertTrue("异常信息应包含超时或取消提示: " + msg,
                        msg.contains("timeout") ||
                                msg.contains("cancel") ||
                                msg.contains("取消"));
            }
        }
        System.out.println(">>> [验证通过]：QueryTimeout 成功中断了慢查询。");
    }
}