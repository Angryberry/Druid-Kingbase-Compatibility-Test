package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class SecurityAuditTest {

    private SecurityAuditRunner_3 runner;

    @Before
    public void setUp() {
        runner = new SecurityAuditRunner_3();
    }

    @Test
    public void testSecurityAndLeakAudit() throws Exception {
        System.out.println("▶️ 开始金融安全场景自动化集成测试...");

        // 1. 启动
        runner.startProcess();
        DruidDataSource ds = runner.getDataSource();

        // 2. 断言 1：SQL 防火墙必须生效
        boolean isBlocked = runner.verifyWallFilter();
        assertTrue("金融级配置必须成功拦截无 WHERE 的删除操作", isBlocked);
        System.out.println("✅ 断言成功：WallFilter 防火墙防御正常。");

        // 3. 断言 2：泄露回收逻辑
        assertEquals("初始状态活跃连接应为 0", 0, ds.getActiveCount());

        runner.triggerConnectionLeak();
        assertEquals("泄露后活跃连接应为 1", 1, ds.getActiveCount());

        // 4. 【核心重构】动态计算等待时间，绝不写死 8000 毫秒！
        // 获取底层真正生效的超时时间 (Druid 内部存储单位是毫秒)
        long timeoutMillis = ds.getRemoveAbandonedTimeoutMillis();
        assertTrue("未配置 removeAbandonedTimeout，无法执行自动回收测试", timeoutMillis > 0);

        // 动态等待时间 = 配置的超时时间 + 3秒的缓冲时间（留给Druid后台定时线程去扫描）
        long waitTime = timeoutMillis + 3000;

        System.out.println("⏳ 根据动态配置 (回收超时设定为 " + (timeoutMillis / 1000) + "s)，程序将等待 " + (waitTime / 1000) + " 秒...");
        Thread.sleep(waitTime);

        // 5. 断言 3：连接是否被强制收回
        assertEquals("回收后活跃连接数应恢复为 0", 0, ds.getActiveCount());
        System.out.println("✅ 断言成功：Druid 已动态触发并自动处决泄露连接。");
    }

    @After
    public void tearDown() {
        if (runner != null) {
            runner.stopProcess();
        }
    }
}