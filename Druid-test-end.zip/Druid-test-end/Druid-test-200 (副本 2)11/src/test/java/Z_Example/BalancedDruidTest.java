package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import org.eclipse.jetty.server.Server;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import static org.junit.Assert.*;

public class BalancedDruidTest {

    private BalancedDruidRunner_1 runner;

    @Before
    public void setUp() {
        runner = new BalancedDruidRunner_1();
    }

    @Test
    public void testFullLifecycle() throws Exception {
        System.out.println("▶️ 开始自动化集成测试...");

        // 1. 执行启动流程
        runner.startProcess();

        DruidDataSource ds = runner.getDataSource();
        Server server = runner.getJettyServer();

        // 2. 断言：Druid 是否初始化成功
        assertNotNull("数据源不应为空", ds);
        assertTrue("数据源应处于初始化状态", ds.isInited());

        // 核心动态断言：实际池中连接数 == 数据源配置的 InitialSize (不再写死数字 10)
        int expectedInitialSize = ds.getInitialSize();
        assertEquals("初始连接数应符合动态配置", expectedInitialSize, ds.getPoolingCount());
        System.out.println("✅ 断言成功：连接池已预热 " + expectedInitialSize + " 条连接。");

        // 3. 断言：Jetty 监控是否启动
        assertTrue("Jetty服务器应在运行中", server.isRunning());
        // 动态打印主机和端口，不再写死 8080
        System.out.println("✅ 断言成功：监控服务器 IP [" + runner.getServerHost() + "] 端口 [" + runner.getServerPort() + "] 已开启。");

        // 4. 执行一次真实的 SQL 校验连接可用性
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT 1")) {
            assertTrue("应能查得结果", rs.next());
            assertEquals(1, rs.getInt(1));
            System.out.println("✅ 数据库通讯测试通过！");
        }
    }

    @After
    public void tearDown() throws Exception {
        if (runner != null) {
            runner.stopProcess();
        }
    }
}