package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HighPerfDruidTest {

    private HighPerfDruidRunner_2 runner;

    @Before
    public void setUp() {
        System.out.println("⏳ [环境隔离] 等待 1.5 秒，确保上一个测试用例占用的数据库连接彻底释放...");
        try {
            // 强行休眠 1.5 秒，给数据库喘息的时间，避免 max_connections 被瞬间打满
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        runner = new HighPerfDruidRunner_2();
    }

    @Test
    public void testHighPerfFlashSaleScenario() throws Exception {
        System.out.println("▶️ 开始高并发场景自动化集成测试...");

        // 1. 启动流程 (这里会自动去读 DruidFactory_2.properties)
        runner.startProcess();
        DruidDataSource ds = runner.getDataSource();

        // 2. 动态断言 1：验证预热配置 (去读数据源真正生效的 initialSize)
        assertNotNull("数据源不应为空", ds);
        int expectedInitialSize = ds.getInitialSize();
        assertEquals("秒杀场景下，实际预热连接数应与配置文件完全一致", expectedInitialSize, ds.getPoolingCount());
        System.out.println("✅ 断言成功：" + expectedInitialSize + " 条初始连接已全量预热。");

        // 3. 动态验证监控服务器启动状态 (去读 Runner 里解析好的 Host 和 Port)
        assertTrue("监控服务器应保持运行", runner.getJettyServer().isRunning());
        System.out.println("✅ 断言成功：监控服务器已在 [" + runner.getServerHost() + ":" + runner.getServerPort() + "] 启动。");

        // 4. 模拟瞬间 200 并发压力
        runner.simulateTraffic(100, 200);

        // 5. 动态断言 2：验证高并发后的状态
        int expectedMaxActive = ds.getMaxActive();
        assertTrue("最大连接数配置必须大于0且已生效", expectedMaxActive > 0);

        // 校验是否存在连接泄露
        assertEquals("高并发结束后，活跃连接数应归零，不应发生连接泄露", 0, ds.getActiveCount());
        System.out.println("✅ 断言成功：200 次秒杀请求处理完成，活跃连接已全部安全释放。");
    }

    @After
    public void tearDown() throws Exception {
        if (runner != null) {
            runner.stopProcess();
        }
    }
}