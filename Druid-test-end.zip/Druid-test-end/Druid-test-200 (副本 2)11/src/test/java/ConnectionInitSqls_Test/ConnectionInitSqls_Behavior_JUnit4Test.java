package ConnectionInitSqls_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.io.InputStream;

import static org.junit.Assert.*;

public class ConnectionInitSqls_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }
        // 使用工厂类创建，确保配置完整
        dataSource = ConnectionInitSqls_Test.createDataSource(props);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    /**
     * 行为验证：验证 ConnectionInitSqls 是否在底层生效
     */
    @Test
    public void shouldApplyInitSqlToNewConnections() throws Exception {
        System.out.println(">>> 开始验证 ConnectionInitSqls 行为...");

        // 1. 从池中获取连接
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // 2. 执行查询验证会话变量
            // 在 Kingbase8 中，SHOW application_name 会返回 SET 进去的值
            try (ResultSet rs = stmt.executeQuery("SHOW application_name")) {
                if (rs.next()) {
                    String actualName = rs.getString(1);
                    System.out.println("数据库返回的会话名称: " + actualName);

                    // --- 核心断言 ---
                    // 验证返回的值是否包含我们在 ConnectionInitSqls 中设置的常量
                    assertTrue("初始化 SQL 未能成功改变会话状态",
                            actualName.contains("Druid_Init_Tester"));
                } else {
                    fail("未能在数据库中查询到 application_name 变量");
                }
            }
        }
        System.out.println("【验证通过】：底层物理连接已成功执行初始化 SQL。");
    }

    /**
     * 静态属性验证：确保配置列表不为空
     */
    @Test
    public void verifyConfigIsPresent() {
        assertNotNull("配置列表不应为空", dataSource.getConnectionInitSqls());
        assertEquals("配置的 SQL 数量不匹配",
                ConnectionInitSqls_Test.INIT_SQLS.size(),
                dataSource.getConnectionInitSqls().size());
    }
}