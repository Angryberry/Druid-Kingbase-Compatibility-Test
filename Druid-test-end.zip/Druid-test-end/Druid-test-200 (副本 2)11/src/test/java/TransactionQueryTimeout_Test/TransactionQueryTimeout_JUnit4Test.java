package TransactionQueryTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.Assert.*;

public class TransactionQueryTimeout_JUnit4Test {

    private DruidDataSource dataSource;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            assertNotNull("druid.properties 未找到", in);
            props.load(in);
        }

        // 1. 调用工厂方法
        dataSource = TransactionQueryTimeoutTest.createDataSource(props);

        // 2. 行为验证核心配置：设置事务查询超时为 1 秒
        dataSource.setTransactionQueryTimeout(1);

        dataSource.setInitialSize(1);
        dataSource.setMaxActive(1);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    /**
     * 行为验证：验证当 SQL 执行超过 transactionQueryTimeout 时是否报错
     */
    @Test
    public void shouldTimeoutWhenQueryExceedsTransactionLimit() throws Exception {
        System.out.println(">>> 开始验证 TransactionQueryTimeout 行为...");

        try (Connection conn = dataSource.getConnection()) {
            // 必须开启事务，该参数在事务上下文中才生效
            conn.setAutoCommit(false);

            try (Statement stmt = conn.createStatement()) {
                System.out.println(">>> 执行耗时 3 秒的 SQL (预期 1 秒超时)...");

                // Kingbase 兼容 pg_sleep
                stmt.executeQuery("SELECT pg_sleep(3)");

                fail("失败：SQL 执行了 3 秒但未触发 TransactionQueryTimeout 拦截！");
            } catch (SQLException e) {
                String msg = e.getMessage().toLowerCase();
                System.out.println(">>> 捕获到预期超时异常: " + e.getMessage());

                // --- 核心断言修正：同时支持中英文超时/取消提示 ---
                assertTrue("异常信息应包含超时或取消提示: " + msg,
                        msg.contains("timeout") ||
                                msg.contains("cancel") ||
                                msg.contains("取消") ||
                                msg.contains("超时"));
            } finally {
                try { conn.rollback(); } catch (Exception ignored) {}
            }
        }
    }

    @Test
    public void shouldRunMainAndExecuteSql() throws Exception {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured));
        try {
            TransactionQueryTimeoutTest.main(new String[0]);
            String output = captured.toString();
            // 修正断言逻辑：主方法成功运行即可
            assertTrue("未检测到预期的 SQL 执行日志", output.contains("Executed SQL") || output.contains("❌"));
        } finally {
            System.setOut(originalOut);
        }
    }
}