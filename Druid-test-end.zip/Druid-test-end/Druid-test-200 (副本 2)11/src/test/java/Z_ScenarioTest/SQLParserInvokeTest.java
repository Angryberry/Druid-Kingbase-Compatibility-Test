package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class SQLParserInvokeTest {

    @Test
    public void verifySQLParserScenarios() {
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        try {
            // 🎯 使用 UTF-8 抓取，防止中文断言失败
            PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8");
            System.setOut(captureStream);
            System.setErr(captureStream);

            SQLParserDruidTest.main(new String[0]);

            System.setOut(originalOut);
            System.setErr(originalErr);

            String fullOutput = outputBuffer.toString("UTF-8");
            System.out.println("--- [Captured Output] ---");
            System.out.println(fullOutput);
            System.out.println("-------------------------");

            Assert.assertTrue("未检测到简报标题", fullOutput.contains("📊 SQL 解析专项测试简报"));

            // 🎯 核心断言：只要逻辑类修复了关键词匹配，这里就能稳稳拿到 100%
            Assert.assertTrue("SQL 解析验证未达到 100% 成功率！", fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] SQL 解析全场景验证通过！");

        } catch (Exception e) {
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("测试异常: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}