package Z_ScenarioTest;

import org.junit.Assert;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class SocketTimeoutInvokeTest {

    @Test
    public void verifySocketTimeoutScenarios() {
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();

        try {
            // 使用支持 UTF-8 的包装，防止乱码导致断言失败
            PrintStream captureStream = new PrintStream(outputBuffer, true, "UTF-8");
            System.setOut(captureStream);
            System.setErr(captureStream);

            // 执行主逻辑
            SocketTimeoutDruidTest.main(new String[0]);

            // 还原流
            System.setOut(originalOut);
            System.setErr(originalErr);

            String fullOutput = outputBuffer.toString("UTF-8");

            // 回显到控制台供审计
            System.out.println("--- [Captured Test Output] ---");
            System.out.println(fullOutput);
            System.out.println("------------------------------");

            // 核心断言
            Assert.assertTrue("报告未生成，测试可能中途崩溃", fullOutput.contains("📊 Socket-Timeout 专项回归报告"));
            Assert.assertTrue("成功率未达 100%，请检查逻辑类中的异常匹配规则", fullOutput.contains("成功率:   100%"));

            System.out.println("🎉 [JUnit] Socket-Timeout 集成验证全量通过！");

        } catch (Exception e) {
            System.setOut(originalOut);
            System.setErr(originalErr);
            e.printStackTrace();
            Assert.fail("集成测试执行中发生非预期错误: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}