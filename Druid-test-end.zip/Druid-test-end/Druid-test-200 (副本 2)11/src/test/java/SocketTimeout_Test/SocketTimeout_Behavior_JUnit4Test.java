package SocketTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.*;

import static org.junit.Assert.*;

public class SocketTimeout_Behavior_JUnit4Test {

    private DruidDataSource dataSource;

    private static final String BLACK_HOLE_URL = "jdbc:kingbase8://192.0.2.1:54321/test";

    @Before
    public void setUp() throws Exception {
        dataSource = new DruidDataSource();

        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) props.load(in);
        }

        dataSource.setDriverClassName(props.getProperty("driverClassName", "com.kingbase8.Driver"));
        dataSource.setUrl(BLACK_HOLE_URL);
        dataSource.setUsername("test");
        dataSource.setPassword("test");

        // 严格禁用重试，确保超时判定准确
        dataSource.setConnectionErrorRetryAttempts(0);
        dataSource.setBreakAfterAcquireFailure(true);
        dataSource.setMaxWait(10000);

        // 设置驱动超时属性（3秒）
        dataSource.setConnectionProperties("connectTimeout=3;socketTimeout=3");
        dataSource.setSocketTimeout(3000);

        dataSource.setTestWhileIdle(false);
        dataSource.setInitialSize(0);
        dataSource.init();
    }

    @After
    public void tearDown() {
        if (dataSource != null) dataSource.close();
    }

    /**
     * 行为验证：验证 SocketTimeout 是否能及时掐断无响应的物理连接
     */
    @Test
    public void shouldBreakConnectionWhenSocketIsSilent() throws Exception {
        System.out.println(">>> 开始验证 SocketTimeout 行为...");
        long startTime = System.currentTimeMillis();

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<Void> future = executor.submit(() -> {
            dataSource.getConnection();
            return null;
        });

        try {
            // 给够 15 秒观察时间
            future.get(15, TimeUnit.SECONDS);
            fail("不应连接成功");
        } catch (ExecutionException e) {
            long duration = System.currentTimeMillis() - startTime;
            double durationSec = duration / 1000.0;
            System.out.println(">>> 捕获到异常，实际耗时: " + String.format("%.2f", durationSec) + " 秒");

            // --- 核心断言修正 ---
            // 下限：确保参数生效，非瞬间报错
            assertTrue("报错太快，可能不是超时引起: " + durationSec, durationSec > 2.5);

            // 上限：放宽至 13.0s，适配全量跑时的系统调度与 TCP 重传
            assertTrue("超时验证失败，实际耗时过长: " + durationSec, durationSec < 13.0);

            System.out.println(">>> [验证通过]：SocketTimeout 参数已成功约束驱动行为。");
        } finally {
            executor.shutdownNow();
        }
    }
}