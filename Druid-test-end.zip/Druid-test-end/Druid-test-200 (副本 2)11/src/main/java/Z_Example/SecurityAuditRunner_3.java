package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;

import java.io.InputStream;
import java.sql.Statement;
import java.util.Properties;

public class SecurityAuditRunner_3 {

    private DruidDataSource dataSource;
    private Properties props;

    /**
     * 自动化启动流程
     */
    public SecurityAuditRunner_3 startProcess() throws Exception {
        System.out.println("🛡️ 正在启动金融级安全型数据源自动化流程...");

        // 1. 加载动态配置
        props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("DruidFactory_3.properties")) {
            if (is == null) throw new RuntimeException("找不到 DruidFactory_3.properties 配置文件");
            props.load(is);
        }

        // 2. 初始化数据源 (提示：确保 DruidFactory_Security_3 内部读取了 props 里的 db.url)
        this.dataSource = DruidFactory_Security_3.createSecurityDataSource();
        this.dataSource.init();

        // 动态打印数据库连接地址，证明没有硬编码
        System.out.println("✅ 安全数据源已连接至: " + this.dataSource.getUrl());
        return this;
    }

    /**
     * 自动化验证：SQL 防火墙拦截
     */
    public boolean verifyWallFilter() {
        System.out.println("🔥 [验证] 尝试执行无 WHERE 的 DELETE...");
        try (DruidPooledConnection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM USERS");
            return false; // 如果走到这里，说明没拦住
        } catch (Exception e) {
            System.out.println("🛡️ [拦截成功] 捕获异常: " + e.getMessage());
            return true;
        }
    }

    /**
     * 自动化验证：模拟连接泄露
     */
    public void triggerConnectionLeak() throws Exception {
        System.out.println("💧 [验证] 借走连接且不释放...");
        // 故意泄露，不调用 close()
        dataSource.getConnection();
    }

    public void stopProcess() {
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 安全审计环境已关闭。");
    }

    public DruidDataSource getDataSource() { return dataSource; }
}