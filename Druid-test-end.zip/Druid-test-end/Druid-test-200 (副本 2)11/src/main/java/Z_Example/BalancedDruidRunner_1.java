package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.util.Properties;

public class BalancedDruidRunner_1 {

    private DruidDataSource dataSource;
    private Server jettyServer;

    // 增加成员变量存储动态配置
    private String serverHost;
    private int serverPort;
    private Properties props;

    public static void main(String[] args) {
        BalancedDruidRunner_1 runner = new BalancedDruidRunner_1();
        try {
            runner.startProcess();
            System.out.println("🚀 [Runner] 启动成功，按 Ctrl+C 手动停止。");
            runner.jettyServer.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BalancedDruidRunner_1 startProcess() throws Exception {
        System.out.println("🚀 正在初始化自动化流程...");

        // 1. 加载动态配置
        props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("DruidFactory_1.properties")) {
            if (is == null) throw new RuntimeException("找不到 DruidFactory_1.properties");
            props.load(is);
        }

        this.serverHost = props.getProperty("jetty.host", "0.0.0.0");
        // 【防呆设计】把兜底默认值也改成 0，这样即使配置文件忘了写，也会自动走盲盒模式
        this.serverPort = Integer.parseInt(props.getProperty("jetty.port", "0"));

        // 2. 初始化数据源 (确保 DruidFactory_Fixed_1 也是读取 props 里的 db.initialSize 等参数)
        this.dataSource = DruidFactory_Fixed_1.createBalancedDataSource();
        this.dataSource.init();

        // 3. 动态启动 Jetty
        this.jettyServer = new Server();
        ServerConnector connector = new ServerConnector(this.jettyServer);
        connector.setHost(this.serverHost);
        connector.setPort(this.serverPort); // 如果是 0，Jetty 就知道要去申请空闲端口了
        this.jettyServer.addConnector(connector);

        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        jettyServer.setHandler(context);

        ServletHolder holder = new ServletHolder(new StatViewServlet());
        holder.setInitParameter("loginUsername", props.getProperty("loginUsername"));
        holder.setInitParameter("loginPassword", props.getProperty("loginPassword"));
        context.addServlet(holder, "/druid/*");

        // 🚀 启动服务器！这一步执行完，操作系统才会真正分配好真实的端口
        this.jettyServer.start();

        // 🎯 【核心修改】服务器启动后，立刻获取真实分配的盲盒端口，并覆盖存起来！
        // 这样测试类通过 getServerPort() 获取的，就是实打实的真实端口了！
        this.serverPort = this.jettyServer.getURI().getPort();

        return this;
    }

    public void stopProcess() throws Exception {
        if (jettyServer != null) jettyServer.stop();
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 资源已安全释放。");
    }

    // --- 暴露给测试类使用的 Getter ---
    public DruidDataSource getDataSource() { return dataSource; }
    public Server getJettyServer() { return jettyServer; }
    public String getServerHost() { return serverHost; }
    public int getServerPort() { return serverPort; }
}