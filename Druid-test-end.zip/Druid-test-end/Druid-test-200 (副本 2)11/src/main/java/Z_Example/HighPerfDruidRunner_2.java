package Z_Example;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.druid.support.http.StatViewServlet;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import java.io.InputStream;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class HighPerfDruidRunner_2 {

    private DruidDataSource dataSource;
    private Server jettyServer;
    private ExecutorService executor;

    // 提取为成员变量，彻底告别硬编码
    private String serverHost;
    private int serverPort;

    public static void main(String[] args) {
        HighPerfDruidRunner_2 runner = new HighPerfDruidRunner_2();
        try {
            runner.startProcess();
            System.out.println("🔥 [Runner] 高并发环境已就绪。");
            runner.jettyServer.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 自动化启动流程
     */
    public HighPerfDruidRunner_2 startProcess() throws Exception {
        System.out.println("🔥 正在启动高并发秒杀型数据源自动化流程...");

        // 1. 严格读取你项目里的 DruidFactory_2.properties
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("DruidFactory_2.properties")) {
            if (is == null) throw new RuntimeException("找不到 DruidFactory_2.properties 配置文件");
            props.load(is);
        }

        // 解析绑定的 IP 和 端口 (【修改点1】将兜底默认值改为 0，强制走随机端口分配)
        this.serverHost = props.getProperty("jetty.host", "0.0.0.0");
        this.serverPort = Integer.parseInt(props.getProperty("jetty.port", "0"));

        // 2. 初始化数据源
        this.dataSource = DruidFactory_HighPerf_2.createHighPerfDataSource();
        long start = System.currentTimeMillis();
        this.dataSource.init();
        long end = System.currentTimeMillis();
        System.out.println("✅ 预热完成，耗时: " + (end - start) + "ms");

        // 3. 动态启动监控服务器
        this.jettyServer = new Server();
        ServerConnector connector = new ServerConnector(this.jettyServer);
        connector.setHost(this.serverHost);
        connector.setPort(this.serverPort); // 传入 0，让 Jetty 自己去找空闲端口
        this.jettyServer.addConnector(connector);

        ServletContextHandler context = new ServletContextHandler();
        context.setContextPath("/");
        jettyServer.setHandler(context);
        context.addServlet(new ServletHolder(new StatViewServlet()), "/druid/*");

        // 🚀 启动服务器！必须先 start，系统才会真正分配端口
        this.jettyServer.start();

        // 🎯 【修改点2】服务器启动后，立刻获取系统分配的真实端口，并存入成员变量
        // 这样测试类断言时调用的 getServerPort() 就是实打实的可用端口了
        this.serverPort = this.jettyServer.getURI().getPort();

        return this;
    }

    /**
     * 模拟高并发秒杀压力
     */
    public void simulateTraffic(int threadCount, int taskCount) throws InterruptedException {
        System.out.println("🚀 开始模拟秒杀压力: " + taskCount + " 个请求...");
        this.executor = Executors.newFixedThreadPool(threadCount);
        for (int i = 0; i < taskCount; i++) {
            executor.execute(() -> {
                try (DruidPooledConnection conn = dataSource.getConnection();
                     Statement stmt = conn.createStatement()) {
                    stmt.executeQuery("SELECT 1");
                } catch (Exception ignored) {}
            });
        }
        executor.shutdown();
        executor.awaitTermination(10, TimeUnit.SECONDS);
    }

    public void stopProcess() throws Exception {
        if (executor != null) executor.shutdownNow();
        if (jettyServer != null) jettyServer.stop();
        if (dataSource != null) dataSource.close();
        System.out.println("🛑 高并发资源已释放。");
    }

    // --- 供测试类断言使用的 Getters ---
    public DruidDataSource getDataSource() { return dataSource; }
    public Server getJettyServer() { return jettyServer; }
    public String getServerHost() { return serverHost; }
    public int getServerPort() { return serverPort; }
}