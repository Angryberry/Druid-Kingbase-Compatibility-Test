package SocketTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.InputStream;
import java.util.Properties;

public class SocketTimeout_Test {

    public static final int SOCKET_TIMEOUT_MS = 5000;

    public static void main(String[] args) {
        Properties properties = new Properties();
        try (InputStream in = SocketTimeout_Test.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (in != null) properties.load(in);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection()) {
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        String url = properties.getProperty("url");

        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(url);
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 修正：调用修复后的 getModel 函数 ---
        if ("oracle".equalsIgnoreCase(getModel(url))) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }

        dataSource.setSocketTimeout(SOCKET_TIMEOUT_MS);
        return dataSource;
    }

    // --- 修正：直接解析传入的 url，不再内部 new 对象 ---
    private static String getModel(String url) {
        return (url != null && url.toLowerCase().contains("oracle")) ? "oracle" : "other";
    }

    private static void executeDatabaseOperations(Connection connection) {
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);
        executeUpdate(connection, "UPDATE users SET age = ? WHERE name = ?", 31, "John Doe");
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "John Doe");
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}