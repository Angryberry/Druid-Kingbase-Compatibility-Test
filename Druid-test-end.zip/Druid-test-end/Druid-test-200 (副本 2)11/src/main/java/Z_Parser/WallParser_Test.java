package Z_Parser;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.WallFilter;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Properties;

public class WallParser_Test {

    // 🎯 核心配置：开启防火墙
    public static final boolean WALL_ENABLED = true;

    public static void main(String[] args) {
        Properties properties = new Properties();
        try (InputStream is = WallParser_Test.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is != null) properties.load(is);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            // 尝试执行一个普通的查询
            stmt.executeQuery("SELECT 1");
            System.out.println("✅ 基础查询执行成功");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));

        if (WALL_ENABLED) {
            // 1. 创建防火墙过滤器
            WallFilter wallFilter = new WallFilter();

            // 2. 【最关键】指定 dbType 为 kingbase，强制触发最新的 Kingbase 解析类
            wallFilter.setDbType("kingbase");

            // 3. 配置防火墙细节（可选）
            WallConfig config = new WallConfig();
            config.setSelectUnionCheck(true); // 开启 UNION 注入检查
            wallFilter.setConfig(config);

            // 4. 将过滤器挂载到连接池
            dataSource.setProxyFilters(Collections.singletonList(wallFilter));
        }

        return dataSource;
    }
}