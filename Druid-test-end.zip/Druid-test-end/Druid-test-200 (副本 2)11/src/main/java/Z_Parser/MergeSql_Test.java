package Z_Parser;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.filter.stat.StatFilter;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Properties;

public class MergeSql_Test {

    // 🎯 核心配置：开启 SQL 合并
    public static final boolean MERGE_SQL_ENABLED = true;

    public static void main(String[] args) {
        Properties properties = new Properties();
        try (InputStream is = MergeSql_Test.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is != null) properties.load(is);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection();
             Statement stmt = connection.createStatement()) {
            // 执行两条极其相似的 SQL，观察它们是否在后台被合并
            stmt.executeQuery("SELECT name FROM users WHERE id = 101");
            stmt.executeQuery("SELECT name FROM users WHERE id = 102");
            System.out.println("✅ 两条相似 SQL 已执行完毕。");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl(properties.getProperty("url"));
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));
        dataSource.setDriverClassName(properties.getProperty("driverClassName"));

        // --- 核心：配置 StatFilter 的合并功能 ---
        StatFilter statFilter = new StatFilter();

        // 开启合并开关
        statFilter.setMergeSql(MERGE_SQL_ENABLED);

        // 关键！确保 StatFilter 在进行参数化处理时调用 Kingbase 的解析器
        statFilter.setDbType("kingbase");

        dataSource.setProxyFilters(Collections.singletonList(statFilter));

        return dataSource;
    }
}
