package Z_monitor;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;



public class DruidMetricsValidationTest {

    // ================= 配置区 =================
    private static final String HOST = "http://localhost:8080";
    private static final String CONTEXT = "/druid-demo";
    private static final String BUSINESS_API = HOST + CONTEXT + "/DruidMonitorTest";
    private static final String DATASOURCE_JSON_API = HOST + CONTEXT + "/druid/datasource.json";
    // ==========================================

    public static void main(String[] args) {
        try {
            System.out.println("🚀 步骤 1: 模拟业务请求，连续 5 次触发全属性打点...");
            for (int i = 0; i < 5; i++) {
                doHttpGet(BUSINESS_API);
            }

            System.out.println("⏳ 步骤 2: 等待 Druid 统计引擎同步数据 (1.5秒)...");
            Thread.sleep(1500);

            System.out.println("📊 步骤 3: 远程拉取【数据源】监控大盘的底层 JSON 账本...");
            String jsonResult = doHttpGet(DATASOURCE_JSON_API);

            System.out.println("\n================ 开始参数校验 ================");


            System.out.println("\n【一】连接池核心配置项校验 (静态比对)：");

            // 基础信息
            assertConfig(jsonResult, "\"DbType\":\"kingbase\"", "数据库类型 (DbType: kingbase)");
            assertConfig(jsonResult, "\"DriverClassName\":\"com.kingbase8.Driver\"", "驱动类名 (DriverClassName)");
            assertConfig(jsonResult, "StatFilter", "filter类名 (包含 StatFilter)");

            // 检测机制
            assertConfig(jsonResult, "\"TestOnBorrow\":false", "获取连接时检测 (TestOnBorrow)");
            assertConfig(jsonResult, "\"TestWhileIdle\":true", "空闲时检测 (TestWhileIdle)");
            assertConfig(jsonResult, "\"TestOnReturn\":false", "连接放回时检测 (TestOnReturn)");
            assertConfig(jsonResult, "\"KeepAlive\":false", "KeepAlive");

            // 容量配置
            assertConfig(jsonResult, "\"InitialSize\":0", "初始化连接大小 (InitialSize)");
            assertConfig(jsonResult, "\"MinIdle\":0", "最小空闲连接数 (MinIdle)");
            assertConfig(jsonResult, "\"MaxActive\":8", "最大连接数 (MaxActive)");

            // 超时与时间配置
            assertConfig(jsonResult, "\"QueryTimeout\":0", "查询超时时间 (QueryTimeout)");
            assertConfig(jsonResult, "\"TransactionQueryTimeout\":0", "事务查询超时时间");
            assertConfig(jsonResult, "\"LoginTimeout\":0", "登录超时时间 (LoginTimeout)");
            assertConfig(jsonResult, "\"MaxWait\":-1", "MaxWait");
            assertConfig(jsonResult, "\"MinEvictableIdleTimeMillis\":1800000", "MinEvictableIdleTimeMillis");
            assertConfig(jsonResult, "\"MaxEvictableIdleTimeMillis\":25200000", "MaxEvictableIdleTimeMillis");

            // 默认与高级设置
            assertConfig(jsonResult, "\"DefaultAutoCommit\":true", "默认autocommit设置");
            assertConfig(jsonResult, "\"DefaultReadOnly\":null", "默认只读设置 (null)");
            assertConfig(jsonResult, "\"DefaultTransactionIsolation\":null", "默认事务隔离 (null)");
            assertConfig(jsonResult, "\"FailFast\":false", "FailFast");
            assertConfig(jsonResult, "\"PoolPreparedStatements\":false", "PoolPreparedStatements");
            assertConfig(jsonResult, "\"MaxPoolPreparedStatementPerConnectionSize\":10", "MaxPoolPreparedStatementPerConnectionSize");
            assertConfig(jsonResult, "\"UseUnfairLock\":true", "UseUnfairLock");



            System.out.println("\n【二】动态统计指标校验 (循环5次后的预期结果)：");

            // 连接层统计
            checkMetric(jsonResult, "\"LogicConnectCount\":", 5, "逻辑连接打开次数");
            checkMetric(jsonResult, "\"LogicCloseCount\":", 5, "逻辑连接关闭次数");
            checkMetric(jsonResult, "\"CreateCount\":", 0, "物理连接打开次数 (CreateCount)"); // 至少会真连1次数据库

            // 事务与执行层统计
            checkMetric(jsonResult, "\"ExecuteCount\":", 5, "总执行数");
            checkMetric(jsonResult, "\"ExecuteQueryCount\":", 5, "查询数 (ExecuteQueryCount)");
            checkMetric(jsonResult, "\"ExecuteUpdateCount\":", 5, "更新数 (ExecuteUpdateCount)");
            checkMetric(jsonResult, "\"ExecuteBatchCount\":", 5, "批处理数 (ExecuteBatchCount)");

            // 由于每次访问有1次commit和1次rollback，5次访问预期至少为5
            checkMetric(jsonResult, "\"StartTransactionCount\":", 5, "事务启动数");
            checkMetric(jsonResult, "\"CommitCount\":", 5, "提交数 (CommitCount)");
            checkMetric(jsonResult, "\"RollbackCount\":", 5, "回滚数 (RollbackCount)");
            checkMetric(jsonResult, "\"ErrorCount\":", 5, "错误数 (ErrorCount)");

            // 这些受限于驱动和缓存机制，预期为 0
            checkMetric(jsonResult, "\"RealPreparedStatementOpenCount\":", 0, "真实PreparedStatement打开");
            checkMetric(jsonResult, "\"RealPreparedStatementClosedCount\":", 0, "真实PreparedStatement关闭");
            checkMetric(jsonResult, "\"ClobOpenCount\":", 0, "Clob打开次数");
            checkMetric(jsonResult, "\"BlobOpenCount\":", 0, "Blob打开次数");

            System.out.println("\n🎉 测试结束：页面所有能验证的静态配置与动态指标，全部比对通过！");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ========== 工具方法 (保持不变) ==========
    private static void assertConfig(String json, String expectFragment, String checkName) {
        System.out.printf(" -> 检查 [%-45s] ... ", checkName);
        if (json.contains(expectFragment)) {
            System.out.println("✅ 通过");
        } else {
            System.out.println("🔴 失败 (未找到: " + expectFragment + ")");
        }
    }

    private static void checkMetric(String json, String key, int expectedMin, String checkName) {
        int actualValue = extractIntValue(json, key);
        System.out.printf(" -> 检查 [%-45s] ... 实际值: %-4d ", checkName, actualValue);
        if (actualValue >= expectedMin) {
            System.out.println("✅ 通过");
        } else {
            System.out.println("🔴 失败 (未达到: " + expectedMin + ")");
        }
    }

    private static int extractIntValue(String json, String key) {
        int idx = json.indexOf(key);
        if (idx == -1) return 0;
        int start = idx + key.length();
        int end = json.indexOf(",", start);
        if (end == -1) end = json.indexOf("}", start);
        try { return Integer.parseInt(json.substring(start, end).trim()); }
        catch (Exception e) { return 0; }
    }

    private static String doHttpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        if (conn.getResponseCode() != 200) throw new RuntimeException("HTTP GET 失败: " + conn.getResponseCode());
        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
            StringBuilder res = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) res.append(line);
            return res.toString();
        }
    }
}

