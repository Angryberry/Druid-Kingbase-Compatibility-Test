package Z_monitor;

import com.alibaba.druid.pool.DruidDataSource;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * Druid 监控大盘【全量参数】触发器 Servlet
 */
public class DruidMonitorTestServlet extends HttpServlet {

    private DruidDataSource dataSource;

    @Override
    public void init() throws ServletException {
        System.out.println("🚀 全能打点 Servlet 开始初始化...");
        Properties properties = new Properties();
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("druid.properties")) {
            properties.load(is);
        } catch (IOException e) {
            throw new ServletException("读取 druid.properties 失败", e);
        }

        try {
            dataSource = new DruidDataSource();
            dataSource.setDriverClassName(properties.getProperty("driverClassName"));
            dataSource.setUrl(properties.getProperty("url"));
            dataSource.setUsername(properties.getProperty("username"));
            dataSource.setPassword(properties.getProperty("password"));
            if (properties.getProperty("testWhileIdle") != null) {
                dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle")));
            }
            if (properties.getProperty("validationQuery") != null) {
                dataSource.setValidationQuery(properties.getProperty("validationQuery"));
            }

            // 核心：必须开启 stat 过滤器
            dataSource.setFilters("stat");
            dataSource.init();
            System.out.println("✅ 数据源初始化成功，StatFilter 已挂载！");
        } catch (Exception e) {
            throw new ServletException("Druid 数据源初始化异常", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/plain;charset=UTF-8");
        StringBuilder log = new StringBuilder("🎯 开始执行全属性打点测试...\n");

        // 【参数 1 & 2】：逻辑连接打开次数 (+1)、逻辑连接关闭次数 (+1，在 finally 自动触发)
        try (Connection conn = dataSource.getConnection()) {
            log.append("✅ 获取连接成功 (逻辑连接打开次数 +1)\n");

            // 【参数 3 & 4】：执行数 (+1)、ExecuteQueryCount (+1)
            try (Statement stmt = conn.createStatement()) {
                stmt.executeQuery("SELECT 1");
                log.append("✅ 查询成功 (ExecuteQueryCount +1)\n");
            } catch (Exception e) {}

            // 【参数 5】：ExecuteUpdateCount (+1)
            // 故意写一个不影响真实数据的 UPDATE 语句，只要经过底层，计数器就会 +1
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("UPDATE mysql.user SET user='test' WHERE 1=2");
                log.append("✅ 更新操作执行 (ExecuteUpdateCount +1)\n");
            } catch (Exception e) {}

            // 【参数 6】：ExecuteBatchCount (+1)
            // 使用 PreparedStatement 模拟一次批处理
            try (PreparedStatement pstmt = conn.prepareStatement("SELECT ?")) {
                pstmt.setInt(1, 1);
                pstmt.addBatch();
                pstmt.setInt(1, 2);
                pstmt.addBatch();
                pstmt.executeBatch();
                log.append("✅ 批处理执行 (ExecuteBatchCount +1)\n");
            } catch (Exception e) {}

            // 【参数 7】：提交数 (CommitCount +1)
            conn.setAutoCommit(false); // 开启手动事务
            try (Statement stmt = conn.createStatement()) { stmt.executeQuery("SELECT 1"); } catch (Exception e) {}
            conn.commit();
            log.append("✅ 事务手动提交 (CommitCount +1)\n");

            // 【参数 8】：回滚数 (RollbackCount +1)
            try (Statement stmt = conn.createStatement()) { stmt.executeQuery("SELECT 1"); } catch (Exception e) {}
            conn.rollback();
            log.append("✅ 事务手动回滚 (RollbackCount +1)\n");
            conn.setAutoCommit(true); // 恢复自动提交

            // 【参数 9】：错误数 (ErrorCount +1)
            // 故意查询一个绝对不存在的表，逼迫数据库报错
            try (Statement stmt = conn.createStatement()) {
                stmt.executeQuery("SELECT * FROM I_AM_A_TABLE_THAT_DOES_NOT_EXIST_999");
            } catch (Exception e) {
                log.append("✅ 故意制造 SQL 异常成功 (ErrorCount +1)\n");
            }

            // 【参数 10 & 11】：真实PreparedStatement打开/关闭次数 (+1)
            try (PreparedStatement pstmt = conn.prepareStatement("SELECT 1")) {
                pstmt.executeQuery();
                log.append("✅ 真实游标创建成功 (RealPreparedStatementOpenCount +1)\n");
            } catch (Exception e) {}

            // 【参数 12 & 13】：Clob打开次数 (+1)、Blob打开次数 (+1)
            // 直接调用 Connection 的创建 LOB 对象方法（大部分主流驱动如 MySQL 都支持）
            try {
                Clob clob = conn.createClob();
                log.append("✅ Clob 创建成功 (Clob打开次数 +1)\n");
            } catch (Exception e) {}
            try {
                Blob blob = conn.createBlob();
                log.append("✅ Blob 创建成功 (Blob打开次数 +1)\n");
            } catch (Exception e) {}

            resp.getWriter().write(log.toString());
        } catch (SQLException e) {
            resp.getWriter().write("🔴 数据库连接失败: " + e.getMessage());
        }
    }

    @Override
    public void destroy() {
        if (dataSource != null) {
            dataSource.close();
        }
    }
}

