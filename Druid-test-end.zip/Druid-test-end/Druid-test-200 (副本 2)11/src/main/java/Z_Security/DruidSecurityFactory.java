package Z_Security;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.wall.WallConfig;
import com.alibaba.druid.wall.WallFilter;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DruidSecurityFactory {

    /**
     * 创建安全增强型数据源 (参数化适配版)
     */
    public static DruidDataSource createSecurityDataSource() throws Exception {
        // 1. 加载动态配置 (彻底告别硬编码)
        Properties props = new Properties();
        try (InputStream is = DruidSecurityFactory.class.getClassLoader().getResourceAsStream("DruidFactory_Security.properties")) {
            if (is == null) throw new RuntimeException("找不到 DruidFactory_Security.properties 配置文件");
            props.load(is);
        }

        DruidDataSource ds = new DruidDataSource();

        // 2. 基础连接信息 (从配置文件读取)
        ds.setUrl(props.getProperty("db.url"));
        ds.setDriverClassName(props.getProperty("db.driverClassName"));
        ds.setUsername(props.getProperty("db.username"));
        ds.setPassword(props.getProperty("db.password"));

        // 3. 核心：硬核防火墙配置 (WallConfig)
        WallConfig config = new WallConfig();

        // --- 基础注入防御 ---
        config.setConditionAndAlwayTrueAllow(false); // 禁止 '1'='1' 恒真逻辑
        config.setMultiStatementAllow(false);       // 禁止分号多语句执行
        config.setStrictSyntaxCheck(true);          // 开启严格语法检查

        // --- 高危操作拦截 ---
        config.setDeleteWhereNoneCheck(true);       // 禁止无 WHERE 的 DELETE
        config.setUpdateWhereNoneCheck(true);       // 禁止无 WHERE 的 UPDATE

        // --- 函数与元数据探测拦截 ---
        config.setFunctionCheck(true);              // 开启函数调用检查
        config.setSchemaCheck(true);                // 禁止跨 Schema 访问系统表

        // 显式拒绝用于时间盲注和指纹探测的函数
        config.getDenyFunctions().add("pg_sleep");
        config.getDenyFunctions().add("sys_sleep");
        config.getDenyFunctions().add("version");
        config.getDenyFunctions().add("current_user");

        // 4. 过滤器注入 (WallFilter)
        WallFilter filter = new WallFilter();
        // 动态读取数据库方言类型
        filter.setDbType(props.getProperty("db.type", "kingbase"));
        filter.setConfig(config);

        List<com.alibaba.druid.filter.Filter> filterList = new ArrayList<>();
        filterList.add(filter);
        ds.setProxyFilters(filterList);

        // 5. 性能与稳定性参数 (动态读取)
        ds.setInitialSize(Integer.parseInt(props.getProperty("db.initialSize", "5")));
        ds.setMaxActive(Integer.parseInt(props.getProperty("db.maxActive", "20")));
        ds.setValidationQuery("SELECT 1");          // 消除 validationQuery 未设置的警告
        ds.setTestWhileIdle(true);

        // 6. 初始化
        ds.init();

        return ds;
    }
}