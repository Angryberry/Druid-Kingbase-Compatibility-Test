package DefaultReadOnly_Test;

import com.alibaba.druid.pool.DruidDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.InputStream;
import java.util.Properties;

public class DefaultReadOnly_Test {
    public static final boolean DEFAULT_READ_ONLY = true;

    public static void main(String[] args) {
        Properties properties = new Properties();
        // 修正：使用 ClassLoader 更加稳健
        try (InputStream is = DefaultReadOnly_Test.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is != null) properties.load(is);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection()) {
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        String url = properties.getProperty("url");

        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(url);
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // 设置验证查询逻辑
        dataSource.setTestWhileIdle(Boolean.parseBoolean(properties.getProperty("testWhileIdle", "true")));
        if (isOracle(url)) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }

        // 设置默认只读
        dataSource.setDefaultReadOnly(DEFAULT_READ_ONLY);
        return dataSource;
    }

    // 修正后的判定逻辑
    private static boolean isOracle(String url) {
        return url != null && url.toLowerCase().contains("oracle");
    }

    private static void executeDatabaseOperations(Connection connection) {
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            // 正常逻辑下，这里会打印异常
            System.err.println("❌ 写入失败: " + e.getMessage());
        }
    }
}