package QueryTimeout_Test;

import com.alibaba.druid.pool.DruidDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.InputStream;
import java.util.Properties;

public class QueryTimeout_Test {
    public static final int QUERY_TIMEOUT_SECONDS = 10;

    public static void main(String[] args) {
        Properties properties = new Properties();
        // 修正：使用 ClassLoader 加载
        try (InputStream is = QueryTimeout_Test.class.getClassLoader().getResourceAsStream("druid.properties")) {
            if (is != null) properties.load(is);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        DruidDataSource dataSource = createDataSource(properties);

        try (Connection connection = dataSource.getConnection()) {
            executeDatabaseOperations(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dataSource.close();
        }
    }

    public static DruidDataSource createDataSource(Properties properties) {
        DruidDataSource dataSource = new DruidDataSource();
        String url = properties.getProperty("url");

        dataSource.setDriverClassName(properties.getProperty("driverClassName"));
        dataSource.setUrl(url);
        dataSource.setUsername(properties.getProperty("username"));
        dataSource.setPassword(properties.getProperty("password"));

        // --- 修正：不再在 getModel 内部 new 对象，直接根据配置里的 url 判断 ---
        if (isOracle(url)) {
            dataSource.setValidationQuery("SELECT 1 FROM DUAL");
        } else {
            dataSource.setValidationQuery("SELECT 1");
        }

        dataSource.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
        return dataSource;
    }

    private static boolean isOracle(String url) {
        return url != null && url.toLowerCase().contains("oracle");
    }

    private static void executeDatabaseOperations(Connection connection) {
        executeUpdate(connection, "INSERT INTO users (name, age) VALUES (?, ?)", "John Doe", 30);
        executeUpdate(connection, "UPDATE users SET age = ? WHERE name = ?", 31, "John Doe");
        executeUpdate(connection, "DELETE FROM users WHERE name = ?", "John Doe");
    }

    private static void executeUpdate(Connection connection, String sql, Object... params) {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
            System.out.println("Executed SQL: " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}